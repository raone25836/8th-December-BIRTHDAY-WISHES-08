import React, { useEffect, useState } from 'react';
import { useTheme } from './ThemeContext';

export const Particles: React.FC = () => {
  const [stars, setStars] = useState<{id: number, style: React.CSSProperties}[]>([]);
  const [orbs, setOrbs] = useState<{id: number, style: React.CSSProperties}[]>([]);
  const { colors } = useTheme();

  useEffect(() => {
    // Generate Stars
    const starCount = 60;
    const newStars = [];
    for (let i = 0; i < starCount; i++) {
      const size = Math.random() * 2 + 1;
      newStars.push({
        id: i,
        style: {
          left: `${Math.random() * 100}vw`,
          top: `${Math.random() * 100}vh`,
          width: `${size}px`,
          height: `${size}px`,
          animationDuration: `${Math.random() * 3 + 2}s, ${Math.random() * 60 + 90}s`, // Twinkle duration, Drift duration
          background: `radial-gradient(circle, var(--text-main) 0%, transparent 70%)`,
          opacity: Math.random() * 0.5 + 0.2
        }
      });
    }
    setStars(newStars);

    // Generate Orbs
    const orbCount = 6;
    const newOrbs = [];
    
    for (let i = 0; i < orbCount; i++) {
      const size = Math.random() * 150 + 100;
      const duration = Math.random() * 15 + 20;
      // Alternate between primary and secondary accents for orbs
      const isPrimary = i % 2 === 0;
      
      newOrbs.push({
        id: i,
        style: {
          width: `${size}px`,
          height: `${size}px`,
          left: `${Math.random() * 100}vw`,
          bottom: `${Math.random() * 30 - 10}vh`,
          // We use the CSS variables directly in the gradient string
          background: isPrimary 
            ? `radial-gradient(circle, var(--accent-primary) 0%, transparent 70%)` 
            : `radial-gradient(circle, var(--accent-secondary) 0%, transparent 70%)`,
          '--duration': `${duration}s`,
          animationDelay: `${Math.random() * -20}s`,
          opacity: Math.random() * 0.15 + 0.05
        } as React.CSSProperties
      });
    }
    setOrbs(newOrbs);
  }, []);

  return (
    <>
      {/* Stars Layer */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none z-0">
        {stars.map(star => (
          <span 
            key={star.id} 
            className="absolute rounded-full"
            style={{
              ...star.style,
              animation: 'twinkle 4s infinite ease-in-out, drift 120s linear infinite'
            }}
          />
        ))}
      </div>

      {/* Aurora Layer - Uses Theme Variables */}
      <div className="fixed inset-[-10%_-10%_auto_-10%] h-[60vh] blur-3xl pointer-events-none z-0 transition-colors duration-700"
           style={{
             background: 'radial-gradient(50% 60% at 10% 30%, var(--accent-primary) 0%, transparent 60%), radial-gradient(40% 50% at 80% 20%, var(--accent-secondary) 0%, transparent 60%)',
             opacity: 0.15
           }}
      />

      {/* Orbs Layer */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none z-0">
        {orbs.map(orb => (
          <div 
            key={orb.id}
            className="absolute rounded-full mix-blend-screen blur-2xl transition-colors duration-700"
            style={{
              ...orb.style,
              animation: `floatUp var(--duration) linear infinite`
            }}
          />
        ))}
      </div>
    </>
  );
};
