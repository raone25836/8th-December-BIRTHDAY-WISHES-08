
import React from 'react';
import { motion, HTMLMotionProps } from 'framer-motion';
import { ChevronLeft } from 'lucide-react';

// --- Cinematic Button (Themed) ---
interface ButtonProps extends HTMLMotionProps<"button"> {
  children: React.ReactNode;
  variant?: 'primary' | 'secondary' | 'danger' | 'scifi';
  className?: string;
  onClick?: React.MouseEventHandler<HTMLButtonElement>;
  disabled?: boolean;
}

export const GlowingButton: React.FC<ButtonProps> = ({ onClick, children, className, disabled, variant = 'primary', ...props }) => {
  const baseStyles = "relative overflow-hidden font-bold py-3 px-8 rounded-xl transition-all shadow-lg font-['Inter'] tracking-wide border";
  
  const variants = {
    primary: "border-[var(--accent-secondary)] bg-gradient-to-r from-[var(--accent-secondary)] to-[#fbbf24] text-[#0b1026] hover:brightness-110 shadow-[0_0_15px_rgba(245,158,11,0.3)]",
    secondary: "bg-[var(--bg-card)] border-[var(--border-color)] text-[var(--text-main)] hover:bg-[var(--bg-input)]",
    danger: "bg-red-900/40 border-red-500/50 text-red-300 hover:bg-red-900/60",
    scifi: "bg-cyan-950/50 border-cyan-500/50 text-cyan-400 hover:bg-cyan-900/70 hover:shadow-[0_0_20px_rgba(6,182,212,0.4)] uppercase tracking-widest text-xs"
  };

  return (
    <motion.button
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      onClick={onClick}
      disabled={disabled}
      className={`${baseStyles} ${variants[variant]} ${disabled ? 'opacity-50 cursor-not-allowed' : ''} ${className || ''}`}
      {...props}
    >
      <span className="relative z-10 flex items-center justify-center gap-2">{children}</span>
    </motion.button>
  );
};

// --- Glass Input (Themed) ---
export const GlassInput: React.FC<React.InputHTMLAttributes<HTMLInputElement>> = (props) => (
  <input
    {...props}
    className={`w-full bg-[var(--bg-input)] border border-[var(--border-color)] rounded-xl px-4 py-3 text-[var(--text-main)] placeholder-[var(--text-muted)] focus:outline-none focus:ring-2 focus:ring-[var(--accent-secondary)] transition-all shadow-inner backdrop-blur-sm ${props.className || ''}`}
  />
);

// --- Glass Card Container (Themed) ---
interface GlassCardProps extends HTMLMotionProps<"div"> {
  children: React.ReactNode;
  delay?: number;
  className?: string;
}

export const GlassCard: React.FC<GlassCardProps> = ({ children, className, delay = 0, ...props }) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    exit={{ opacity: 0, y: -20 }}
    transition={{ duration: 0.8, delay, ease: "easeOut" }}
    className={`bg-[var(--bg-card)] backdrop-blur-xl border border-[var(--border-color)] shadow-xl rounded-2xl ${className || ''}`}
    {...props}
  >
    {children}
  </motion.div>
);

// --- Sci-Fi Stats Card ---
export const SciFiCard: React.FC<GlassCardProps> = ({ children, className, delay = 0, ...props }) => (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.5, delay }}
      className={`relative bg-[#0f172a]/80 backdrop-blur-md border border-cyan-500/30 shadow-[0_0_20px_rgba(6,182,212,0.1)] rounded-xl overflow-hidden ${className || ''}`}
      {...props}
    >
        {/* Holographic corner accents */}
        <div className="absolute top-0 left-0 w-8 h-8 border-t-2 border-l-2 border-cyan-500/60 rounded-tl-xl"></div>
        <div className="absolute bottom-0 right-0 w-8 h-8 border-b-2 border-r-2 border-cyan-500/60 rounded-br-xl"></div>
        {children}
    </motion.div>
);


// --- Page Transition Wrapper ---
export const PageTransition: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <motion.div
    initial={{ opacity: 0, filter: 'blur(8px)' }}
    animate={{ opacity: 1, filter: 'blur(0px)' }}
    exit={{ opacity: 0, filter: 'blur(8px)' }}
    transition={{ duration: 0.8, ease: "easeInOut" }}
    className="w-full h-full"
  >
    {children}
  </motion.div>
);

// --- Bottom Back Button (Mobile Optimized) ---
export const BottomBackButton: React.FC<{ onClick?: () => void }> = ({ onClick }) => (
  <motion.button
    onClick={onClick || (() => window.history.back())}
    whileTap={{ scale: 0.9 }}
    className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 flex items-center gap-2 px-6 py-2 rounded-full bg-[var(--bg-card)] border border-[var(--border-color)] shadow-lg backdrop-blur-md text-[var(--text-muted)] text-sm font-medium hover:text-[var(--text-main)] hover:bg-[var(--bg-input)] transition-colors"
  >
    <ChevronLeft size={16} /> Back to Start
  </motion.button>
);
