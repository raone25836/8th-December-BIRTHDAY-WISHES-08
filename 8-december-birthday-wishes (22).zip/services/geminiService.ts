

import { GoogleGenAI } from "@google/genai";

const apiKey = process.env.API_KEY;
// Safely initialize only if key exists (handling development/preview environments)
const ai = apiKey ? new GoogleGenAI({ apiKey }) : null;

export const generateWishSuggestion = async (category: string, style: string): Promise<string> => {
  if (!ai) return "Happy Birthday! Have a magical day! (AI Unavailable)";

  try {
    const prompt = `Write a short, ${style} birthday wish for a girl named Shivani. The sender is a ${category}. Keep it under 30 words. Add appropriate emojis.`;
    
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });
    
    return response.text?.trim() || "Happy Birthday Shivani!";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Wishing you the happiest of birthdays! ✨";
  }
};

export const generateLoveReward = async (): Promise<string> => {
    if (!ai) return "You are amazing and loved beyond measure! ✨";
    try {
        const prompt = "Write a beautiful, unique, and deep 2-sentence love message/appreciation for a girl named Shivani to celebrate her birthday. Make it poetic and magical.";
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
        });
        return response.text?.trim() || "You are the magic in everyone's life!";
    } catch(e) {
        return "You are the magic in everyone's life! ✨";
    }
}

export const generatePoem = async (mood: string): Promise<string> => {
    if (!ai) return "Roses are red, violets are blue, Happy Birthday to you! (AI unavailable)";
    try {
        const prompt = `Write a short 4-line rhyming poem for Shivani's birthday based on the mood: ${mood}. Make it sweet and special.`;
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
        });
        return response.text?.trim() || "Happy Birthday dear Shivani!";
    } catch(e) {
        return "Happy Birthday dear Shivani! ✨";
    }
}

export const checkContentSafety = async (text: string): Promise<boolean> => {
  if (!ai) return true; // Allow if AI is down, but normally fail open/closed based on policy

  try {
    const prompt = `Analyze the following birthday message for offensive, rude, or inappropriate content. Reply with ONLY 'SAFE' or 'UNSAFE'. Message: "${text}"`;
    
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });
    
    const result = response.text?.trim().toUpperCase();
    return result === 'SAFE';
  } catch (error) {
    return true; // Fallback
  }
};