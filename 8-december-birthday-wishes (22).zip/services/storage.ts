import { Wish, PrivateWish, Photo, MOCK_WISHES } from '../types';

const WISHES_KEY = 'bday_wishes_db';
const PRIVATE_WISHES_KEY = 'bday_private_wishes_db';
const PHOTOS_KEY = 'bday_photos_db';

// --- Wishes ---

export const getWishes = (): Wish[] => {
  const stored = localStorage.getItem(WISHES_KEY);
  if (!stored) {
    // Initialize with mock data if empty
    localStorage.setItem(WISHES_KEY, JSON.stringify(MOCK_WISHES));
    return MOCK_WISHES;
  }
  return JSON.parse(stored);
};

export const saveWish = (wish: Wish): void => {
  const current = getWishes();
  const updated = [wish, ...current];
  localStorage.setItem(WISHES_KEY, JSON.stringify(updated));
};

export const updateWish = (updatedWish: Wish): void => {
  const current = getWishes();
  const index = current.findIndex(w => w.id === updatedWish.id);
  if (index !== -1) {
    current[index] = updatedWish;
    localStorage.setItem(WISHES_KEY, JSON.stringify(current));
  }
};

export const deleteWish = (id: string): void => {
  const current = getWishes();
  const updated = current.filter(w => w.id !== id);
  localStorage.setItem(WISHES_KEY, JSON.stringify(updated));
};

export const toggleWishApproval = (id: string): void => {
  const current = getWishes();
  const updated = current.map(w => w.id === id ? { ...w, isApproved: !w.isApproved } : w);
  localStorage.setItem(WISHES_KEY, JSON.stringify(updated));
};

// --- Private Wishes ---

export const getPrivateWishes = (): PrivateWish[] => {
  const stored = localStorage.getItem(PRIVATE_WISHES_KEY);
  return stored ? JSON.parse(stored) : [];
};

export const savePrivateWish = (wish: PrivateWish): void => {
  const current = getPrivateWishes();
  const updated = [wish, ...current];
  localStorage.setItem(PRIVATE_WISHES_KEY, JSON.stringify(updated));
};

// --- Photos (Memory Lane) ---

const MOCK_PHOTOS: Photo[] = [
    { id: '1', url: "https://images.unsplash.com/photo-1513151233558-d860c5398176?w=500", caption: "Party Time!", timestamp: Date.now() },
    { id: '2', url: "https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=500", caption: "Beautiful Smile", timestamp: Date.now() },
    { id: '3', url: "https://images.unsplash.com/photo-1492633423870-43d1cd2775eb?w=500", caption: "Making Memories", timestamp: Date.now() }
];

export const getPhotos = (): Photo[] => {
    const stored = localStorage.getItem(PHOTOS_KEY);
    if (!stored) {
        localStorage.setItem(PHOTOS_KEY, JSON.stringify(MOCK_PHOTOS));
        return MOCK_PHOTOS;
    }
    return JSON.parse(stored);
};

export const savePhoto = (photo: Photo): void => {
    const current = getPhotos();
    const updated = [photo, ...current];
    localStorage.setItem(PHOTOS_KEY, JSON.stringify(updated));
};

export const deletePhoto = (id: string): void => {
    const current = getPhotos();
    const updated = current.filter(p => p.id !== id);
    localStorage.setItem(PHOTOS_KEY, JSON.stringify(updated));
};