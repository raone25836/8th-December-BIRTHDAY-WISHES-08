
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { User, Lock, ArrowRight } from 'lucide-react';
import { PageTransition, GlassCard, GlassInput, BottomBackButton } from '../components/UI';

interface VerificationProps {
  onVerify: (name: string, code: string) => void;
  onBack: () => void;
}

export const VerificationView: React.FC<VerificationProps> = ({ onVerify, onBack }) => {
  const [name, setName] = useState('');
  const [code, setCode] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setError("Please tell us your name to continue!");
      return;
    }
    // Simple logic: if '0812' is used, they get VIP path. Otherwise Guest.
    onVerify(name, code);
  };

  return (
    <PageTransition>
      <div className="min-h-screen flex items-center justify-center p-4 relative z-10 pb-20">
        <GlassCard className="max-w-md w-full p-8 border-t-4 border-t-[var(--accent-secondary)]">
          <div className="text-center mb-8">
            <h2 className="text-4xl font-bold cursive text-[var(--text-main)] mb-2">Who are you?</h2>
            <p className="text-[var(--text-muted)] text-sm">Please identify yourself to enter.</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
               <label className="text-xs font-bold text-[var(--accent-primary)] uppercase tracking-wider ml-1">Your Name</label>
               <div className="relative">
                 <User className="absolute left-3 top-3.5 text-[var(--text-muted)]" size={18} />
                 <GlassInput 
                    placeholder="E.g., Rahul" 
                    className="pl-10"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    autoFocus
                 />
               </div>
            </div>

            <div className="space-y-2">
               <label className="text-xs font-bold text-[var(--accent-secondary)] uppercase tracking-wider ml-1 opacity-80">VIP Access</label>
               <div className="relative">
                 <Lock className="absolute left-3 top-3.5 text-[var(--text-muted)]" size={18} />
                 <GlassInput 
                    type="password"
                    inputMode="numeric"
                    maxLength={10}
                    placeholder="Secret Code" 
                    className="pl-10 tracking-widest"
                    value={code}
                    onChange={(e) => setCode(e.target.value)}
                 />
               </div>
            </div>

            {error && <p className="text-red-400 text-sm text-center font-bold animate-pulse">{error}</p>}

            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="w-full py-4 rounded-xl bg-gradient-to-r from-[var(--accent-primary)] to-purple-600 text-white font-bold text-lg shadow-lg hover:shadow-xl transition-all flex items-center justify-center gap-2"
            >
              Continue <ArrowRight size={20} />
            </motion.button>
          </form>
        </GlassCard>
      </div>
      <BottomBackButton onClick={onBack} />
    </PageTransition>
  );
};
