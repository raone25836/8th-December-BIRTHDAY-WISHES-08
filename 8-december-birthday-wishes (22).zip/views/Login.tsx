

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Lock, User, Sparkles, Key, HelpCircle, Heart, Stars, ShieldAlert, AlertTriangle } from 'lucide-react';
import { UserRole } from '../types';
import { GlowingButton, GlassInput, GlassCard, PageTransition, BottomBackButton } from '../components/UI';
import { useTheme } from '../components/ThemeContext';
import { db } from '../services/database';

interface LoginProps {
  onLogin: (role: UserRole) => void;
  initialName?: string;
  onBack: () => void;
}

export const LoginView: React.FC<LoginProps> = ({ onLogin, initialName = '', onBack }) => {
  const [id, setId] = useState(initialName);
  const [password, setPassword] = useState('');
  const [passcode, setPasscode] = useState('');
  const [error, setError] = useState('');
  const [show2FA, setShow2FA] = useState(false);
  const [twoFACode, setTwoFACode] = useState('');
  const [showDemo, setShowDemo] = useState(false);
  const [isBlocked, setIsBlocked] = useState(false);
  
  const { theme, colors } = useTheme();

  // Load saved identity if available
  useEffect(() => {
    const savedName = localStorage.getItem('last_user_name');
    if (savedName && !initialName) {
        setId(savedName);
    }
  }, [initialName]);

  const generateDeviceId = () => {
    let devId = localStorage.getItem('device_fingerprint');
    if (!devId) {
        devId = Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
        localStorage.setItem('device_fingerprint', devId);
    }
    return devId;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    // --- GLOBAL TRACKING SYSTEM (CRITICAL UPDATE) ---
    // Track EVERYONE immediately upon button click, regardless of success/failure
    const deviceId = generateDeviceId();
    const trackingName = id.trim() || 'Anonymous Visitor';
    
    // 1. Log to Security Console
    db.logSecurityEvent('LOGIN', `Global Visit Attempt by: ${trackingName}`, trackingName, 'INFO');
    
    // 2. Track in "User Insights" (Known Users DB)
    db.trackUserLogin(deviceId, trackingName, 'Visitor (Global)');
    // -----------------------------

    // Check if user is blocked
    if (db.isUserBlocked(id)) {
        setIsBlocked(true);
        db.logSecurityEvent('LOGIN_FAIL', `Blocked user attempted login: ${id}`, id, 'CRITICAL');
        return;
    }

    // Check System Locks
    const sysState = db.getSystemState();

    // Get Dynamic Codes from DB (or defaults)
    const adminCode = db.getConfig('admin_code', 'SHIVAM123');
    const privateCode = db.getConfig('private_code', 'SHIVANI08');
    
    // Admin Check
    if (passcode === adminCode) {
      if (!show2FA) {
        setShow2FA(true);
        return;
      }
    } 
    // Private Check
    else if (passcode === privateCode) {
      if (sysState.privateLocked) {
          setError("Private Portal is temporarily locked for maintenance.");
          return;
      }

      if (password.length > 0) {
        db.logSecurityEvent('LOGIN', `Private Access Granted`, id, 'SUCCESS');
        db.trackUserLogin(deviceId, id, 'Private');
        localStorage.setItem('last_user_name', id);
        onLogin(UserRole.PRIVATE);
      } else {
        setError('Please enter your password.');
        db.logSecurityEvent('LOGIN_FAIL', `Private Access Failed: Missing Password`, id, 'WARNING');
      }
    } 
    // Guest Fallback
    else {
        if (sysState.guestLocked) {
            setError("Guest Portal is closed at this moment.");
            return;
        }
        // Log guest login
        db.logSecurityEvent('LOGIN', `Guest Login`, id, 'SUCCESS');
        db.trackUserLogin(deviceId, id, 'Guest');
        localStorage.setItem('last_user_name', id);
        onLogin(UserRole.PUBLIC);
    }
  };

  const handle2FASubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const deviceId = generateDeviceId();
    if (twoFACode === '123456') { // Hardcoded 2FA for demo, normally dynamic too
      db.logSecurityEvent('LOGIN', `Admin Access Granted via 2FA`, id, 'SUCCESS');
      db.trackUserLogin(deviceId, id, 'Admin');
      onLogin(UserRole.ADMIN);
    } else {
      setError('Invalid 2FA Code');
      db.logSecurityEvent('LOGIN_FAIL', `Admin 2FA Failed`, id, 'CRITICAL');
    }
  };

  if (isBlocked) {
      return (
          <div className="min-h-screen flex items-center justify-center p-4 bg-red-950/20">
              <GlassCard className="max-w-md w-full p-8 text-center border-red-500/50 bg-black/80">
                  <ShieldAlert size={64} className="mx-auto text-red-500 mb-6 animate-pulse"/>
                  <h2 className="text-3xl font-bold text-red-400 mb-2 font-mono">ACCESS DENIED</h2>
                  <p className="text-red-200/70 mb-6">Your identity "{id}" has been flagged by the security mainframe. Access to this portal is restricted.</p>
                  <button onClick={() => window.location.reload()} className="text-xs text-red-500 hover:text-red-300 uppercase tracking-widest underline">Return to Safety</button>
              </GlassCard>
          </div>
      );
  }

  if (show2FA) return <TwoFAView error={error} twoFACode={twoFACode} setTwoFACode={setTwoFACode} handle2FASubmit={handle2FASubmit} setShow2FA={setShow2FA} />;

  // Dynamic Styles based on Theme
  const isLove = theme === 'Love';
  const isGalaxy = theme === 'Galaxy';
  const isSilver = theme === 'Silver';

  return (
    <PageTransition>
      <div className="min-h-screen flex items-center justify-center p-4 relative overflow-hidden pb-20 pt-24">
        
        {/* Dynamic Background Elements for Specific Patterns */}
        {isGalaxy && (
            <div className="absolute inset-0 pointer-events-none">
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-indigo-900 rounded-full mix-blend-color-dodge blur-[120px] opacity-20"></div>
                <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-purple-900 rounded-full mix-blend-screen blur-[100px] opacity-20"></div>
            </div>
        )}

        {isLove && (
           <div className="absolute inset-0 pointer-events-none">
              <motion.div animate={{ y: [0, -20, 0] }} transition={{ duration: 5, repeat: Infinity }} className="absolute top-20 left-[20%] text-pink-500/20"><Heart size={100} fill="currentColor" /></motion.div>
              <motion.div animate={{ y: [0, -30, 0] }} transition={{ duration: 7, repeat: Infinity, delay: 1 }} className="absolute bottom-20 right-[20%] text-red-500/20"><Heart size={80} fill="currentColor" /></motion.div>
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-pink-500/10 rounded-full blur-[100px]"></div>
           </div>
        )}

        <GlassCard className={`max-w-md w-full relative overflow-hidden transition-all duration-700 ${isSilver ? 'border-gray-400/40 bg-gray-900/40' : ''}`}>
          
          {/* Decorative Card Header */}
          {isSilver && <div className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-transparent via-gray-300 to-transparent"></div>}
          {isLove && <div className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-transparent via-pink-400 to-transparent"></div>}

          <div className="p-8 relative z-10">
            {/* Header Section */}
            <div className="text-center mb-8 relative">
              <motion.div 
                animate={{ rotate: [0, 5, -5, 0], scale: [1, 1.05, 1] }} 
                transition={{ duration: 6, repeat: Infinity }}
                className="inline-flex justify-center items-center mb-3"
              >
                {isLove ? <Heart size={56} className="text-pink-500 fill-pink-500/20 drop-shadow-[0_0_10px_rgba(236,72,153,0.8)]" /> :
                 isGalaxy ? <Stars size={56} className="text-indigo-400 drop-shadow-[0_0_10px_rgba(129,140,248,0.8)]" /> :
                 <Sparkles size={56} className="text-[var(--accent-secondary)]" />
                }
              </motion.div>

              {/* Realistic Gold Text Effect for Everyone (it looks premium) */}
              <h1 className="text-5xl font-bold mb-2 cursive gold-text-shimmer leading-tight tracking-wide">
                8th December
              </h1>
              <p className="font-medium tracking-widest uppercase text-xs text-[var(--accent-primary)]">
                {isGalaxy ? 'Interstellar Gateway' : isLove ? 'Magical Love Portal' : 'Enter the Celebration'}
              </p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-5">
              <div className="space-y-1">
                <label className="text-xs font-bold ml-1 uppercase tracking-wider text-[var(--text-muted)]">Identity</label>
                <div className="relative group">
                  <User className="absolute left-3 top-3.5 transition-colors text-[var(--accent-primary)]" size={18} />
                  <GlassInput 
                    placeholder="Your Name" 
                    className="pl-10 text-[var(--text-main)]"
                    value={id}
                    onChange={(e) => setId(e.target.value)}
                    required
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold ml-1 uppercase tracking-wider text-[var(--text-muted)]">Password (Optional)</label>
                <div className="relative group">
                  <Key className="absolute left-3 top-3.5 transition-colors text-[var(--accent-primary)]" size={18} />
                  <GlassInput 
                    type="password"
                    placeholder="Required for Private Access" 
                    className="pl-10 text-[var(--text-main)]"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                  />
                </div>
              </div>
              
              <div className="space-y-1">
                <label className="text-xs font-bold ml-1 uppercase tracking-wider text-[var(--text-muted)]">Secret Passcode</label>
                <div className="relative group">
                  <Lock className="absolute left-3 top-3.5 transition-colors text-[var(--accent-primary)]" size={18} />
                  <GlassInput 
                    type="password"
                    placeholder="Role Code (Empty for Guests)" 
                    className="pl-10 text-[var(--text-main)]"
                    value={passcode}
                    onChange={(e) => setPasscode(e.target.value)}
                  />
                </div>
              </div>

              {error && (
                <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="text-red-300 text-sm text-center font-bold bg-red-900/40 p-2 rounded-lg border border-red-500/30 flex items-center justify-center gap-2">
                  <AlertTriangle size={16}/> {error}
                </motion.div>
              )}

              {/* Flame Button Effect */}
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="w-full py-4 rounded-xl font-bold text-white uppercase tracking-wider flame-button mt-6 text-shadow-glow"
              >
                Enter Portal
              </motion.button>
            </form>

            <div className="mt-8 text-center">
              <button onClick={() => setShowDemo(!showDemo)} className="flex items-center justify-center w-full gap-2 text-xs transition-colors text-[var(--accent-primary)] hover:text-[var(--text-main)]">
                 <HelpCircle size={14} /> {showDemo ? 'Hide Secrets' : 'Show Demo Access'}
              </button>
              <AnimatePresence>
                {showDemo && (
                  <motion.div 
                    initial={{ height: 0, opacity: 0 }} 
                    animate={{ height: 'auto', opacity: 1 }} 
                    exit={{ height: 0, opacity: 0 }}
                    className="overflow-hidden mt-2"
                  >
                     <div className="p-3 rounded-lg text-left text-xs space-y-2 border bg-[var(--bg-input)] border-[var(--border-color)] text-[var(--text-muted)]">
                        <div><span className="font-bold opacity-80">Admin:</span> Code: <code className="bg-black/20 px-1 rounded">{db.getConfig('admin_code', 'SHIVAM123')}</code></div>
                        <div><span className="font-bold opacity-80">Private:</span> Code: <code className="bg-black/20 px-1 rounded">{db.getConfig('private_code', 'SHIVANI08')}</code></div>
                        <div><span className="font-bold opacity-80">Guest:</span> Just Name or Empty Code</div>
                     </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </GlassCard>
      </div>
      <BottomBackButton onClick={onBack} />
    </PageTransition>
  );
};

const TwoFAView = ({ error, twoFACode, setTwoFACode, handle2FASubmit, setShow2FA }: any) => (
  <div className="min-h-screen flex items-center justify-center p-4">
    <GlassCard className="max-w-md w-full p-8 text-center bg-[var(--bg-card)] border-[var(--accent-primary)]/30">
      <Lock className="w-12 h-12 text-[var(--accent-primary)] mx-auto mb-4" />
      <h2 className="text-2xl font-bold text-[var(--text-main)] mb-2">Security Verification</h2>
      <p className="mb-6 text-sm text-[var(--text-muted)]">Admin access requires 2FA. (Code: 123456)</p>
      <form onSubmit={handle2FASubmit} className="space-y-4">
        <GlassInput 
          value={twoFACode}
          onChange={(e) => setTwoFACode(e.target.value)}
          placeholder="000000"
          className="text-center text-2xl tracking-[0.5em] text-[var(--text-main)]"
          maxLength={6}
        />
        <GlowingButton className="w-full">Verify Identity</GlowingButton>
        <button onClick={() => setShow2FA(false)} type="button" className="text-xs text-[var(--accent-primary)] underline hover:text-[var(--accent-secondary)]">Back</button>
      </form>
    </GlassCard>
  </div>
);
