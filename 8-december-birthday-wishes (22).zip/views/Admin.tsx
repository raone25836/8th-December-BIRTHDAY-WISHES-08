
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { LogOut, Lock, Heart, ArrowLeft, Settings, Activity, Image as ImageIcon, MessageSquare, Radio, Mic, Volume2, Save, Play, Shield, Key, Terminal, AlertOctagon, Fingerprint, Eye, EyeOff, FileText, Users, Globe, Smartphone, UserX, UserCheck, RefreshCw, XCircle, Mail, Inbox, Filter, Check, CornerUpLeft, Trash2, CheckCircle, Search, Clock, Power, ShieldAlert, AlertTriangle, RotateCcw, Monitor, Laptop, Timer } from 'lucide-react';
import { PrivateDashboard } from './Private';
import { PublicPortal } from './Public';
import { PageTransition, SciFiCard, GlowingButton } from '../components/UI';
import { db, SecurityLog, BlockedUser, KnownUser } from '../services/database';
import { Wish, Story, PrivateWish } from '../types';
import { EditableText } from '../components/Editable';

interface AdminProps {
  onLogout: () => void;
}

type AdminView = 'HUB' | 'PRIVATE' | 'PUBLIC' | 'SECURITY' | 'INBOX' | 'SYSTEM';

export const AdminDashboard: React.FC<AdminProps> = ({ onLogout }) => {
  const [view, setView] = useState<AdminView>('HUB');
  const [stats, setStats] = useState(db.getSystemStats());
  const [broadcastMsg, setBroadcastMsg] = useState('');
  const [musicUrl, setMusicUrl] = useState('');
  const [showSettings, setShowSettings] = useState(false);

  useEffect(() => {
      const interval = setInterval(() => {
          setStats(db.getSystemStats());
      }, 2000);
      return () => clearInterval(interval);
  }, []);

  useEffect(() => {
      // Load global configs
      setBroadcastMsg(db.getConfig('global_broadcast_message', ''));
      setMusicUrl(db.getConfig('global_music_url', ''));
  }, []);

  const handleSaveBroadcast = () => {
      db.setConfig('global_broadcast_message', broadcastMsg);
      alert('Broadcast message updated!');
  };
  
  const handleSaveMusic = () => {
      db.setConfig('global_music_url', musicUrl);
      if(confirm("Music URL updated. Reload to hear changes?")) {
          window.location.reload();
      }
  };

  // RENDER THE HUB (Sci-Fi Command Center)
  if (view === 'HUB') {
    return (
      <PageTransition>
        <div className="min-h-screen bg-[#020617] text-cyan-100 font-sans p-4 relative overflow-hidden">
          {/* Background Grid */}
          <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-10 pointer-events-none"></div>
          <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-b from-cyan-900/10 to-[#020617] pointer-events-none"></div>

          {/* Header */}
          <header className="relative z-10 flex justify-between items-center mb-8 border-b border-cyan-800/50 pb-4">
             <div className="flex items-center gap-3">
                 <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse shadow-[0_0_10px_#22c55e]"></div>
                 <h1 className="text-2xl font-bold tracking-[0.2em] uppercase text-cyan-400">Command Center</h1>
             </div>
             <div className="flex gap-4">
                 <button onClick={() => setView('SYSTEM')} className="text-white bg-blue-600 hover:bg-blue-500 transition-colors flex items-center gap-2 text-xs uppercase font-bold px-4 py-2 rounded-lg shadow-lg"><Power size={14}/> System Controls</button>
                 <button onClick={() => setShowSettings(!showSettings)} className="text-cyan-600 hover:text-cyan-300 transition-colors"><Settings size={20}/></button>
                 <button onClick={onLogout} className="text-red-500 hover:text-red-300 transition-colors flex items-center gap-1 text-xs font-bold uppercase tracking-wider border border-red-900/50 px-3 py-1 rounded bg-red-950/30">
                    <LogOut size={14} /> Disconnect
                 </button>
             </div>
          </header>

          <div className="relative z-10 max-w-7xl mx-auto space-y-8">
             
             {/* Analytics HUD */}
             <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                 <StatCard icon={MessageSquare} label="Total Wishes" value={stats.wishes} color="text-pink-400" />
                 <StatCard icon={ImageIcon} label="Memories" value={stats.photos} color="text-blue-400" />
                 <StatCard icon={Lock} label="Pending" value={stats.pendingWishes} color="text-yellow-400" alert={stats.pendingWishes > 0} />
                 <StatCard icon={Activity} label="System Status" value="ONLINE" color="text-green-400" />
             </div>

             {/* Main Portals - Updated Grid Layout */}
             <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <PortalCard 
                   title="Private Portal" 
                   sub="Manage Surprises & Cards" 
                   icon={Lock} 
                   theme="indigo"
                   onClick={() => setView('PRIVATE')} 
                />
                <PortalCard 
                   title="Guest Portal" 
                   sub="Public Wall & Wishes" 
                   icon={Heart} 
                   theme="rose"
                   onClick={() => setView('PUBLIC')} 
                />
                <PortalCard 
                   title="Interaction Hub" 
                   sub="All Messages & Feedback" 
                   icon={Inbox} 
                   theme="amber"
                   onClick={() => setView('INBOX')} 
                   alert={stats.pendingWishes > 0}
                />
                <PortalCard 
                   title="Security" 
                   sub="Mainframe & Logs" 
                   icon={Shield} 
                   theme="emerald"
                   onClick={() => setView('SECURITY')} 
                   alert={stats.securityAlerts > 0}
                />
             </div>

             {/* Global Controls */}
             <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                 <SciFiCard className="p-6">
                     <h3 className="text-cyan-400 font-bold uppercase tracking-widest text-xs mb-4 flex items-center gap-2"><Radio size={14}/> Broadcast System</h3>
                     <div className="flex gap-2">
                         <input 
                            value={broadcastMsg} 
                            onChange={e => setBroadcastMsg(e.target.value)} 
                            placeholder="Type a message for all guests..." 
                            className="flex-1 bg-[#0b1221] border border-cyan-800 rounded px-3 py-2 text-sm text-cyan-100 outline-none focus:border-cyan-500 transition-colors"
                         />
                         <button onClick={handleSaveBroadcast} className="bg-cyan-700 hover:bg-cyan-600 text-white px-4 rounded transition-colors"><Save size={16}/></button>
                     </div>
                     <p className="text-[10px] text-cyan-600 mt-2">Leave empty to disable. Appears as a popup for all users.</p>
                 </SciFiCard>

                 <SciFiCard className="p-6">
                     <h3 className="text-cyan-400 font-bold uppercase tracking-widest text-xs mb-4 flex items-center gap-2"><Volume2 size={14}/> Audio Stream Source</h3>
                     <div className="flex gap-2">
                         <input 
                            value={musicUrl} 
                            onChange={e => setMusicUrl(e.target.value)} 
                            placeholder="Paste MP3 URL..." 
                            className="flex-1 bg-[#0b1221] border border-cyan-800 rounded px-3 py-2 text-sm text-cyan-100 outline-none focus:border-cyan-500 transition-colors"
                         />
                         <button onClick={handleSaveMusic} className="bg-cyan-700 hover:bg-cyan-600 text-white px-4 rounded transition-colors"><Save size={16}/></button>
                     </div>
                     <p className="text-[10px] text-cyan-600 mt-2">Overrides default background music.</p>
                 </SciFiCard>
             </div>
             
             <div className="text-center pt-8 opacity-30 text-[10px] font-mono">
                 SYSTEM ID: 08-DEC-SHIVANI-CORE-V2
             </div>
          </div>

          <AnimatePresence>
              {showSettings && (
                  <motion.div initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}} className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4">
                      <SciFiCard className="max-w-md w-full p-8 border-red-500/30">
                          <h3 className="text-red-400 font-bold text-xl mb-4">Danger Zone</h3>
                          <p className="text-gray-400 text-sm mb-6">Resetting the system will wipe all wishes, memories, and photos permanently.</p>
                          <GlowingButton 
                            variant="danger" 
                            className="w-full" 
                            onClick={() => { if(confirm("FINAL WARNING: DELETE EVERYTHING?")) { db.clearAllData(); } }}
                          >
                             MASTER RESET
                          </GlowingButton>
                          <button onClick={() => setShowSettings(false)} className="w-full mt-4 text-sm text-gray-500 hover:text-white">Cancel</button>
                      </SciFiCard>
                  </motion.div>
              )}
          </AnimatePresence>
        </div>
      </PageTransition>
    );
  }

  // WRAPPERS FOR EDIT MODE
  if (view === 'PRIVATE') {
    return (
      <div className="relative">
         <AdminOverlay onBack={() => setView('HUB')} label="Editing Private Portal" />
         <PrivateDashboard onLogout={() => {}} isAdmin={true} onExit={() => setView('HUB')} />
      </div>
    );
  }

  if (view === 'PUBLIC') {
    return (
      <div className="relative">
         <AdminOverlay onBack={() => setView('HUB')} label="Editing Guest Portal" />
         <PublicPortal onLogout={() => {}} isAdmin={true} onExit={() => setView('HUB')} />
      </div>
    );
  }
  
  if (view === 'SECURITY') {
      return (
          <div className="relative">
             <AdminOverlay onBack={() => setView('HUB')} label="Security Mainframe" />
             <SecurityPanel />
          </div>
      )
  }

  if (view === 'INBOX') {
      return (
          <div className="relative">
             <AdminOverlay onBack={() => setView('HUB')} label="User Interaction Center" />
             <InboxPanel />
          </div>
      )
  }

  if (view === 'SYSTEM') {
      return (
          <div className="relative bg-white min-h-screen text-gray-900">
             <SimpleAdminOverlay onBack={() => setView('HUB')} label="System Controls" />
             <SystemPanel />
          </div>
      )
  }

  return null;
};

// --- SIMPLIFIED SYSTEM CONTROL PANEL (CLEAN UI) ---
const SystemPanel = () => {
    const [sysState, setSysState] = useState(db.getSystemState());

    useEffect(() => {
        // Poll for updates to ensure UI reflects current DB state
        const interval = setInterval(() => {
            setSysState(db.getSystemState());
        }, 1000);
        return () => clearInterval(interval);
    }, []);

    const toggleLock = (type: 'GUEST' | 'PRIVATE' | 'SYSTEM', val: boolean) => {
        db.toggleSystemLock(type, val);
        setSysState(db.getSystemState()); // Instant UI update
    }

    const handleRenewPrivate = () => {
        if(confirm("Confirm Renew? This will reload the Private User's screen and lock all surprises again.")) {
            db.renewPrivateExperience();
            // Force reload for everyone to apply changes
            db.forceLogoutAll(); 
            alert("Success: Experience Renewed. Surprises re-locked.");
        }
    }

    const handleResetGallery = () => {
        if(confirm("Delete ALL photos? This cannot be undone.")) {
            db.resetGallery();
            alert("Gallery Reset Complete.");
        }
    }

    const handleLogoutAll = () => {
        if(confirm("Log everyone out immediately?")) {
            db.forceLogoutAll();
            alert("All users logged out.");
        }
    }

    return (
        <div className="max-w-4xl mx-auto p-6 pt-20">
             
             <div className="mb-8">
                 <h2 className="text-3xl font-bold text-gray-900 mb-2">System Controls</h2>
                 <p className="text-gray-500">Simple controls to manage portal access and reset data.</p>
             </div>

             <div className="space-y-8">
                 
                 {/* 1. RESET & RENEW SECTION */}
                 <div className="bg-gray-100 p-6 rounded-2xl border border-gray-200 shadow-sm">
                     <h3 className="text-xl font-bold text-gray-800 mb-6 flex items-center gap-2">
                        <RotateCcw className="text-blue-600"/> Reset Options (Renew)
                     </h3>
                     
                     <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                         {/* Renew Private */}
                         <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm flex flex-col justify-between">
                             <div>
                                <h4 className="font-bold text-lg text-gray-900 mb-2">Renew Private Portal</h4>
                                <p className="text-sm text-gray-500 mb-4">Re-locks all gift boxes & surprises. Use this to give Shivani a "First Time" experience again.</p>
                             </div>
                             <button onClick={handleRenewPrivate} className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-lg transition-colors">
                                 Renew Experience
                             </button>
                         </div>

                         {/* Reset Photos */}
                         <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm flex flex-col justify-between">
                             <div>
                                <h4 className="font-bold text-lg text-gray-900 mb-2">Reset Gallery</h4>
                                <p className="text-sm text-gray-500 mb-4">Deletes all uploaded photos. Restores the default album covers.</p>
                             </div>
                             <button onClick={handleResetGallery} className="w-full py-3 bg-orange-600 hover:bg-orange-700 text-white font-bold rounded-lg transition-colors">
                                 Reset Photos
                             </button>
                         </div>

                         {/* Logout All */}
                         <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm flex flex-col justify-between">
                             <div>
                                <h4 className="font-bold text-lg text-gray-900 mb-2">Logout Everyone</h4>
                                <p className="text-sm text-gray-500 mb-4">Instantly logs out all active users from the website.</p>
                             </div>
                             <button onClick={handleLogoutAll} className="w-full py-3 bg-gray-800 hover:bg-black text-white font-bold rounded-lg transition-colors">
                                 Force Logout
                             </button>
                         </div>
                     </div>
                 </div>

                 {/* 2. EMERGENCY LOCKS */}
                 <div className="bg-red-50 p-6 rounded-2xl border border-red-100 shadow-sm">
                     <h3 className="text-xl font-bold text-red-800 mb-6 flex items-center gap-2">
                        <Lock className="text-red-600"/> Emergency Locks
                     </h3>

                     <div className="space-y-4">
                         
                         {/* Guest Lock */}
                         <div className="flex items-center justify-between p-4 bg-white rounded-xl border border-gray-200 shadow-sm">
                             <div>
                                 <h4 className="font-bold text-gray-900">Guest Portal Access</h4>
                                 <p className="text-sm text-gray-500">Turn OFF to stop guests from entering.</p>
                             </div>
                             <LockSwitch 
                                label="Guest Access" 
                                isLocked={sysState.guestLocked} 
                                onToggle={(val) => toggleLock('GUEST', val)}
                             />
                         </div>

                         {/* Private Lock */}
                         <div className="flex items-center justify-between p-4 bg-white rounded-xl border border-gray-200 shadow-sm">
                             <div>
                                 <h4 className="font-bold text-gray-900">Private Portal Access</h4>
                                 <p className="text-sm text-gray-500">Turn OFF to stop the birthday girl from entering.</p>
                             </div>
                             <LockSwitch 
                                label="Private Access" 
                                isLocked={sysState.privateLocked} 
                                onToggle={(val) => toggleLock('PRIVATE', val)}
                             />
                         </div>

                         {/* System Lock */}
                         <div className="flex items-center justify-between p-4 bg-red-100 rounded-xl border border-red-200 shadow-sm">
                             <div>
                                 <h4 className="font-bold text-red-900">WHOLE WEBSITE LOCKDOWN</h4>
                                 <p className="text-sm text-red-700">Shuts down the entire site. Shows maintenance screen to everyone.</p>
                             </div>
                             <LockSwitch 
                                label="System" 
                                isLocked={sysState.systemLocked} 
                                onToggle={(val) => toggleLock('SYSTEM', val)}
                                isDanger
                             />
                         </div>

                     </div>
                 </div>

             </div>
        </div>
    )
}

// Simple Toggle Switch Component
const LockSwitch = ({ label, isLocked, onToggle, isDanger }: { label: string, isLocked: boolean, onToggle: (v: boolean) => void, isDanger?: boolean }) => {
    return (
        <div className="flex items-center gap-3">
             <span className={`text-sm font-bold uppercase tracking-wider ${isLocked ? 'text-red-600' : 'text-green-600'}`}>
                 {isLocked ? 'LOCKED' : 'ACTIVE'}
             </span>
             <button 
                onClick={() => onToggle(!isLocked)}
                className={`w-16 h-8 rounded-full p-1 transition-colors relative ${isLocked ? 'bg-red-500' : 'bg-green-500'}`}
             >
                 <div className={`w-6 h-6 bg-white rounded-full shadow-md transform transition-transform ${isLocked ? 'translate-x-8' : 'translate-x-0'}`}></div>
             </button>
        </div>
    )
}

// Simple Overlay for Admin View
const SimpleAdminOverlay = ({ onBack, label }: { onBack: () => void, label: string }) => (
  <div className="fixed top-0 inset-x-0 z-[100] bg-white border-b border-gray-200 p-3 flex justify-between items-center px-6 shadow-sm">
     <div className="flex items-center gap-3">
        <span className="font-bold text-gray-900 uppercase tracking-widest text-sm">{label}</span>
     </div>
     <button onClick={onBack} className="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 text-sm font-bold rounded-lg transition-colors flex items-center gap-2">
         <ArrowLeft size={16} /> Back to Dashboard
     </button>
  </div>
);

// --- NEW INBOX PANEL COMPONENT ---

const InboxPanel = () => {
    const [items, setItems] = useState<any[]>([]);
    const [filter, setFilter] = useState<'ALL' | 'WISH' | 'MEMORY' | 'PENDING'>('ALL');
    const [search, setSearch] = useState('');
    const [replyModal, setReplyModal] = useState<Story | null>(null);
    const [replyText, setReplyText] = useState('');

    useEffect(() => {
        refreshData();
        const interval = setInterval(refreshData, 3000);
        return () => clearInterval(interval);
    }, []);

    const refreshData = () => {
        const wishes = db.getWishes().map(w => ({ ...w, type: 'WISH' }));
        const stories = db.getStories().filter(s => s.type === 'GUEST_MESSAGE').map(s => ({ ...s, type: 'MEMORY' }));
        const privateWishes = db.getPrivateWishes().map(p => ({ ...p, type: 'PRIVATE', senderName: 'Private User', message: p.wish, category: 'Private' }));
        
        // Combine and sort by timestamp desc
        const combined = [...wishes, ...stories, ...privateWishes].sort((a, b) => b.timestamp - a.timestamp);
        setItems(combined);
    };

    const handleDelete = (id: string, type: string) => {
        if(confirm("Delete this interaction permanently?")) {
            if(type === 'WISH') db.deleteWish(id);
            if(type === 'MEMORY') db.deleteStory(id);
            // Private wishes delete logic not implemented in service yet, effectively read-only here or need enhancement
            refreshData();
        }
    };

    const toggleApproval = (id: string) => {
        db.toggleApproval(id);
        refreshData();
    };

    const handleReply = () => {
        if(replyModal && replyText) {
            db.updateStoryReply(replyModal.id, replyText);
            setReplyModal(null);
            setReplyText('');
            refreshData();
        }
    };

    const openReply = (item: any) => {
        setReplyModal(item);
        setReplyText(item.replyContent || '');
    };

    const filteredItems = items.filter(item => {
        const matchesFilter = 
            filter === 'ALL' ? true :
            filter === 'PENDING' ? (item.type === 'WISH' && !item.isApproved) :
            item.type === filter;
        
        const matchesSearch = 
            (item.senderName || item.author || '').toLowerCase().includes(search.toLowerCase()) ||
            (item.message || item.content || '').toLowerCase().includes(search.toLowerCase());

        return matchesFilter && matchesSearch;
    });

    return (
        <div className="min-h-screen bg-[#1e1b4b] text-indigo-100 font-sans p-4 pt-20 relative">
             <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/dark-matter.png')] opacity-20 pointer-events-none"></div>
             
             <div className="max-w-6xl mx-auto relative z-10">
                 
                 {/* Header Stats */}
                 <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
                     <div className="bg-indigo-950/50 p-4 rounded-xl border border-indigo-500/30 flex items-center justify-between">
                         <div>
                             <p className="text-xs uppercase tracking-widest text-indigo-400">Total Interactions</p>
                             <h3 className="text-2xl font-bold text-white">{items.length}</h3>
                         </div>
                         <Inbox className="text-indigo-400 opacity-50"/>
                     </div>
                     <div className="bg-indigo-950/50 p-4 rounded-xl border border-indigo-500/30 flex items-center justify-between">
                         <div>
                             <p className="text-xs uppercase tracking-widest text-yellow-400">Pending Wishes</p>
                             <h3 className="text-2xl font-bold text-yellow-400">{items.filter(i => i.type === 'WISH' && !i.isApproved).length}</h3>
                         </div>
                         <Clock className="text-yellow-400 opacity-50"/>
                     </div>
                     <div className="bg-indigo-950/50 p-4 rounded-xl border border-indigo-500/30 flex items-center justify-between">
                         <div>
                             <p className="text-xs uppercase tracking-widest text-pink-400">Guest Memories</p>
                             <h3 className="text-2xl font-bold text-pink-400">{items.filter(i => i.type === 'MEMORY').length}</h3>
                         </div>
                         <ImageIcon className="text-pink-400 opacity-50"/>
                     </div>
                     <div className="bg-indigo-950/50 p-4 rounded-xl border border-indigo-500/30 flex items-center justify-between">
                         <div>
                             <p className="text-xs uppercase tracking-widest text-emerald-400">Replied</p>
                             <h3 className="text-2xl font-bold text-emerald-400">{items.filter(i => i.isReplied).length}</h3>
                         </div>
                         <CheckCircle className="text-emerald-400 opacity-50"/>
                     </div>
                 </div>

                 {/* Controls */}
                 <div className="flex flex-col md:flex-row gap-4 mb-6 bg-black/20 p-4 rounded-xl border border-white/10 backdrop-blur-sm">
                     <div className="flex gap-2 overflow-x-auto pb-2 md:pb-0">
                         {(['ALL', 'WISH', 'MEMORY', 'PENDING'] as const).map(f => (
                             <button
                                key={f}
                                onClick={() => setFilter(f)}
                                className={`px-4 py-2 rounded-lg text-xs font-bold uppercase tracking-wider transition-all ${filter === f ? 'bg-indigo-600 text-white shadow-lg' : 'bg-indigo-900/30 text-indigo-300 hover:bg-indigo-900/50'}`}
                             >
                                 {f}
                             </button>
                         ))}
                     </div>
                     <div className="flex-1 relative">
                         <Search className="absolute left-3 top-2.5 text-indigo-400" size={16}/>
                         <input 
                            value={search}
                            onChange={e => setSearch(e.target.value)}
                            placeholder="Search sender or message content..."
                            className="w-full bg-indigo-950/50 border border-indigo-500/30 rounded-lg pl-10 pr-4 py-2 text-sm text-indigo-100 placeholder-indigo-400/50 focus:outline-none focus:border-indigo-400 transition-colors"
                         />
                     </div>
                 </div>

                 {/* Messages List */}
                 <div className="grid grid-cols-1 gap-4">
                     {filteredItems.length === 0 && (
                         <div className="text-center py-20 opacity-50 border-2 border-dashed border-indigo-500/30 rounded-2xl">
                             <Inbox size={48} className="mx-auto mb-4"/>
                             <p>No messages found matching your criteria.</p>
                         </div>
                     )}

                     {filteredItems.map(item => (
                         <motion.div 
                            key={item.id}
                            initial={{ opacity: 0, y: 10 }}
                            animate={{ opacity: 1, y: 0 }}
                            className={`relative p-6 rounded-2xl border backdrop-blur-md transition-all ${
                                item.type === 'WISH' 
                                    ? item.isApproved ? 'bg-indigo-900/20 border-indigo-500/30' : 'bg-yellow-900/10 border-yellow-500/30'
                                : item.type === 'MEMORY'
                                    ? 'bg-pink-900/10 border-pink-500/30'
                                    : 'bg-emerald-900/10 border-emerald-500/30'
                            }`}
                         >
                             {/* Badge */}
                             <div className="absolute top-4 right-4 flex gap-2">
                                 {item.type === 'WISH' && (
                                     <span className={`px-2 py-1 rounded text-[10px] font-bold uppercase tracking-widest border ${item.isApproved ? 'bg-green-500/20 text-green-400 border-green-500/30' : 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30'}`}>
                                         {item.isApproved ? 'Publicly Visible' : 'Pending Approval'}
                                     </span>
                                 )}
                                 <span className="px-2 py-1 rounded bg-black/30 border border-white/10 text-[10px] font-bold uppercase tracking-widest text-white/50">
                                     {item.type}
                                 </span>
                             </div>

                             {/* Content Header */}
                             <div className="flex items-start gap-4 mb-4">
                                 <div className={`w-12 h-12 rounded-full flex items-center justify-center text-xl font-bold shadow-lg ${
                                     item.type === 'WISH' ? 'bg-gradient-to-br from-indigo-500 to-blue-600' :
                                     item.type === 'MEMORY' ? 'bg-gradient-to-br from-pink-500 to-rose-600' :
                                     'bg-gradient-to-br from-emerald-500 to-teal-600'
                                 }`}>
                                     {(item.senderName || item.author || 'P')[0]?.toUpperCase()}
                                 </div>
                                 <div>
                                     <h3 className="text-lg font-bold text-white">{item.senderName || item.author || 'Private User'}</h3>
                                     <div className="flex items-center gap-2 text-xs text-white/50 font-mono">
                                         <span>{new Date(item.timestamp).toLocaleString()}</span>
                                         <span>•</span>
                                         <span>{item.category || (item.type === 'MEMORY' ? 'Shared Memory' : 'Private Wish')}</span>
                                     </div>
                                 </div>
                             </div>

                             {/* Message Body */}
                             <div className="bg-black/20 p-4 rounded-xl border border-white/5 text-indigo-100 leading-relaxed font-serif italic mb-4">
                                 "{item.message || item.content}"
                             </div>
                             
                             {/* Photo Attachment */}
                             {item.photoUrl && (
                                 <div className="mb-4">
                                     <img src={item.photoUrl} alt="Attached" className="h-32 rounded-lg border border-white/10 object-cover"/>
                                 </div>
                             )}

                             {/* Admin Reply Display */}
                             {item.isReplied && (
                                 <div className="mb-4 ml-8 p-3 bg-emerald-900/20 border-l-2 border-emerald-500 rounded-r-lg">
                                     <p className="text-xs text-emerald-400 font-bold uppercase mb-1">Your Reply:</p>
                                     <p className="text-sm text-emerald-100">"{item.replyContent}"</p>
                                 </div>
                             )}

                             {/* Actions Toolbar */}
                             <div className="flex flex-wrap gap-2 pt-2 border-t border-white/5">
                                 {item.type === 'WISH' && (
                                     <button 
                                        onClick={() => toggleApproval(item.id)}
                                        className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-colors ${
                                            item.isApproved 
                                            ? 'bg-yellow-500/10 text-yellow-400 hover:bg-yellow-500/20 border border-yellow-500/30' 
                                            : 'bg-green-500/10 text-green-400 hover:bg-green-500/20 border border-green-500/30'
                                        }`}
                                     >
                                         {item.isApproved ? <><XCircle size={14}/> Unapprove</> : <><CheckCircle size={14}/> Approve</>}
                                     </button>
                                 )}

                                 {item.type === 'MEMORY' && (
                                     <button 
                                        onClick={() => openReply(item)}
                                        className="px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 bg-blue-500/10 text-blue-400 hover:bg-blue-500/20 border border-blue-500/30"
                                     >
                                         <CornerUpLeft size={14}/> {item.isReplied ? 'Edit Reply' : 'Reply'}
                                     </button>
                                 )}

                                 <button 
                                    onClick={() => handleDelete(item.id, item.type)}
                                    className="px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 bg-red-500/10 text-red-400 hover:bg-red-500/20 border border-red-500/30 ml-auto"
                                 >
                                     <Trash2 size={14}/> Delete
                                 </button>
                             </div>
                         </motion.div>
                     ))}
                 </div>

                 {/* Reply Modal */}
                 <AnimatePresence>
                     {replyModal && (
                         <motion.div initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}} className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4">
                             <motion.div initial={{scale:0.9}} animate={{scale:1}} exit={{scale:0.9}} className="bg-[#0f172a] p-6 rounded-2xl max-w-md w-full border border-indigo-500/30 shadow-2xl">
                                 <h3 className="text-xl font-bold text-white mb-4">Reply to {replyModal.author}</h3>
                                 <div className="bg-black/30 p-3 rounded-lg text-sm text-indigo-200 mb-4 max-h-32 overflow-y-auto italic">
                                     "{replyModal.content}"
                                 </div>
                                 <textarea 
                                    value={replyText}
                                    onChange={e => setReplyText(e.target.value)}
                                    placeholder="Write your heartfelt reply..."
                                    className="w-full bg-indigo-950/30 border border-indigo-500/30 rounded-lg p-3 text-white outline-none focus:border-indigo-400 h-32 mb-4"
                                 />
                                 <div className="flex justify-end gap-2">
                                     <button onClick={() => setReplyModal(null)} className="px-4 py-2 text-indigo-300 hover:text-white">Cancel</button>
                                     <button onClick={handleReply} className="px-6 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg font-bold flex items-center gap-2">
                                         <CornerUpLeft size={16}/> Send Reply
                                     </button>
                                 </div>
                             </motion.div>
                         </motion.div>
                     )}
                 </AnimatePresence>

             </div>
        </div>
    );
};

// --- SECURITY PANEL COMPONENT ---

const SecurityPanel = () => {
    const [adminCode, setAdminCode] = useState('');
    const [privateCode, setPrivateCode] = useState('');
    const [showAdmin, setShowAdmin] = useState(false);
    const [showPrivate, setShowPrivate] = useState(false);
    const [logs, setLogs] = useState<SecurityLog[]>([]);
    const [activeSessions, setActiveSessions] = useState<SecurityLog[]>([]);
    const [blockedUsers, setBlockedUsers] = useState<BlockedUser[]>([]);
    const [knownUsers, setKnownUsers] = useState<KnownUser[]>([]); // New Advanced Tracking
    const [activeTab, setActiveTab] = useState<'OVERVIEW' | 'LOGS' | 'ACCESS' | 'USERS' | 'TRACKING'>('OVERVIEW');
    const [refreshCount, setRefreshCount] = useState(0);

    // Refresh Data
    useEffect(() => {
        setAdminCode(db.getConfig('admin_code', 'SHIVAM123'));
        setPrivateCode(db.getConfig('private_code', 'SHIVANI08'));
        setLogs(db.getSecurityLogs());
        setActiveSessions(db.getActiveSessions());
        setBlockedUsers(db.getBlockedUsers());
        setKnownUsers(db.getKnownUsers());

        const interval = setInterval(() => {
            setLogs(db.getSecurityLogs());
            setActiveSessions(db.getActiveSessions());
            setBlockedUsers(db.getBlockedUsers());
            setKnownUsers(db.getKnownUsers());
        }, 2000); // Live update every 2s

        return () => clearInterval(interval);
    }, [refreshCount]);

    const handleSaveAdmin = () => {
        db.setConfig('admin_code', adminCode);
        db.logSecurityEvent('ADMIN_ACTION', 'Admin access code changed', 'Admin', 'WARNING');
        alert('Admin Access Code Updated');
    };

    const handleSavePrivate = () => {
        db.setConfig('private_code', privateCode);
        db.logSecurityEvent('ADMIN_ACTION', 'Private access code changed', 'Admin', 'WARNING');
        alert('Private Access Code Updated');
    };

    const blockUser = (identifier: string) => {
        if(confirm(`Are you sure you want to BLOCK ${identifier}? They will be logged out immediately.`)) {
            db.blockUser(identifier, 'Admin Manual Block');
            setRefreshCount(c => c + 1);
        }
    }

    const unblockUser = (identifier: string) => {
        db.unblockUser(identifier);
        setRefreshCount(c => c + 1);
    }

    return (
        <div className="min-h-screen bg-[#051c14] text-emerald-100 font-mono p-4 pt-20 relative overflow-hidden">
             <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/circuit-board.png')] opacity-5 pointer-events-none"></div>
             
             <div className="max-w-7xl mx-auto space-y-6 relative z-10">
                 
                 {/* Header & Tabs */}
                 <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-emerald-800 pb-6">
                     <div className="flex items-center gap-4">
                         <div className="relative">
                            <Shield size={48} className="text-emerald-500 animate-pulse"/>
                            <div className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full animate-ping"></div>
                         </div>
                         <div>
                             <h1 className="text-3xl font-bold text-emerald-400 tracking-widest uppercase">Security Mainframe</h1>
                             <p className="text-emerald-700 text-xs tracking-[0.3em]">CLEARANCE LEVEL 5 • ENCRYPTED</p>
                         </div>
                     </div>
                     
                     <div className="flex flex-wrap gap-2 p-1 bg-[#0a1f18] rounded-lg border border-emerald-900">
                         {['OVERVIEW', 'LOGS', 'ACCESS', 'USERS', 'TRACKING'].map((tab) => (
                             <button 
                                key={tab}
                                onClick={() => setActiveTab(tab as any)}
                                className={`px-4 py-2 rounded text-xs font-bold uppercase tracking-wider transition-all ${activeTab === tab ? 'bg-emerald-600 text-white shadow-lg' : 'text-emerald-600 hover:bg-emerald-900/50'}`}
                             >
                                {tab === 'TRACKING' ? 'User Insights' : tab}
                             </button>
                         ))}
                     </div>
                 </div>

                 {/* TAB CONTENT: OVERVIEW */}
                 {activeTab === 'OVERVIEW' && (
                     <div className="grid grid-cols-1 md:grid-cols-3 gap-6 animate-fadeIn">
                         {/* Threat Map Visual (Simulated) */}
                         <SciFiCard className="col-span-1 md:col-span-2 p-6 bg-black/40 border-emerald-900/50 min-h-[300px] flex flex-col relative overflow-hidden">
                             <h3 className="text-emerald-400 font-bold uppercase tracking-widest text-xs flex items-center gap-2 mb-4"><Globe size={14}/> Active Connections Map</h3>
                             <div className="flex-1 relative border border-emerald-900/30 rounded bg-[#020a07] opacity-80 grid place-items-center">
                                 {/* Grid Lines */}
                                 <div className="absolute inset-0 bg-[linear-gradient(rgba(16,185,129,0.1)_1px,transparent_1px),linear-gradient(90deg,rgba(16,185,129,0.1)_1px,transparent_1px)] bg-[size:40px_40px]"></div>
                                 <div className="text-emerald-800 text-xs animate-pulse">SCANNING GLOBAL NETWORK NODES...</div>
                                 {/* Random Dots representing users */}
                                 {activeSessions.map((s, i) => (
                                     <div key={i} className="absolute w-2 h-2 bg-green-500 rounded-full shadow-[0_0_10px_#22c55e]" style={{top: `${Math.random()*80 + 10}%`, left: `${Math.random()*80 + 10}%`}}>
                                         <div className="absolute -inset-2 border border-green-500/50 rounded-full animate-ping"></div>
                                     </div>
                                 ))}
                             </div>
                         </SciFiCard>

                         {/* Quick Stats */}
                         <div className="space-y-4">
                             <SciFiCard className="p-4 flex items-center justify-between bg-[#0a1f18]">
                                 <div>
                                     <span className="text-3xl font-bold text-white block">{activeSessions.length}</span>
                                     <span className="text-[10px] text-emerald-500 uppercase tracking-widest">Active Users</span>
                                 </div>
                                 <Users className="text-emerald-600" size={32}/>
                             </SciFiCard>
                             <SciFiCard className="p-4 flex items-center justify-between bg-[#0a1f18]">
                                 <div>
                                     <span className="text-3xl font-bold text-red-400 block">{blockedUsers.length}</span>
                                     <span className="text-[10px] text-red-500 uppercase tracking-widest">Blacklisted</span>
                                 </div>
                                 <UserX className="text-red-600" size={32}/>
                             </SciFiCard>
                             <SciFiCard className="p-4 flex items-center justify-between bg-[#0a1f18]">
                                 <div>
                                     <span className="text-3xl font-bold text-yellow-400 block">{logs.filter(l => l.status === 'CRITICAL').length}</span>
                                     <span className="text-[10px] text-yellow-500 uppercase tracking-widest">Threats Detected</span>
                                 </div>
                                 <AlertOctagon className="text-yellow-600" size={32}/>
                             </SciFiCard>
                         </div>
                     </div>
                 )}

                 {/* TAB CONTENT: LOGS */}
                 {activeTab === 'LOGS' && (
                     <SciFiCard className="p-0 overflow-hidden bg-black/80 border-emerald-900/50 min-h-[500px] flex flex-col animate-fadeIn">
                        <div className="p-3 bg-[#0a1f18] border-b border-emerald-900/50 flex justify-between items-center">
                            <h3 className="text-emerald-400 font-bold uppercase tracking-widest text-xs flex items-center gap-2"><Terminal size={14}/> Live System Event Stream</h3>
                            <div className="flex gap-2 text-[10px] font-mono text-emerald-600">
                                <span>SSH-SECURE</span>
                                <span>PORT: 443</span>
                            </div>
                        </div>
                        <div className="flex-1 p-4 font-mono text-xs overflow-y-auto max-h-[500px] custom-scrollbar space-y-1">
                            {logs.map((log) => (
                                <div key={log.id} className="flex gap-4 hover:bg-emerald-900/10 p-1 rounded transition-colors group">
                                    <span className="text-emerald-700 w-20 shrink-0">{new Date(log.timestamp).toLocaleTimeString()}</span>
                                    <span className={`w-24 shrink-0 font-bold ${log.status === 'CRITICAL' ? 'text-red-500' : log.status === 'WARNING' ? 'text-yellow-500' : log.status === 'SUCCESS' ? 'text-green-500' : 'text-blue-400'}`}>
                                        [{log.type}]
                                    </span>
                                    <span className="text-emerald-300 w-32 shrink-0 truncate" title={log.user}>{log.user}</span>
                                    <span className="text-emerald-400/70 flex-1 truncate">{log.details}</span>
                                    <span className="text-emerald-800 text-[10px] hidden md:block">{log.ip}</span>
                                </div>
                            ))}
                            {logs.length === 0 && <div className="text-emerald-800 animate-pulse">_ Waiting for incoming data streams...</div>}
                        </div>
                     </SciFiCard>
                 )}

                 {/* TAB CONTENT: ACCESS */}
                 {activeTab === 'ACCESS' && (
                     <div className="grid grid-cols-1 md:grid-cols-2 gap-6 animate-fadeIn">
                         <SciFiCard className="p-6 bg-black/60 border-emerald-900/50">
                             <div className="flex items-center gap-3 mb-6">
                                 <Key size={20} className="text-emerald-500"/>
                                 <h3 className="text-emerald-300 font-bold uppercase tracking-wider">Admin Override</h3>
                             </div>
                             <div className="space-y-4">
                                 <label className="text-xs text-emerald-600 uppercase tracking-widest block">Master Passcode</label>
                                 <div className="flex gap-2">
                                     <div className="relative flex-1">
                                         <input 
                                            type={showAdmin ? "text" : "password"} 
                                            value={adminCode} 
                                            onChange={e => setAdminCode(e.target.value)}
                                            className="w-full bg-[#0a2f23] border border-emerald-800 rounded px-4 py-3 text-emerald-300 outline-none focus:border-emerald-500 tracking-widest font-bold"
                                         />
                                         <button onClick={() => setShowAdmin(!showAdmin)} className="absolute right-3 top-3 text-emerald-700 hover:text-emerald-400">
                                             {showAdmin ? <EyeOff size={16}/> : <Eye size={16}/>}
                                         </button>
                                     </div>
                                     <button onClick={handleSaveAdmin} className="bg-emerald-800 hover:bg-emerald-700 text-white px-4 rounded transition-colors"><Save size={20}/></button>
                                 </div>
                                 <p className="text-[10px] text-emerald-700/80 mt-2">* Changing this will log a critical security event.</p>
                             </div>
                         </SciFiCard>

                         <SciFiCard className="p-6 bg-black/60 border-emerald-900/50">
                             <div className="flex items-center gap-3 mb-6">
                                 <Fingerprint size={20} className="text-emerald-500"/>
                                 <h3 className="text-emerald-300 font-bold uppercase tracking-wider">Private Access</h3>
                             </div>
                             <div className="space-y-4">
                                 <label className="text-xs text-emerald-600 uppercase tracking-widest block">User Passcode</label>
                                 <div className="flex gap-2">
                                     <div className="relative flex-1">
                                         <input 
                                            type={showPrivate ? "text" : "password"} 
                                            value={privateCode} 
                                            onChange={e => setPrivateCode(e.target.value)}
                                            className="w-full bg-[#0a2f23] border border-emerald-800 rounded px-4 py-3 text-emerald-300 outline-none focus:border-emerald-500 tracking-widest font-bold"
                                         />
                                         <button onClick={() => setShowPrivate(!showPrivate)} className="absolute right-3 top-3 text-emerald-700 hover:text-emerald-400">
                                             {showPrivate ? <EyeOff size={16}/> : <Eye size={16}/>}
                                         </button>
                                     </div>
                                     <button onClick={handleSavePrivate} className="bg-emerald-800 hover:bg-emerald-700 text-white px-4 rounded transition-colors"><Save size={20}/></button>
                                 </div>
                                 <p className="text-[10px] text-emerald-700/80 mt-2">* Used by Shivani for VIP portal access.</p>
                             </div>
                         </SciFiCard>
                         
                         <SciFiCard className="col-span-1 md:col-span-2 p-6 flex justify-between items-center bg-red-950/20 border-red-900/50">
                             <div>
                                 <h3 className="text-red-400 font-bold uppercase tracking-wider text-sm flex items-center gap-2"><Lock size={16}/> Emergency Lockdown</h3>
                                 <p className="text-red-300/60 text-xs mt-1">Disconnect all active sessions immediately (Soft Ban).</p>
                             </div>
                             <button onClick={() => {if(confirm("Kick all active users?")) { activeSessions.forEach(s => blockUser(s.user)); }}} className="px-6 py-2 bg-red-900 text-white text-xs font-bold uppercase rounded border border-red-500 hover:bg-red-800 transition-colors">INITIATE LOCKDOWN</button>
                         </SciFiCard>
                     </div>
                 )}

                 {/* TAB CONTENT: USERS */}
                 {activeTab === 'USERS' && (
                     <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 animate-fadeIn">
                         {/* Active Users List */}
                         <SciFiCard className="p-0 overflow-hidden bg-black/60 border-emerald-900/50 min-h-[400px]">
                             <div className="p-4 bg-[#0a1f18] border-b border-emerald-900/50 font-bold text-emerald-400 uppercase tracking-widest text-xs">Active Sessions</div>
                             <div className="p-4 space-y-4">
                                 {activeSessions.length === 0 && <p className="text-emerald-800 text-center italic py-4">No active users detected.</p>}
                                 {activeSessions.map((session, i) => (
                                     <div key={i} className="flex items-center justify-between p-3 bg-emerald-900/10 rounded border border-emerald-500/20">
                                         <div className="flex items-center gap-3">
                                             <div className="w-8 h-8 rounded-full bg-emerald-800 flex items-center justify-center text-emerald-200 font-bold">{session.user[0]?.toUpperCase()}</div>
                                             <div>
                                                 <h4 className="text-emerald-300 text-sm font-bold">{session.user}</h4>
                                                 <div className="flex items-center gap-2 text-[10px] text-emerald-600">
                                                     <Smartphone size={10} /> {session.device.substring(0, 20)}
                                                 </div>
                                             </div>
                                         </div>
                                         <div className="flex flex-col items-end gap-1">
                                             <span className="text-[10px] text-green-500 font-bold bg-green-900/20 px-1 rounded border border-green-800">ONLINE</span>
                                             <button onClick={() => blockUser(session.user)} className="text-[10px] text-red-400 hover:text-red-200 underline uppercase tracking-wider">Block Access</button>
                                         </div>
                                     </div>
                                 ))}
                             </div>
                         </SciFiCard>

                         {/* Blocked Users List */}
                         <SciFiCard className="p-0 overflow-hidden bg-black/60 border-red-900/30 min-h-[400px]">
                             <div className="p-4 bg-red-950/20 border-b border-red-900/30 font-bold text-red-400 uppercase tracking-widest text-xs">Blacklisted Entities</div>
                             <div className="p-4 space-y-4">
                                 {blockedUsers.length === 0 && <p className="text-red-900/50 text-center italic py-4">Blocklist is empty.</p>}
                                 {blockedUsers.map((user, i) => (
                                     <div key={i} className="flex items-center justify-between p-3 bg-red-950/10 rounded border border-red-900/20 opacity-75 grayscale hover:grayscale-0 transition-all">
                                         <div className="flex items-center gap-3">
                                             <div className="w-8 h-8 rounded-full bg-red-900 flex items-center justify-center text-red-200 font-bold"><XCircle size={16}/></div>
                                             <div>
                                                 <h4 className="text-red-300 text-sm font-bold line-through decoration-red-500">{user.identifier}</h4>
                                                 <p className="text-[10px] text-red-700">{user.reason}</p>
                                             </div>
                                         </div>
                                         <button onClick={() => unblockUser(user.identifier)} className="px-3 py-1 bg-emerald-900/30 text-emerald-400 text-[10px] font-bold uppercase rounded border border-emerald-800 hover:bg-emerald-900/50 flex items-center gap-1">
                                             <UserCheck size={10}/> Unblock
                                         </button>
                                     </div>
                                 ))}
                             </div>
                         </SciFiCard>
                     </div>
                 )}

                 {/* TAB CONTENT: ADVANCED USER TRACKING (NEW) */}
                 {activeTab === 'TRACKING' && (
                     <SciFiCard className="p-0 overflow-hidden bg-black/80 border-cyan-900/50 min-h-[500px] flex flex-col animate-fadeIn">
                        <div className="p-4 bg-[#020a07] border-b border-cyan-900/50 flex justify-between items-center">
                            <h3 className="text-cyan-400 font-bold uppercase tracking-widest text-xs flex items-center gap-2"><Monitor size={14}/> User Insights & Time Tracking</h3>
                        </div>
                        <div className="overflow-x-auto">
                            <table className="w-full text-left border-collapse">
                                <thead>
                                    <tr className="text-cyan-600 text-[10px] uppercase tracking-wider border-b border-cyan-900/30">
                                        <th className="p-4">User Identity</th>
                                        <th className="p-4">Role</th>
                                        <th className="p-4">Total Time</th>
                                        <th className="p-4">Visits</th>
                                        <th className="p-4">Last Seen</th>
                                        <th className="p-4">Device / IP</th>
                                    </tr>
                                </thead>
                                <tbody className="text-cyan-200 text-xs font-mono">
                                    {knownUsers.map((u, i) => (
                                        <tr key={i} className="hover:bg-cyan-900/10 border-b border-cyan-900/20 transition-colors">
                                            <td className="p-4 font-bold flex items-center gap-2">
                                                <div className="w-6 h-6 rounded bg-cyan-900 text-cyan-400 flex items-center justify-center">{u.name[0]?.toUpperCase()}</div>
                                                {u.name}
                                            </td>
                                            <td className="p-4">
                                                <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${u.role === 'Private' ? 'bg-indigo-900 text-indigo-300' : 'bg-green-900 text-green-300'}`}>
                                                    {u.role.toUpperCase()}
                                                </span>
                                            </td>
                                            <td className="p-4">
                                                <div className="flex items-center gap-1 text-yellow-400 font-bold">
                                                    <Timer size={12}/>
                                                    {Math.floor(u.totalTimeSpentMinutes / 60)}h {u.totalTimeSpentMinutes % 60}m
                                                </div>
                                            </td>
                                            <td className="p-4">{u.visitCount} logins</td>
                                            <td className="p-4 text-cyan-500">{new Date(u.lastLogin).toLocaleString()}</td>
                                            <td className="p-4 text-[10px] text-cyan-600">
                                                <div className="flex flex-col">
                                                    <span className="flex items-center gap-1"><Laptop size={10}/> {u.deviceModel.substring(0, 15)}...</span>
                                                    <span>{u.ip}</span>
                                                </div>
                                            </td>
                                        </tr>
                                    ))}
                                    {knownUsers.length === 0 && (
                                        <tr>
                                            <td colSpan={6} className="p-8 text-center text-cyan-800 italic">No tracking data gathered yet.</td>
                                        </tr>
                                    )}
                                </tbody>
                            </table>
                        </div>
                     </SciFiCard>
                 )}

             </div>
        </div>
    );
};

// --- Sub Components ---

const StatCard = ({ icon: Icon, label, value, color, alert }: any) => (
    <SciFiCard className={`p-4 flex flex-col items-center justify-center ${alert ? 'border-yellow-500 animate-pulse' : ''}`}>
        <Icon className={`${color} mb-2 opacity-80`} size={24} />
        <span className="text-2xl font-bold text-white font-mono">{value}</span>
        <span className="text-[10px] uppercase tracking-widest text-cyan-700">{label}</span>
    </SciFiCard>
);

const PortalCard = ({ title, sub, icon: Icon, theme, onClick, alert }: any) => {
    // Theme configurations
    let colorClass, borderClass;
    if (theme === 'indigo') {
        colorClass = 'from-indigo-600 to-blue-600';
        borderClass = 'border-indigo-500/30';
    } else if (theme === 'rose') {
        colorClass = 'from-rose-600 to-pink-600';
        borderClass = 'border-rose-500/30';
    } else if (theme === 'emerald') {
        colorClass = 'from-emerald-600 to-teal-600';
        borderClass = 'border-emerald-500/30';
    } else if (theme === 'amber') {
        colorClass = 'from-amber-600 to-orange-600';
        borderClass = 'border-amber-500/30';
    } else {
        colorClass = 'from-gray-600 to-gray-800';
        borderClass = 'border-gray-500/30';
    }
    
    return (
        <motion.button 
            onClick={onClick}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            className={`relative h-64 rounded-2xl overflow-hidden group border ${alert ? 'border-red-500 animate-pulse' : borderClass}`}
        >
            <div className={`absolute inset-0 bg-gradient-to-br ${colorClass} opacity-10 group-hover:opacity-20 transition-opacity`}></div>
            <div className="absolute inset-0 flex flex-col items-center justify-center z-10">
                <Icon size={64} className="text-white mb-4 drop-shadow-[0_0_15px_rgba(255,255,255,0.3)] group-hover:scale-110 transition-transform duration-500" />
                <h2 className="text-3xl font-bold text-white uppercase tracking-wider">{title}</h2>
                <p className="text-white/60 text-sm mt-1">{sub}</p>
                <div className="mt-6 px-6 py-2 rounded-full border border-white/20 bg-white/5 backdrop-blur-md text-xs font-bold uppercase tracking-[0.2em] group-hover:bg-white/20 transition-colors">
                    Access Interface
                </div>
            </div>
            
            {/* Scanlines Effect */}
            <div className="absolute inset-0 bg-[linear-gradient(rgba(18,16,16,0)_50%,rgba(0,0,0,0.25)_50%),linear-gradient(90deg,rgba(255,0,0,0.06),rgba(0,255,0,0.02),rgba(0,0,255,0.06))] z-0 bg-[length:100%_2px,3px_100%] pointer-events-none opacity-20"></div>
        </motion.button>
    );
};

// Fixed Overlay for Admin Mode inside Portals
const AdminOverlay = ({ onBack, label }: { onBack: () => void, label: string }) => (
  <div className="fixed top-0 inset-x-0 z-[100] bg-black/90 border-b border-cyan-500/30 p-2 flex justify-between items-center px-4 md:px-6 shadow-[0_5px_20px_rgba(0,0,0,0.5)]">
     <div className="flex items-center gap-3">
        <span className="relative flex h-3 w-3">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
          <span className="relative inline-flex rounded-full h-3 w-3 bg-red-500"></span>
        </span>
        <span className="font-mono text-xs uppercase tracking-widest text-cyan-400 font-bold hidden md:inline-block">{label}</span>
        <span className="font-mono text-xs uppercase tracking-widest text-cyan-400 font-bold md:hidden">SECURE MODE</span>
     </div>
     
     <div className="flex gap-2">
        <button onClick={onBack} className="px-4 py-1.5 bg-red-900/40 hover:bg-red-900/60 border border-red-500/40 text-red-200 text-xs font-bold rounded-md transition-all flex items-center gap-2 shadow-lg">
            <ArrowLeft size={14} /> <span className="hidden sm:inline">EXIT TO COMMAND CENTER</span><span className="sm:hidden">EXIT</span>
        </button>
     </div>
  </div>
);
