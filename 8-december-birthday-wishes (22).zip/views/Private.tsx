
import React, { useState, useEffect, useRef, useMemo } from 'react';
import { motion, AnimatePresence, useScroll, useTransform, useSpring, useMotionValue } from 'framer-motion';
import { Star, Gift, Image as ImageIcon, BookOpen, MessageCircle, Puzzle, Gamepad2, Wand2, Send, RotateCcw, DoorOpen, Trash2, Upload, Edit3, Save, ArrowLeft, LogOut, Heart, Plus, Sparkles, Check, CloudRain, Sun, Moon, Wind, Fingerprint, Lock, Music, Flower2, Mic, Zap, Eye, Leaf, X, Snowflake, Flame, Droplets, Mountain, CloudFog, Sunset, CloudLightning, Waves, Camera, PenTool, User, Layers, CircleDashed, Grid, Eraser } from 'lucide-react';
import { Photo, Story, QuizQuestion, GreetingCard, SurpriseItem } from '../types';
import { db } from '../services/database';
import { GlassCard, PageTransition, GlowingButton, GlassInput } from '../components/UI';
import { ScratchCard } from '../components/ScratchCard';
import { EditableText, EditableImage } from '../components/Editable';
import confetti from 'canvas-confetti';
import { generateLoveReward, generatePoem } from '../services/geminiService';

// --- MAIN DASHBOARD ---

interface PrivateProps {
  onLogout: () => void;
  isAdmin?: boolean; 
  onExit?: () => void; // Explicit exit to Admin Hub
}

type PrivateViewMode = 'HOME' | 'GALLERY_3D' | 'STORIES' | 'GIFT_BOXES' | 'QUIZ' | 'SURPRISE_PORTAL' | 'AI_MAGIC' | 'SURPRISE_COLLECTION' | 'MASTER_WISHES';

export const PrivateDashboard: React.FC<PrivateProps> = ({ onLogout, isAdmin = false, onExit }) => {
  const [view, setView] = useState<PrivateViewMode>('HOME');

  useEffect(() => {
    if (isAdmin) return;
    const handlePopState = (event: PopStateEvent) => {
        const state = event.state;
        if (state && state.privateView) {
            setView(state.privateView);
        } else {
            setView('HOME');
        }
    };

    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, [isAdmin]);

  const navigateTo = (newView: PrivateViewMode) => {
    if (!isAdmin) {
        const newState = { ...window.history.state, privateView: newView };
        window.history.pushState(newState, '');
    }
    setView(newView);
  };

  const handleBack = () => {
    if (!isAdmin) window.history.back();
    else setView('HOME');
  };

  return (
    <PageTransition>
      <div className={`min-h-screen p-4 pb-20 z-10 relative font-sans ${isAdmin ? 'pt-20' : ''}`}>
         <AnimatePresence mode="wait">
            {view === 'HOME' && <HomeHub key="home" setView={navigateTo} isAdmin={isAdmin} onExit={onExit} onLogout={onLogout} />}
            {view === 'GALLERY_3D' && <Gallery3DSection key="gallery" onBack={handleBack} isAdmin={isAdmin} />}
            {view === 'STORIES' && <StorySection key="stories" onBack={handleBack} isAdmin={isAdmin} />}
            {view === 'GIFT_BOXES' && <GreetingCardsSection key="gifts" onBack={handleBack} isAdmin={isAdmin} />}
            {view === 'QUIZ' && <QuizSection key="quiz" onBack={handleBack} isAdmin={isAdmin} />}
            {view === 'SURPRISE_PORTAL' && <SurprisePortalSection key="surprise" onBack={handleBack} isAdmin={isAdmin} />}
            {view === 'AI_MAGIC' && <AIMagicSection key="magic" onBack={handleBack} isAdmin={isAdmin} />}
            {view === 'SURPRISE_COLLECTION' && <SurpriseCollectionSection key="collection" onBack={handleBack} isAdmin={isAdmin} />}
            {view === 'MASTER_WISHES' && <MasterWishesSection key="master_wishes" onBack={handleBack} isAdmin={isAdmin} />}
         </AnimatePresence>
      </div>
    </PageTransition>
  );
};

// --- 0. HOME HUB (Menu) ---
interface HomeHubProps {
  setView: (v: PrivateViewMode) => void;
  isAdmin?: boolean;
  onExit?: () => void;
  onLogout: () => void;
}

const HomeHub: React.FC<HomeHubProps> = ({ setView, isAdmin, onExit, onLogout }) => (
  <motion.div exit={{ opacity: 0, scale: 0.9 }} className="max-w-4xl mx-auto pt-6">
     {/* ADMIN ONLY: Explicit Back to Hub Button */}
     {isAdmin && (
         <div className="mb-8 flex justify-center">
             <button 
                onClick={() => onExit?.()}
                className="flex items-center gap-2 px-6 py-3 bg-cyan-950/50 border border-cyan-500/50 text-cyan-300 rounded-full font-bold uppercase tracking-widest text-xs hover:bg-cyan-900/80 transition-colors shadow-[0_0_15px_rgba(6,182,212,0.3)]"
             >
                <ArrowLeft size={16} /> Return to Command Center
             </button>
         </div>
     )}

     {!isAdmin && (
         <div className="absolute top-4 right-4">
            <button onClick={onLogout} className="p-2 rounded-full bg-[var(--bg-input)] text-[var(--accent-secondary)]"><LogOut size={20}/></button>
         </div>
     )}

     <div className="text-center mb-12">
        <motion.div 
           initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ type: "spring", duration: 1 }}
           className="relative inline-block"
        >
           <div className="absolute inset-0 bg-gradient-to-tr from-[var(--accent-primary)] to-[var(--accent-secondary)] rounded-full blur-lg opacity-70 animate-pulse"></div>
           <div className="relative w-32 h-32 rounded-full border-4 border-[var(--bg-card)] shadow-2xl overflow-hidden">
             <EditableImage 
                id="private_avatar_main" 
                defaultSrc="https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=500" 
                isAdmin={isAdmin} 
                className="w-full h-full"
             />
           </div>
           <motion.div 
             animate={{ rotate: 360 }} transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
             className="absolute -inset-2 border border-dashed border-[var(--accent-primary)] rounded-full opacity-50 pointer-events-none"
           />
        </motion.div>
        <h1 className="text-6xl font-bold cursive text-[var(--text-main)] mt-6 text-shadow-glow tracking-wide">
            <EditableText id="private_home_title" defaultText="Shivani's World" isAdmin={isAdmin} />
        </h1>
        <p className="text-[var(--accent-secondary)] mt-2 font-medium tracking-widest uppercase text-xs">
            <EditableText id="private_home_subtitle" defaultText="The Queen's Private Lounge" isAdmin={isAdmin} />
        </p>
     </div>

     {/* Featured Big Card 1: Surprise Collection */}
     <motion.button
        onClick={() => setView('SURPRISE_COLLECTION')}
        whileHover={{ scale: 1.01, boxShadow: "0 20px 50px -12px rgba(236, 72, 153, 0.5)" }} 
        whileTap={{ scale: 0.98 }}
        className="w-full mb-6 p-8 rounded-[2rem] bg-gradient-to-br from-[#2e1065] via-[#4c1d95] to-[#db2777] border border-white/10 shadow-2xl relative overflow-hidden group text-left isolate"
     >
        <div className="absolute inset-0 opacity-30 mix-blend-overlay bg-[url('https://www.transparenttextures.com/patterns/stardust.png')]"></div>
        <div className="absolute -right-20 -top-20 w-64 h-64 bg-pink-500 rounded-full blur-[100px] opacity-40 group-hover:opacity-60 transition-opacity duration-500"></div>
        <div className="absolute -left-20 -bottom-20 w-64 h-64 bg-blue-500 rounded-full blur-[100px] opacity-40 group-hover:opacity-60 transition-opacity duration-500"></div>
        
        <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-6">
            <div>
               <div className="flex items-center gap-3 mb-2">
                  <span className="px-3 py-1 rounded-full bg-white/10 backdrop-blur-md border border-white/20 text-xs font-bold text-pink-200 uppercase tracking-wider">New</span>
                  <div className="flex gap-1"><Star size={12} className="text-yellow-400 fill-current"/><Star size={12} className="text-yellow-400 fill-current"/></div>
               </div>
               <h2 className="text-3xl md:text-5xl font-bold text-white mb-2 cursive leading-tight">
                 <EditableText id="private_collection_title" defaultText="Magical Surprise World" isAdmin={isAdmin} />
               </h2>
               <p className="text-pink-100/80 text-sm md:text-lg font-light max-w-lg">
                 <EditableText id="private_collection_sub" defaultText="13 Ultra-Realistic Magical Experiences" isAdmin={isAdmin} multiline />
               </p>
            </div>
            <div className="text-7xl filter drop-shadow-[0_0_20px_rgba(255,255,255,0.3)] animate-float">🎁</div>
        </div>
     </motion.button>

     {/* Featured Big Card 2: 50 Wishes Section (NEW) */}
     <motion.button
        onClick={() => setView('MASTER_WISHES')}
        whileHover={{ scale: 1.01, boxShadow: "0 20px 50px -12px rgba(220, 38, 38, 0.5)" }} 
        whileTap={{ scale: 0.98 }}
        className="w-full mb-10 p-8 rounded-[2rem] bg-gradient-to-br from-[#881337] via-[#9f1239] to-[#fb7185] border border-white/10 shadow-2xl relative overflow-hidden group text-left isolate"
     >
        {/* Animated Background */}
        <div className="absolute inset-0 opacity-20 mix-blend-overlay bg-[url('https://www.transparenttextures.com/patterns/cubes.png')]"></div>
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[120%] h-[120%] bg-[radial-gradient(circle,rgba(255,0,0,0.2)_0%,transparent_70%)] animate-pulse"></div>
        
        <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="order-2 md:order-1">
               <div className="flex items-center gap-3 mb-2">
                  <span className="px-3 py-1 rounded-full bg-white/10 backdrop-blur-md border border-white/20 text-xs font-bold text-red-100 uppercase tracking-wider">50 Categories</span>
               </div>
               <h2 className="text-3xl md:text-5xl font-bold text-white mb-2 cursive leading-tight">
                 <EditableText id="private_wishes_title" defaultText="Wishes & Feelings" isAdmin={isAdmin} />
               </h2>
               <p className="text-red-100/80 text-sm md:text-lg font-light max-w-lg">
                 <EditableText id="private_wishes_sub" defaultText="Explore 50 beautiful worlds of love." isAdmin={isAdmin} multiline />
               </p>
            </div>
            <div className="order-1 md:order-2 relative">
                <div className="absolute inset-0 bg-red-500 blur-[40px] opacity-50 animate-pulse"></div>
                <Heart size={80} className="text-white fill-rose-500 animate-[beat_1.5s_infinite] relative z-10 drop-shadow-2xl" />
            </div>
        </div>
        
        {/* Falling Petals Effect */}
        <div className="absolute inset-0 pointer-events-none overflow-hidden">
            {[...Array(5)].map((_, i) => (
                <div key={i} className="absolute text-white/30 text-xl animate-[floatUp_8s_linear_infinite]" 
                     style={{ left: `${Math.random()*100}%`, animationDelay: `${Math.random()*5}s`, bottom: '-20px' }}>
                    🌸
                </div>
            ))}
        </div>
     </motion.button>

     <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pb-20">
        <MenuCard icon={ImageIcon} title="Memory Gallery 3D" sub="Scratch to reveal moments" onClick={() => setView('GALLERY_3D')} delay={0.1} color="from-blue-500/20 to-cyan-500/20" isAdmin={isAdmin} idPrefix="gallery" />
        <MenuCard icon={BookOpen} title="Live Feed & Archives" sub="Live wishes from everyone" onClick={() => setView('STORIES')} delay={0.2} color="from-purple-500/20 to-pink-500/20" isAdmin={isAdmin} idPrefix="stories" />
        <MenuCard icon={Gift} title="Greeting Cards" sub="AI Generated Art for You" onClick={() => setView('GIFT_BOXES')} delay={0.3} color="from-amber-500/20 to-orange-500/20" isAdmin={isAdmin} idPrefix="gifts" />
        <MenuCard icon={Gamepad2} title="Shivani Quiz" sub="Rewards & Love Messages" onClick={() => setView('QUIZ')} delay={0.4} color="from-emerald-500/20 to-teal-500/20" isAdmin={isAdmin} idPrefix="quiz" />
        <MenuCard icon={Wand2} title="AI Magic" sub="Poems & Mood Generator" onClick={() => setView('AI_MAGIC')} delay={0.5} color="from-indigo-500/20 to-violet-500/20" isAdmin={isAdmin} idPrefix="magic" />
        <MenuCard icon={Puzzle} title="Surprise Portal" sub="Original List & Unlocks" onClick={() => setView('SURPRISE_PORTAL')} delay={0.6} color="from-rose-500/20 to-red-500/20" isAdmin={isAdmin} idPrefix="portal" />
     </div>
  </motion.div>
);

interface MenuCardProps {
  icon: any;
  title: string;
  sub: string;
  onClick: () => void;
  delay: number;
  color: string;
  isAdmin?: boolean;
  idPrefix: string;
}

const MenuCard: React.FC<MenuCardProps> = ({ icon: Icon, title, sub, onClick, delay, color, isAdmin, idPrefix }) => (
  <motion.button 
     initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay }}
     onClick={(e) => {
         // If admin clicks the editable text directly, don't navigate
         if ((e.target as HTMLElement).closest('.group') && (e.target as HTMLElement).tagName !== 'DIV') {
            onClick();
         } else if(!isAdmin) {
             onClick();
         }
     }}
     whileHover={{ scale: 1.02, y: -5 }} whileTap={{ scale: 0.98 }}
     className={`relative overflow-hidden group p-6 rounded-3xl bg-[var(--bg-card)] border border-[var(--border-color)] text-left shadow-xl hover:shadow-2xl transition-all`}
  >
     <div className={`absolute inset-0 bg-gradient-to-br ${color} opacity-0 group-hover:opacity-100 transition-opacity duration-500`}></div>
     <div className="relative z-10 flex items-start justify-between">
        <div>
           <Icon size={36} className="text-[var(--accent-primary)] mb-4 group-hover:scale-110 transition-transform duration-300" />
           <h3 className="text-2xl font-bold text-[var(--text-main)] mb-1 font-sans">
              <EditableText id={`${idPrefix}_title`} defaultText={title} isAdmin={isAdmin} />
           </h3>
           <p className="text-[var(--text-muted)] text-sm font-medium">
              <EditableText id={`${idPrefix}_sub`} defaultText={sub} isAdmin={isAdmin} />
           </p>
        </div>
        <div className="w-10 h-10 rounded-full bg-[var(--bg-input)] flex items-center justify-center group-hover:bg-[var(--accent-primary)] group-hover:text-white transition-colors">
            <DoorOpen size={18} />
        </div>
     </div>
  </motion.button>
);


// --- GALLERY 3D SECTION ---

// Gallery Types for Album Support
type GalleryType = 'CAROUSEL' | 'HELIX' | 'WALL';

const Gallery3DSection = ({ onBack, isAdmin }: {onBack: () => void, isAdmin?: boolean}) => {
  const [activeGallery, setActiveGallery] = useState<GalleryType | 'LOBBY'>('LOBBY');
  const [photos, setPhotos] = useState<Photo[]>([]);
  
  // States for interactive 3D Scenes
  const [rotation, setRotation] = useState(0);
  const [isDragging, setIsDragging] = useState(false);
  const [startX, setStartX] = useState(0);
  const [activeModal, setActiveModal] = useState<Photo | null>(null);
  
  // Animation Refs
  const requestRef = useRef<number | undefined>(undefined);

  useEffect(() => {
    setPhotos(db.getPhotos());
  }, []);

  // Filter photos based on active gallery
  const currentPhotos = activeGallery === 'LOBBY' 
    ? [] 
    : photos.filter(p => p.album === activeGallery || (!p.album && activeGallery === 'CAROUSEL')); 
    // Default to CAROUSEL if no album specified for backward compatibility

  // Admin Actions
  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>, album: GalleryType) => {
    if (e.target.files?.[0]) {
      const reader = new FileReader();
      reader.onload = () => {
         if (typeof reader.result === 'string') {
             const newPhoto: Photo = {
                 id: Date.now().toString(),
                 url: reader.result,
                 caption: "New Memory",
                 timestamp: Date.now(),
                 album: album
             };
             const updated = db.addPhoto(newPhoto);
             setPhotos(updated);
         }
      };
      reader.readAsDataURL(e.target.files[0]);
    }
  };

  const handleDelete = (id: string, e: React.MouseEvent) => {
      e.stopPropagation(); 
      if(confirm("Delete this photo permanently?")) {
          setPhotos(db.deletePhoto(id));
      }
  };

  // --- 3D Animation Logic (Shared) ---
  const animate = (time: number) => {
    if (!isDragging && !activeModal) {
       setRotation(prev => prev + 0.1); // Slow spin
    }
    requestRef.current = requestAnimationFrame(animate);
  };

  useEffect(() => {
    if(activeGallery !== 'LOBBY') {
        requestRef.current = requestAnimationFrame(animate);
    }
    return () => { 
        if(requestRef.current !== undefined) {
            cancelAnimationFrame(requestRef.current);
        }
    };
  }, [isDragging, activeModal, activeGallery]);

  // Input Handlers for rotation
  const handleStart = (clientX: number) => { setIsDragging(true); setStartX(clientX); };
  const handleMove = (clientX: number) => {
      if (!isDragging) return;
      const delta = clientX - startX;
      setRotation(prev => prev + delta * 0.5); 
      setStartX(clientX);
  };
  const handleEnd = () => { setIsDragging(false); };

  // --- SUB-VIEWS ---

  // 1. LOBBY VIEW (Select a Gallery)
  if (activeGallery === 'LOBBY') {
      return (
          <div className="min-h-screen pt-20 pb-20 px-4 relative overflow-hidden bg-[#0a0a0a]">
              <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/black-scales.png')] opacity-20"></div>
              
              <div className="absolute top-4 left-4 z-50">
                <button onClick={() => onBack()} className="p-2 rounded-full bg-white/10 backdrop-blur-md text-white border border-white/20 hover:bg-white/20 transition-colors">
                    <ArrowLeft size={24}/>
                </button>
              </div>

              <div className="text-center mb-12 relative z-10">
                  <h2 className="text-4xl md:text-6xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-pink-300 via-purple-300 to-indigo-300 cursive text-shadow-glow">
                      <EditableText id="gallery_lobby_title" defaultText="Memories of Love" isAdmin={isAdmin} />
                  </h2>
                  <p className="text-white/50 mt-2 uppercase tracking-widest text-xs">Choose a Dimension</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto relative z-10">
                  {/* Gallery Card 1: Carousel */}
                  <motion.button 
                    onClick={() => setActiveGallery('CAROUSEL')}
                    whileHover={{ scale: 1.05, y: -10 }}
                    className="relative group h-96 rounded-3xl overflow-hidden border border-pink-500/30 shadow-[0_0_30px_rgba(236,72,153,0.2)]"
                  >
                      <div className="absolute inset-0 bg-gradient-to-br from-pink-900 to-black opacity-80 group-hover:opacity-90 transition-opacity"></div>
                      <EditableImage id="cover_carousel" defaultSrc="https://images.unsplash.com/photo-1518199266791-5375a83190b7?w=600" isAdmin={isAdmin} className="absolute inset-0 w-full h-full object-cover -z-10 opacity-60 group-hover:scale-110 transition-transform duration-700"/>
                      <div className="absolute inset-0 flex flex-col items-center justify-center p-6 text-center">
                          <CircleDashed size={64} className="text-pink-400 mb-4 animate-[spin_10s_linear_infinite]"/>
                          <h3 className="text-3xl font-bold text-white cursive mb-2">Circle of Love</h3>
                          <p className="text-pink-200/70 text-sm">Rotating memories in a loop of time.</p>
                      </div>
                  </motion.button>

                  {/* Gallery Card 2: Helix */}
                  <motion.button 
                    onClick={() => setActiveGallery('HELIX')}
                    whileHover={{ scale: 1.05, y: -10 }}
                    className="relative group h-96 rounded-3xl overflow-hidden border border-purple-500/30 shadow-[0_0_30px_rgba(168,85,247,0.2)]"
                  >
                      <div className="absolute inset-0 bg-gradient-to-br from-purple-900 to-black opacity-80 group-hover:opacity-90 transition-opacity"></div>
                      <EditableImage id="cover_helix" defaultSrc="https://images.unsplash.com/photo-1492633423870-43d1cd2775eb?w=600" isAdmin={isAdmin} className="absolute inset-0 w-full h-full object-cover -z-10 opacity-60 group-hover:scale-110 transition-transform duration-700"/>
                      <div className="absolute inset-0 flex flex-col items-center justify-center p-6 text-center">
                          <Layers size={64} className="text-purple-400 mb-4 animate-bounce"/>
                          <h3 className="text-3xl font-bold text-white cursive mb-2">Spiral of Time</h3>
                          <p className="text-purple-200/70 text-sm">Ascending through moments.</p>
                      </div>
                  </motion.button>

                  {/* Gallery Card 3: Wall */}
                  <motion.button 
                    onClick={() => setActiveGallery('WALL')}
                    whileHover={{ scale: 1.05, y: -10 }}
                    className="relative group h-96 rounded-3xl overflow-hidden border border-blue-500/30 shadow-[0_0_30px_rgba(59,130,246,0.2)]"
                  >
                      <div className="absolute inset-0 bg-gradient-to-br from-blue-900 to-black opacity-80 group-hover:opacity-90 transition-opacity"></div>
                      <EditableImage id="cover_wall" defaultSrc="https://images.unsplash.com/photo-1506784983877-45594efa4cbe?w=600" isAdmin={isAdmin} className="absolute inset-0 w-full h-full object-cover -z-10 opacity-60 group-hover:scale-110 transition-transform duration-700"/>
                      <div className="absolute inset-0 flex flex-col items-center justify-center p-6 text-center">
                          <Grid size={64} className="text-blue-400 mb-4 animate-pulse"/>
                          <h3 className="text-3xl font-bold text-white cursive mb-2">Dream Wall</h3>
                          <p className="text-blue-200/70 text-sm">A magnificent curved wall of life.</p>
                      </div>
                  </motion.button>
              </div>
          </div>
      );
  }

  // SHARED RENDER LOGIC FOR GALLERIES
  const cardCount = currentPhotos.length;
  // Radius calculation for Carousel
  const radius = Math.max(250, (cardCount * 60)); 

  return (
    <div className="min-h-screen pt-20 pb-20 px-4 relative overflow-hidden bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-blue-950 via-black to-black">
      
      {/* Dynamic Background Ambience */}
      <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/stardust.png')] opacity-20 pointer-events-none"></div>
      
      {activeGallery === 'CAROUSEL' && (
          <div className="absolute inset-0 pointer-events-none">
             <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-pink-500/20 rounded-full blur-[100px] animate-pulse"></div>
          </div>
      )}
      {activeGallery === 'HELIX' && (
          <div className="absolute inset-0 pointer-events-none">
             <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-purple-500/20 rounded-full blur-[100px] animate-pulse"></div>
          </div>
      )}
      {activeGallery === 'WALL' && (
          <div className="absolute inset-0 pointer-events-none">
             <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full h-full bg-blue-500/10 rounded-full blur-[120px] animate-pulse"></div>
          </div>
      )}

      {/* Navigation Controls */}
      <div className="absolute top-4 left-4 z-50 flex gap-4">
        <button onClick={() => onBack()} className="p-2 rounded-full bg-white/10 backdrop-blur-md text-white border border-white/20 hover:bg-white/20 transition-colors">
            <ArrowLeft size={24}/>
        </button>
        <button onClick={() => setActiveGallery('LOBBY')} className="px-4 py-2 rounded-full bg-white/10 backdrop-blur-md text-white border border-white/20 hover:bg-white/20 transition-colors text-xs font-bold uppercase tracking-wider flex items-center gap-2">
            <RotateCcw size={14}/> Switch Gallery
        </button>
      </div>

      {isAdmin && (
         <div className="absolute top-4 right-4 z-50">
             <label className="flex items-center gap-2 px-4 py-2 bg-green-600 hover:bg-green-500 text-white rounded-full font-bold cursor-pointer shadow-lg transition-colors">
                 <Camera size={20}/>
                 <span className="text-xs uppercase tracking-wider">Add to {activeGallery}</span>
                 <input type="file" className="hidden" accept="image/*" onChange={(e) => handleFileSelect(e, activeGallery as GalleryType)}/>
             </label>
         </div>
      )}

      <div className="text-center mb-4 relative z-10 pointer-events-none mt-10">
        <h2 className="text-4xl md:text-5xl font-bold text-white cursive text-shadow-glow">
            {activeGallery === 'CAROUSEL' && "Circle of Love"}
            {activeGallery === 'HELIX' && "Spiral of Time"}
            {activeGallery === 'WALL' && "Dream Wall"}
        </h2>
        <p className="text-blue-200 mt-2 text-sm uppercase tracking-widest opacity-70">
            Swipe to Rotate • Tap to Reveal
        </p>
      </div>

      {/* 3D SCENE CONTAINER */}
      <div 
        className="relative w-full h-[60vh] flex items-center justify-center perspective-1000 cursor-grab active:cursor-grabbing touch-pan-y"
        onTouchStart={(e) => handleStart(e.touches[0].clientX)} 
        onTouchMove={(e) => handleMove(e.touches[0].clientX)} 
        onTouchEnd={handleEnd}
        onMouseDown={(e) => handleStart(e.clientX)} 
        onMouseMove={(e) => handleMove(e.clientX)} 
        onMouseUp={handleEnd} 
        onMouseLeave={handleEnd}
      >
          {currentPhotos.length === 0 ? (
              <div className="text-white/50 text-center">
                  <ImageIcon size={48} className="mx-auto mb-4 opacity-50"/>
                  <p>Admin: Add photos to this {activeGallery.toLowerCase()} gallery.</p>
              </div>
          ) : (
              <motion.div 
                 className="relative preserve-3d transition-transform ease-out"
                 style={{ 
                    // Base Transform + Rotation
                    transform: activeGallery === 'CAROUSEL' 
                        ? `translateZ(-${radius}px) rotateY(${rotation}deg)` 
                        : activeGallery === 'HELIX'
                        ? `translateZ(-400px) rotateY(${rotation}deg)`
                        : `translateZ(-300px) rotateY(${rotation * 0.5}deg)`, // Wall rotates slower
                    width: activeGallery === 'WALL' ? '800px' : '280px',
                    height: '400px'
                 }}
              >
                  {currentPhotos.map((photo, index) => {
                      // 1. CAROUSEL LAYOUT
                      if (activeGallery === 'CAROUSEL') {
                        const angle = (360 / cardCount) * index;
                        return (
                            <div 
                                key={photo.id}
                                className="absolute top-0 left-0 w-full h-full rounded-2xl bg-white/5 border border-white/10 shadow-[0_0_30px_rgba(236,72,153,0.3)] overflow-hidden hover:border-pink-400/50"
                                style={{ 
                                    transform: `rotateY(${angle}deg) translateZ(${radius}px)`,
                                    backfaceVisibility: 'hidden' 
                                }}
                                onClick={() => !isDragging && setActiveModal(photo)}
                            >
                                <GalleryCardContent photo={photo} isAdmin={!!isAdmin} onDelete={handleDelete} color="pink" />
                            </div>
                        );
                      }
                      
                      // 2. HELIX LAYOUT
                      if (activeGallery === 'HELIX') {
                          const angle = index * 40; // Spacing
                          const yOffset = (index - cardCount/2) * 60; // Vertical spread
                          return (
                            <div 
                                key={photo.id}
                                className="absolute top-0 left-0 w-full h-full rounded-2xl bg-white/5 border border-white/10 shadow-[0_0_30px_rgba(168,85,247,0.3)] overflow-hidden hover:border-purple-400/50"
                                style={{ 
                                    transform: `rotateY(${angle}deg) translateY(${yOffset}px) translateZ(500px)`,
                                    backfaceVisibility: 'hidden' 
                                }}
                                onClick={() => !isDragging && setActiveModal(photo)}
                            >
                                <GalleryCardContent photo={photo} isAdmin={!!isAdmin} onDelete={handleDelete} color="purple" />
                            </div>
                          );
                      }

                      // 3. WALL LAYOUT (Curved Grid)
                      if (activeGallery === 'WALL') {
                          // Grid Layout mapped to 3D curve
                          const row = Math.floor(index / 3);
                          const col = index % 3;
                          const xPos = (col - 1) * 320; 
                          const yPos = (row - Math.floor(cardCount/6)) * 420; // Vertical Stack
                          // Curvature based on X position
                          const rotateY = (col - 1) * 15; 
                          const translateZ = Math.abs(col - 1) * -50; 

                          return (
                            <div 
                                key={photo.id}
                                className="absolute w-[300px] h-[400px] rounded-2xl bg-white/5 border border-white/10 shadow-[0_0_30px_rgba(59,130,246,0.3)] overflow-hidden hover:border-blue-400/50"
                                style={{ 
                                    left: '50%', top: '50%',
                                    marginTop: '-200px', marginLeft: '-150px', // Center pivot
                                    transform: `translateX(${xPos}px) translateY(${yPos}px) translateZ(${translateZ}px) rotateY(${rotateY}deg)`,
                                    backfaceVisibility: 'hidden' 
                                }}
                                onClick={() => !isDragging && setActiveModal(photo)}
                            >
                                <GalleryCardContent photo={photo} isAdmin={!!isAdmin} onDelete={handleDelete} color="blue" />
                            </div>
                          );
                      }
                      return null;
                  })}
              </motion.div>
          )}
      </div>

      {/* MODAL FOR SCRATCH INTERACTION */}
      <AnimatePresence>
          {activeModal && (
              <motion.div 
                 initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}}
                 className="fixed inset-0 z-[100] flex items-center justify-center bg-black/90 p-4 backdrop-blur-sm"
                 onClick={() => setActiveModal(null)}
              >
                  <motion.div 
                     initial={{scale:0.8, y: 20}} animate={{scale:1, y:0}} exit={{scale:0.8, opacity:0}}
                     className="max-w-md w-full relative"
                     onClick={e => e.stopPropagation()}
                  >
                      <button onClick={() => setActiveModal(null)} className="absolute -top-12 right-0 text-white hover:text-red-400 transition-colors">
                          <X size={32}/>
                      </button>
                      
                      <div className="rounded-2xl overflow-hidden shadow-2xl border border-white/20">
                          <ScratchCard 
                              imageSrc={activeModal.url}
                              text={activeModal.caption || "A beautiful memory"}
                              scratchType={activeGallery === 'WALL' ? 'frost' : activeGallery === 'HELIX' ? 'night' : 'rose'}
                              className="h-[500px]"
                          />
                      </div>
                      <p className="text-center text-white/50 mt-4 text-sm animate-pulse">Scratch to reveal the full memory</p>
                  </motion.div>
              </motion.div>
          )}
      </AnimatePresence>
    </div>
  );
};

// Sub-component for Card Internal Content to reuse code
const GalleryCardContent = ({ photo, isAdmin, onDelete, color }: { photo: Photo, isAdmin: boolean, onDelete: (id: string, e: React.MouseEvent) => void, color: string }) => (
    <div className="relative w-full h-full group">
        <img src={photo.url} alt="Memory" className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-opacity" />
        <div className={`absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent`}>
            <div className="absolute bottom-4 left-4 right-4">
                <p className="text-white font-bold text-lg truncate text-shadow-glow">{photo.caption || "Memory"}</p>
                <div className={`flex items-center gap-2 mt-2 text-xs uppercase tracking-widest font-bold text-${color}-300`}>
                    <Sparkles size={12}/> Tap to Open
                </div>
            </div>
        </div>
        {isAdmin && (
            <button 
                onClick={(e) => onDelete(photo.id, e)} 
                className="absolute top-2 right-2 p-2 bg-red-600/80 text-white rounded-full opacity-0 group-hover:opacity-100 transition-opacity hover:bg-red-500"
            >
                <Trash2 size={16}/>
            </button>
        )}
    </div>
);


// --- STORY ARCHIVES (3D TIMELINE) ---

const StorySection = ({ onBack, isAdmin }: {onBack: () => void, isAdmin?: boolean}) => {
    const [stories, setStories] = useState<Story[]>([]);
    const [filter, setFilter] = useState<'ALL' | 'MEMORY' | 'GUEST_MESSAGE' | 'GUEST_WISHES'>('ALL'); // Added GUEST_WISHES to typings logic
    const [isAdding, setIsAdding] = useState(false);
    const [editId, setEditId] = useState<string | null>(null);

    // Form State
    const [formAuthor, setFormAuthor] = useState('');
    const [formContent, setFormContent] = useState('');
    const [formPhoto, setFormPhoto] = useState('');
    const fileInputRef = useRef<HTMLInputElement>(null);

    // Live Feed Polling
    useEffect(() => {
        const fetchData = () => {
             // 1. Get Stories (Memories)
             const rawStories = db.getStories();
             
             // 2. Get Guest Wishes (that are approved) and convert to Story format for unified timeline
             const rawWishes = db.getWishes()
                .filter(w => w.isApproved)
                .map(w => ({
                    id: w.id,
                    author: w.senderName,
                    content: w.message,
                    type: 'GUEST_MESSAGE' as const, // Treat wishes as guest messages in timeline
                    timestamp: w.timestamp,
                    photoUrl: '' // Wishes don't usually have photos in this schema, but could be added
                }));

             // Merge and sort by newest
             const merged = [...rawStories, ...rawWishes].sort((a, b) => b.timestamp - a.timestamp);
             
             // Remove duplicates if any ID conflict (rare given timestamp usage)
             const unique = Array.from(new Map(merged.map(item => [item.id, item])).values());
             
             setStories(unique);
        };

        fetchData(); // Initial load
        
        // Poll every 3 seconds for "Live" updates
        const interval = setInterval(fetchData, 3000);
        return () => clearInterval(interval);
    }, []);

    const filteredStories = stories.filter(s => filter === 'ALL' ? true : s.type === filter || (filter === 'GUEST_MESSAGE' && s.type === 'GUEST_MESSAGE'));

    const handleSave = () => {
        if (!formAuthor || !formContent) return alert("Author and Content required!");
        
        let updated: Story[] = [];
        if (editId) {
            // Update
            const story = stories.find(s => s.id === editId);
            if (story) {
                // Delete and Re-add to update properly
                db.deleteStory(editId);
                updated = db.addStory({
                    ...story,
                    author: formAuthor,
                    content: formContent,
                    photoUrl: formPhoto || story.photoUrl
                });
            } else {
                updated = stories; // Should not happen
            }
        } else {
            // Create
            updated = db.addStory({
                id: Date.now().toString(),
                author: formAuthor,
                content: formContent,
                type: 'MEMORY', // Admin adds MEMORIES usually
                timestamp: Date.now(),
                photoUrl: formPhoto
            });
        }
        // Force refresh state immediately, though polling will also catch it
        setStories(prev => {
             const newStory = updated[0]; // simplistic update for local state
             return [newStory, ...prev];
        });
        resetForm();
    };

    const handleDelete = (id: string) => {
        if(confirm("Delete this story permanently?")) {
             setStories(db.deleteStory(id));
        }
    };

    const startEdit = (story: Story) => {
        setEditId(story.id);
        setFormAuthor(story.author);
        setFormContent(story.content);
        setFormPhoto(story.photoUrl || '');
        setIsAdding(true);
    };

    const resetForm = () => {
        setIsAdding(false);
        setEditId(null);
        setFormAuthor('');
        setFormContent('');
        setFormPhoto('');
    }

    const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files?.[0]) {
            const reader = new FileReader();
            reader.onload = () => {
                 if (typeof reader.result === 'string') setFormPhoto(reader.result);
            };
            reader.readAsDataURL(e.target.files[0]);
        }
    }

    return (
        <div className="min-h-screen pt-20 pb-20 px-4 relative perspective-1000">
             {/* 3D Background Atmosphere */}
             <div className="fixed inset-0 bg-[#0f0518] -z-20"></div>
             <div className="fixed inset-0 bg-[url('https://www.transparenttextures.com/patterns/dark-matter.png')] opacity-30 -z-10 animate-[pulse_10s_infinite]"></div>
             
             {/* Floating Particles */}
             <div className="fixed inset-0 pointer-events-none -z-10">
                 {Array.from({length: 20}).map((_, i) => (
                     <motion.div 
                        key={i}
                        className="absolute w-1 h-1 bg-purple-500 rounded-full blur-[1px]"
                        initial={{ opacity: 0, y: 100 }}
                        animate={{ opacity: [0, 1, 0], y: -100, x: Math.random() * 50 - 25 }}
                        transition={{ duration: Math.random() * 5 + 5, repeat: Infinity, delay: Math.random() * 5 }}
                        style={{ left: `${Math.random()*100}%`, top: `${Math.random()*100}%` }}
                     />
                 ))}
             </div>

             <div className="absolute top-4 left-4 z-50">
                 <button onClick={() => onBack()} className="p-2 rounded-full bg-white/10 text-white hover:bg-white/20 transition-colors border border-white/20"><ArrowLeft size={24}/></button>
            </div>

            {/* Header & Controls */}
            <div className="text-center mb-10 relative z-10">
                <h2 className="text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-pink-300 via-purple-300 to-indigo-300 cursive text-shadow-glow mb-4">
                    <EditableText id="stories_header_3d" defaultText="Live Feed & Memories" isAdmin={isAdmin} />
                </h2>
                
                {/* Live Indicator */}
                <div className="flex items-center justify-center gap-2 mb-4">
                    <span className="relative flex h-3 w-3">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-3 w-3 bg-red-500"></span>
                    </span>
                    <span className="text-xs font-bold text-red-400 uppercase tracking-widest">Live Updates</span>
                </div>
                
                <div className="flex justify-center gap-2 mb-6 flex-wrap">
                    {(['ALL', 'MEMORY', 'GUEST_MESSAGE'] as const).map(type => (
                        <button 
                           key={type}
                           onClick={() => setFilter(type)}
                           className={`px-4 py-1 rounded-full text-xs font-bold uppercase tracking-widest transition-all border ${filter === type ? 'bg-purple-600 border-purple-400 text-white shadow-lg' : 'bg-transparent border-purple-500/30 text-purple-300 hover:bg-purple-500/20'}`}
                        >
                            {type === 'GUEST_MESSAGE' ? 'Guest Love' : type === 'MEMORY' ? 'Memories' : 'All'}
                        </button>
                    ))}
                </div>

                {isAdmin && !isAdding && (
                    <button 
                        onClick={() => setIsAdding(true)}
                        className="px-6 py-2 bg-gradient-to-r from-pink-500 to-purple-600 rounded-full text-white font-bold shadow-lg hover:scale-105 transition-transform flex items-center gap-2 mx-auto"
                    >
                        <PenTool size={16}/> Write Story
                    </button>
                )}
            </div>

            {/* ADMIN FORM MODAL */}
            <AnimatePresence>
                {isAdding && (
                    <motion.div 
                        initial={{ opacity: 0, height: 0 }} 
                        animate={{ opacity: 1, height: 'auto' }} 
                        exit={{ opacity: 0, height: 0 }}
                        className="max-w-xl mx-auto mb-10 bg-black/60 backdrop-blur-xl border border-purple-500/50 rounded-2xl p-6 relative z-50 shadow-2xl overflow-hidden"
                    >
                        <h3 className="text-white font-bold mb-4 flex items-center gap-2"><PenTool size={18}/> {editId ? 'Edit Story' : 'New Memory'}</h3>
                        <div className="space-y-4">
                            <input 
                                value={formAuthor} 
                                onChange={e => setFormAuthor(e.target.value)} 
                                placeholder="Author Name" 
                                className="w-full bg-white/5 border border-white/10 rounded-lg p-3 text-white outline-none focus:border-purple-500"
                            />
                            <textarea 
                                value={formContent} 
                                onChange={e => setFormContent(e.target.value)} 
                                placeholder="Write the memory here..." 
                                className="w-full bg-white/5 border border-white/10 rounded-lg p-3 text-white outline-none focus:border-purple-500 min-h-[100px]"
                            />
                            <div 
                                onClick={() => fileInputRef.current?.click()}
                                className="w-full border-2 border-dashed border-white/20 rounded-lg p-4 text-center cursor-pointer hover:bg-white/5 transition-colors"
                            >
                                {formPhoto ? (
                                    <img src={formPhoto} className="h-32 mx-auto object-cover rounded"/>
                                ) : (
                                    <div className="text-white/50 flex flex-col items-center">
                                        <Camera size={24} className="mb-2"/>
                                        <span className="text-xs">Attach Photo</span>
                                    </div>
                                )}
                            </div>
                            <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handlePhotoUpload}/>
                            
                            <div className="flex gap-2 justify-end">
                                <button onClick={resetForm} className="px-4 py-2 text-white/70 hover:text-white">Cancel</button>
                                <button onClick={handleSave} className="px-6 py-2 bg-purple-600 rounded-lg text-white font-bold hover:bg-purple-500">Save Story</button>
                            </div>
                        </div>
                    </motion.div>
                )}
            </AnimatePresence>

            {/* 3D TIMELINE LIST */}
            <div className="max-w-4xl mx-auto space-y-8 pb-20">
                {filteredStories.length === 0 && (
                    <div className="text-center text-white/50 py-20">
                        <BookOpen size={48} className="mx-auto mb-4 opacity-50"/>
                        <p>No stories found in this timeline.</p>
                    </div>
                )}

                {filteredStories.map((story, index) => (
                    <motion.div
                        key={story.id}
                        initial={{ opacity: 0, y: 50, rotateX: 10 }}
                        whileInView={{ opacity: 1, y: 0, rotateX: 0 }}
                        viewport={{ once: true, margin: "-50px" }}
                        transition={{ duration: 0.6, delay: index * 0.1 }}
                        whileHover={{ scale: 1.02, rotateX: 2, rotateY: 2, zIndex: 10 }}
                        className={`relative group rounded-2xl overflow-hidden border backdrop-blur-md shadow-2xl transition-all duration-500 ${
                            story.type === 'GUEST_MESSAGE' 
                            ? 'bg-indigo-950/40 border-indigo-500/30 hover:border-indigo-400' 
                            : 'bg-pink-950/40 border-pink-500/30 hover:border-pink-400'
                        }`}
                    >
                        {/* Glow Effect on Hover */}
                        <div className={`absolute inset-0 opacity-0 group-hover:opacity-20 transition-opacity bg-gradient-to-r ${story.type === 'GUEST_MESSAGE' ? 'from-indigo-500 to-blue-500' : 'from-pink-500 to-purple-500'}`}></div>

                        <div className="p-6 md:p-8 flex flex-col md:flex-row gap-6 relative z-10">
                            {/* Avatar / Badge */}
                            <div className="shrink-0">
                                <div className={`w-14 h-14 rounded-full flex items-center justify-center text-xl font-bold text-white shadow-lg border-2 ${
                                    story.type === 'GUEST_MESSAGE' 
                                    ? 'bg-gradient-to-br from-indigo-500 to-blue-600 border-blue-300' 
                                    : 'bg-gradient-to-br from-pink-500 to-rose-600 border-pink-300'
                                }`}>
                                    {story.author[0].toUpperCase()}
                                </div>
                                <div className={`mt-2 text-[10px] font-bold uppercase tracking-wider text-center px-2 py-0.5 rounded-full ${
                                    story.type === 'GUEST_MESSAGE' ? 'bg-indigo-500/20 text-indigo-300' : 'bg-pink-500/20 text-pink-300'
                                }`}>
                                    {story.type === 'GUEST_MESSAGE' ? 'Guest' : 'Memory'}
                                </div>
                            </div>

                            {/* Content */}
                            <div className="flex-1">
                                <div className="flex justify-between items-start">
                                    <h3 className="text-xl font-bold text-white mb-1">{story.author}</h3>
                                    <span className="text-xs text-white/40 font-mono">{new Date(story.timestamp).toLocaleDateString()} {new Date(story.timestamp).toLocaleTimeString()}</span>
                                </div>
                                
                                <p className="text-white/80 leading-relaxed font-serif italic text-lg mb-4">
                                    "{story.content}"
                                </p>

                                {story.photoUrl && (
                                    <motion.div 
                                        className="relative rounded-xl overflow-hidden shadow-lg border border-white/10 group-hover:shadow-[0_0_20px_rgba(255,255,255,0.1)]"
                                        whileHover={{ scale: 1.02 }}
                                    >
                                        <img src={story.photoUrl} alt="Memory" className="w-full h-auto max-h-[400px] object-cover" />
                                        <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
                                    </motion.div>
                                )}
                            </div>
                        </div>

                        {/* Admin Controls Overlay */}
                        {isAdmin && (
                            <div className="absolute top-4 right-4 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity translate-y-2 group-hover:translate-y-0">
                                <button onClick={() => startEdit(story)} className="p-2 bg-blue-600/80 text-white rounded-full hover:bg-blue-500 shadow-lg backdrop-blur-md">
                                    <Edit3 size={14}/>
                                </button>
                                <button onClick={() => handleDelete(story.id)} className="p-2 bg-red-600/80 text-white rounded-full hover:bg-red-500 shadow-lg backdrop-blur-md">
                                    <Trash2 size={14}/>
                                </button>
                            </div>
                        )}
                    </motion.div>
                ))}
            </div>
        </div>
    )
}

const GreetingCardsSection = ({ onBack, isAdmin }: {onBack: () => void, isAdmin?: boolean}) => {
    const [cards, setCards] = useState<GreetingCard[]>([]);
    const [selectedCard, setSelectedCard] = useState<GreetingCard | null>(null);
    const [isEditing, setIsEditing] = useState(false);
    
    // Form State for Admin
    const [formData, setFormData] = useState<GreetingCard>({ id: '', title: '', message: '', imageUrl: '' });
    const fileInputRef = useRef<HTMLInputElement>(null);

    useEffect(() => {
        setCards(db.getCards());
    }, []);

    const handleEdit = (card: GreetingCard, e: React.MouseEvent) => {
        e.stopPropagation();
        setFormData(card);
        setIsEditing(true);
    };

    const handleAddNew = () => {
        setFormData({ id: '', title: '', message: '', imageUrl: '' });
        setIsEditing(true);
    };

    const handleSave = () => {
        if(!formData.title || !formData.imageUrl) return alert("Title and Image required");
        
        let updatedCards;
        if(formData.id) {
            updatedCards = cards.map(c => c.id === formData.id ? formData : c);
        } else {
            const newCard = { ...formData, id: Date.now().toString() };
            updatedCards = [newCard, ...cards];
        }
        setCards(updatedCards);
        db.saveCards(updatedCards);
        setIsEditing(false);
    };

    const handleDelete = (id: string, e: React.MouseEvent) => {
        e.stopPropagation();
        if(confirm("Delete this card?")) {
            const updated = cards.filter(c => c.id !== id);
            setCards(updated);
            db.saveCards(updated);
        }
    };

    const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files?.[0]) {
            const reader = new FileReader();
            reader.onload = () => {
                 if (typeof reader.result === 'string') setFormData(prev => ({ ...prev, imageUrl: reader.result as string }));
            };
            reader.readAsDataURL(e.target.files[0]);
        }
    };

    return (
        <div className="min-h-screen pt-20 pb-20 px-4 bg-[#1a0b12]">
             <div className="absolute top-4 left-4 z-50">
                 <button onClick={() => onBack()} className="p-2 rounded-full bg-[var(--bg-input)] text-[var(--accent-primary)] hover:bg-[var(--accent-primary)] hover:text-white transition-colors"><ArrowLeft size={24}/></button>
            </div>
            {/* ... rest of component ... */}
            <div className="text-center mb-10">
                <h2 className="text-4xl font-bold text-[var(--text-main)] cursive text-shadow-glow">
                    <EditableText id="cards_header" defaultText="Art of Wishes" isAdmin={isAdmin} />
                </h2>
                {isAdmin && (
                    <button onClick={handleAddNew} className="mt-4 px-6 py-2 bg-pink-600 hover:bg-pink-500 text-white rounded-full font-bold flex items-center gap-2 mx-auto shadow-lg">
                        <Plus size={18}/> Add New Card
                    </button>
                )}
            </div>

            {/* Admin Edit Modal */}
            <AnimatePresence>
                {isEditing && (
                    <motion.div initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}} className="fixed inset-0 z-[100] bg-black/80 flex items-center justify-center p-4">
                        <motion.div className="bg-[#2a1b24] p-6 rounded-2xl max-w-md w-full border border-pink-500/30 shadow-2xl space-y-4">
                            <h3 className="text-xl font-bold text-pink-300">{formData.id ? 'Edit Card' : 'New Card'}</h3>
                            <input value={formData.title} onChange={e => setFormData({...formData, title: e.target.value})} placeholder="Title" className="w-full bg-black/30 border border-pink-500/30 rounded p-2 text-white"/>
                            <textarea value={formData.message} onChange={e => setFormData({...formData, message: e.target.value})} placeholder="Birthday Message" className="w-full bg-black/30 border border-pink-500/30 rounded p-2 text-white h-24"/>
                            
                            <div onClick={() => fileInputRef.current?.click()} className="border-2 border-dashed border-pink-500/30 rounded-lg p-4 text-center cursor-pointer hover:bg-white/5 h-40 flex items-center justify-center overflow-hidden">
                                {formData.imageUrl ? <img src={formData.imageUrl} className="h-full object-cover"/> : <div className="text-white/50 text-xs">Click to Upload Image</div>}
                            </div>
                            <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handlePhotoUpload}/>

                            <div className="flex gap-2 justify-end">
                                <button onClick={() => setIsEditing(false)} className="px-4 py-2 text-pink-300">Cancel</button>
                                <button onClick={handleSave} className="px-6 py-2 bg-pink-600 text-white rounded font-bold">Save</button>
                            </div>
                        </motion.div>
                    </motion.div>
                )}
            </AnimatePresence>

            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                {cards.map(card => (
                    <motion.div 
                        key={card.id}
                        layoutId={card.id}
                        onClick={() => setSelectedCard(card)}
                        className="cursor-pointer group relative aspect-[3/4] rounded-xl overflow-hidden shadow-lg border border-[var(--border-color)]"
                        whileHover={{ y: -5 }}
                    >
                         <img src={card.imageUrl} alt={card.title} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" />
                         <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex flex-col justify-end p-4">
                             <h3 className="text-white font-bold">{card.title}</h3>
                             {!isAdmin && <p className="text-pink-300 text-xs mt-1">Tap to Open Gift</p>}
                         </div>

                         {/* Admin Controls on Thumbnail */}
                         {isAdmin && (
                            <div className="absolute top-2 right-2 flex gap-1 opacity-100 bg-black/50 rounded-lg p-1 backdrop-blur-sm">
                                <button onClick={(e) => handleEdit(card, e)} className="p-1.5 text-blue-300 hover:text-white hover:bg-blue-600 rounded"><Edit3 size={14}/></button>
                                <button onClick={(e) => handleDelete(card.id, e)} className="p-1.5 text-red-300 hover:text-white hover:bg-red-600 rounded"><Trash2 size={14}/></button>
                            </div>
                         )}
                    </motion.div>
                ))}
            </div>

            <AnimatePresence>
                {selectedCard && (
                    <motion.div 
                        initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}}
                        className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-sm" 
                        onClick={() => setSelectedCard(null)}
                    >
                        {/* Custom Modal Content Wrapper */}
                        <div onClick={e => e.stopPropagation()} className="max-w-lg w-full relative">
                            <button onClick={() => setSelectedCard(null)} className="absolute -top-12 right-0 text-white/50 hover:text-white"><X size={32}/></button>
                            
                            {/* IF ADMIN: Show Content Directly */}
                            {isAdmin ? (
                                <Card3DView card={selectedCard} />
                            ) : (
                                /* IF USER: Show Scratch Layer First */
                                <UserScratchExperience card={selectedCard} />
                            )}
                        </div>
                    </motion.div>
                )}
            </AnimatePresence>
        </div>
    )
}

// Helper: The 3D Card Content
const Card3DView = ({ card }: { card: GreetingCard }) => {
    return (
        <motion.div 
            initial={{ scale: 0.8, rotateY: 90 }}
            animate={{ scale: 1, rotateY: 0 }}
            transition={{ type: "spring", damping: 15 }}
            className="perspective-1000"
        >
            <div className="bg-[#2a1b24] rounded-2xl overflow-hidden shadow-[0_0_50px_rgba(236,72,153,0.3)] border border-pink-500/20 transform transition-transform duration-500 hover:rotate-y-6 preserve-3d">
                <div className="relative h-96 overflow-hidden">
                    <img src={card.imageUrl} className="w-full h-full object-cover" />
                    <div className="absolute inset-0 bg-gradient-to-t from-[#2a1b24] to-transparent"></div>
                </div>
                <div className="p-8 text-center relative z-10 -mt-20">
                    <h3 className="text-4xl font-bold text-white cursive mb-6 text-shadow-glow">{card.title}</h3>
                    <p className="text-pink-100 font-serif italic text-lg leading-relaxed whitespace-pre-wrap">"{card.message}"</p>
                    <div className="mt-8 flex justify-center gap-4">
                        <button className="flex items-center gap-2 px-6 py-2 bg-pink-600 text-white rounded-full text-sm font-bold hover:bg-pink-500 transition-colors shadow-lg animate-pulse">
                            <Heart size={16} fill="currentColor"/> Love This
                        </button>
                    </div>
                </div>
            </div>
        </motion.div>
    );
}

// Helper: Scratch Experience wrapper for User
const UserScratchExperience = ({ card }: { card: GreetingCard }) => {
    const [isRevealed, setIsRevealed] = useState(false);

    return (
        <div className="relative w-full aspect-[3/4] max-h-[600px] rounded-2xl overflow-hidden shadow-2xl">
             {/* The Underlying Content (3D View) - Visible only after scratch/reveal */}
             <div className={`absolute inset-0 bg-black transition-opacity duration-1000 ${isRevealed ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'}`}>
                 {isRevealed && <Card3DView card={card} />}
             </div>

             {/* The Scratch Layer - Fades out on reveal */}
             <motion.div 
                animate={isRevealed ? { opacity: 0, pointerEvents: 'none' } : { opacity: 1 }}
                transition={{ duration: 1 }}
                className="absolute inset-0 z-20"
             >
                 <ScratchCard 
                    imageSrc="" // No image needed for generic cover
                    text="" // We just want the cover
                    coverText="Scratch to Open Gift"
                    scratchType="rose"
                    onReveal={() => setIsRevealed(true)}
                    className="w-full h-full"
                 />
                 {/* Decorative Gift Icon on top of scratch card before scratch */}
                 {!isRevealed && (
                    <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 pointer-events-none flex flex-col items-center text-white/80">
                        <Gift size={64} className="mb-4 animate-bounce"/>
                        <p className="text-xl font-bold uppercase tracking-widest text-shadow-glow">Surprise Inside</p>
                    </div>
                 )}
             </motion.div>
        </div>
    )
}

// Quiz Section
const QuizSection = ({ onBack, isAdmin }: {onBack: () => void, isAdmin?: boolean}) => {
    const [questions, setQuestions] = useState<QuizQuestion[]>([]);
    const [currentQ, setCurrentQ] = useState(0);
    const [score, setScore] = useState(0);
    const [showScore, setShowScore] = useState(false);
    const [reward, setReward] = useState("");

    useEffect(() => {
        setQuestions(db.getQuizzes());
    }, []);

    const handleAnswer = async (answer: string) => {
        if (answer === questions[currentQ].correctAnswer) {
            setScore(score + 1);
            confetti({ particleCount: 50, spread: 60, origin: { y: 0.6 } });
        }
        
        if (currentQ + 1 < questions.length) {
            setCurrentQ(currentQ + 1);
        } else {
            setShowScore(true);
            const loveMsg = await generateLoveReward();
            setReward(loveMsg);
        }
    };

    return (
        <div className="min-h-screen pt-20 pb-20 px-4 flex flex-col items-center">
             <div className="absolute top-4 left-4 z-50">
                 <button onClick={() => onBack()} className="p-2 rounded-full bg-[var(--bg-input)] text-[var(--accent-primary)] hover:bg-[var(--accent-primary)] hover:text-white transition-colors"><ArrowLeft size={24}/></button>
            </div>
            
            <GlassCard className="max-w-2xl w-full p-8 text-center relative overflow-hidden">
                {showScore ? (
                    <div className="space-y-6">
                        <div className="w-24 h-24 bg-gradient-to-tr from-yellow-400 to-orange-500 rounded-full flex items-center justify-center mx-auto text-4xl shadow-lg animate-bounce">🏆</div>
                        <h2 className="text-3xl font-bold text-[var(--text-main)]">Quiz Completed!</h2>
                        <p className="text-xl text-[var(--accent-secondary)]">You scored {score} out of {questions.length}</p>
                        
                        <div className="bg-[var(--bg-input)] p-6 rounded-xl border border-[var(--accent-primary)]/30 mt-6">
                            <h3 className="text-sm uppercase tracking-widest text-[var(--text-muted)] mb-2">Your Love Reward</h3>
                            <p className="text-lg font-serif italic text-[var(--text-main)]">{reward}</p>
                        </div>
                        
                        <button onClick={() => {setShowScore(false); setCurrentQ(0); setScore(0);}} className="mt-4 text-sm text-[var(--text-muted)] hover:text-[var(--text-main)] underline">Play Again</button>
                    </div>
                ) : questions.length > 0 ? (
                    <div>
                        <div className="flex justify-between text-xs font-bold text-[var(--text-muted)] uppercase tracking-wider mb-8">
                            <span>Question {currentQ + 1}/{questions.length}</span>
                            <span>Score: {score}</span>
                        </div>
                        
                        <h2 className="text-2xl font-bold text-[var(--text-main)] mb-8 leading-relaxed">
                             {questions[currentQ].question}
                        </h2>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            {questions[currentQ].options.map((opt, idx) => (
                                <GlowingButton key={idx} variant="secondary" onClick={() => handleAnswer(opt)} className="w-full py-4 text-lg">
                                    {opt}
                                </GlowingButton>
                            ))}
                        </div>
                    </div>
                ) : (
                    <p>Loading Quiz...</p>
                )}
            </GlassCard>
        </div>
    )
}

// AI Magic Section
const AIMagicSection = ({ onBack, isAdmin }: {onBack: () => void, isAdmin?: boolean}) => {
    const [mood, setMood] = useState("");
    const [poem, setPoem] = useState("");
    const [loading, setLoading] = useState(false);

    const handleMagic = async () => {
        if(!mood) return;
        setLoading(true);
        const result = await generatePoem(mood);
        setPoem(result);
        setLoading(false);
    };

    return (
        <div className="min-h-screen pt-20 pb-20 px-4 flex flex-col items-center">
             <div className="absolute top-4 left-4 z-50">
                 <button onClick={() => onBack()} className="p-2 rounded-full bg-[var(--bg-input)] text-[var(--accent-primary)] hover:bg-[var(--accent-primary)] hover:text-white transition-colors"><ArrowLeft size={24}/></button>
            </div>
            
            <h2 className="text-4xl font-bold text-[var(--text-main)] cursive text-center mb-2 text-shadow-glow">
                <EditableText id="magic_header" defaultText="AI Magic Wand" isAdmin={isAdmin} />
            </h2>
            <p className="text-[var(--text-muted)] text-center mb-10">Generate a poem based on your mood</p>
            
            <GlassCard className="max-w-md w-full p-8 space-y-6">
                <div>
                    <label className="text-xs font-bold text-[var(--accent-primary)] uppercase tracking-wider mb-2 block">How are you feeling?</label>
                    <GlassInput value={mood} onChange={e => setMood(e.target.value)} placeholder="e.g., Happy, Romantic, Nostalgic..." className="text-[var(--text-main)]"/>
                </div>
                
                <GlowingButton onClick={handleMagic} disabled={loading} className="w-full">
                    {loading ? <span className="animate-pulse">Weaving Magic...</span> : <><Wand2 size={18}/> Generate Poem</>}
                </GlowingButton>
                
                {poem && (
                    <motion.div initial={{opacity:0, y:10}} animate={{opacity:1, y:0}} className="bg-[var(--bg-input)] p-6 rounded-xl border border-[var(--accent-secondary)]/30 text-center relative">
                        <Sparkles size={16} className="absolute top-2 right-2 text-yellow-400 animate-spin-slow"/>
                        <p className="font-serif italic text-[var(--text-main)] whitespace-pre-line leading-loose">{poem}</p>
                    </motion.div>
                )}
            </GlassCard>
        </div>
    )
}

// Surprise Portal Section
const SurprisePortalSection = ({ onBack, isAdmin }: {onBack: () => void, isAdmin?: boolean}) => {
     const [items, setItems] = useState<SurpriseItem[]>([]);
     
     useEffect(() => {
         setItems(db.getSurprises());
     }, []);

     const toggleLock = (id: string) => {
         if(!isAdmin) return;
         const updated = items.map(i => i.id === id ? {...i, isLocked: !i.isLocked} : i);
         setItems(updated);
         db.saveSurprises(updated);
     }

     return (
        <div className="min-h-screen pt-20 pb-20 px-4">
             <div className="absolute top-4 left-4 z-50">
                 <button onClick={() => onBack()} className="p-2 rounded-full bg-[var(--bg-input)] text-[var(--accent-primary)] hover:bg-[var(--accent-primary)] hover:text-white transition-colors"><ArrowLeft size={24}/></button>
            </div>
            <h2 className="text-4xl font-bold text-[var(--text-main)] cursive text-center mb-10 text-shadow-glow">
                <EditableText id="portal_header" defaultText="Hidden Surprises" isAdmin={isAdmin} />
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
                {items.map((item, index) => (
                    <GlassCard key={item.id} className={`p-6 relative overflow-hidden transition-all ${item.isLocked ? 'opacity-80' : 'hover:scale-105 shadow-xl border-[var(--accent-secondary)]/50'}`}>
                        {item.isLocked ? (
                            <div className="flex flex-col items-center justify-center py-8 text-[var(--text-muted)]">
                                <Lock size={48} className="mb-4"/>
                                <h3 className="font-bold text-xl mb-1">Locked Surprise</h3>
                                <p className="text-sm">Unlocks on a special time</p>
                            </div>
                        ) : (
                            <div className="text-center py-8">
                                <Gift size={48} className="mx-auto mb-4 text-[var(--accent-primary)] animate-bounce"/>
                                <h3 className="font-bold text-xl text-[var(--text-main)] mb-2">{item.title}</h3>
                                <p className="text-[var(--text-muted)]">{item.description}</p>
                            </div>
                        )}
                        
                        {isAdmin && (
                            <button onClick={() => toggleLock(item.id)} className="absolute top-2 right-2 bg-[var(--bg-input)] p-2 rounded-full text-[var(--text-main)] hover:bg-[var(--accent-primary)]">
                                {item.isLocked ? "Unlock" : "Lock"}
                            </button>
                        )}
                    </GlassCard>
                ))}
            </div>
        </div>
     )
}

// 13 New Surprise Components Integration
const SurpriseCollectionSection: React.FC<{onBack: () => void, isAdmin?: boolean}> = ({onBack, isAdmin}) => {
    const [activeSurprise, setActiveSurprise] = useState<number | null>(null);

    const surprises = [
        { id: 1, title: "Emotional Rooms", icon: "🚪", component: EmotionalRooms },
        { id: 2, title: "Galaxy Wishes", icon: "🌌", component: GalaxyWishes },
        { id: 3, title: "Heartbeat Scanner", icon: "❤️", component: HeartbeatScanner },
        { id: 4, title: "Mirror of Truth", icon: "🪞", component: MirrorOfTruth },
        { id: 5, title: "Love Weather", icon: "🌦️", component: LoveWeather },
        { id: 6, title: "Future Message", icon: "🔮", component: FutureMessage },
        { id: 7, title: "Make a Wish", icon: "🌠", component: MakeAWish },
        { id: 8, title: "Treasure Boxes", icon: "🎁", component: TreasureBoxes },
        { id: 9, title: "Love Reel", icon: "🎬", component: LoveReel },
        { id: 10, title: "Wishing Tree", icon: "🌳", component: WishingTree },
        { id: 11, title: "Emotion Cards", icon: "🃏", component: EmotionScratchCards },
        { id: 12, title: "Aurora Sky", icon: "✨", component: AuroraSky },
        { id: 13, title: "Magical Library", icon: "📚", component: MagicalLibrary },
    ];

    if (activeSurprise !== null) {
        const SComponent = surprises.find(s => s.id === activeSurprise)?.component;
        return (
            <div className="relative">
                <button 
                    onClick={() => setActiveSurprise(null)} 
                    className="fixed top-4 left-4 z-50 p-2 rounded-full bg-black/50 text-white backdrop-blur-md hover:bg-black/70"
                >
                    <ArrowLeft size={24}/>
                </button>
                {SComponent && <SComponent isAdmin={isAdmin || false} />}
            </div>
        );
    }

    return (
        <div className="min-h-screen pt-20 pb-20 px-4">
             <div className="absolute top-4 left-4 z-50">
                 <button onClick={() => onBack()} className="p-2 rounded-full bg-[var(--bg-input)] text-[var(--accent-primary)] hover:bg-[var(--accent-primary)] hover:text-white transition-colors"><ArrowLeft size={24}/></button>
            </div>

            <div className="text-center mb-10">
                <h2 className="text-5xl font-bold text-[var(--text-main)] cursive text-shadow-glow">
                    <EditableText id="collection_hub_title" defaultText="Magic Surprise World" isAdmin={isAdmin} />
                </h2>
                <p className="text-[var(--text-muted)] mt-2 uppercase tracking-widest text-xs">Choose an experience</p>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 max-w-7xl mx-auto">
                {surprises.map((s) => (
                    <motion.button
                        key={s.id}
                        onClick={() => setActiveSurprise(s.id)}
                        whileHover={{ scale: 1.05, y: -5 }}
                        whileTap={{ scale: 0.95 }}
                        className="group relative h-48 rounded-2xl bg-[var(--bg-card)] border border-[var(--border-color)] overflow-hidden shadow-xl flex flex-col items-center justify-center gap-4"
                    >
                        <div className="absolute inset-0 bg-gradient-to-br from-[var(--accent-primary)]/10 to-[var(--accent-secondary)]/10 opacity-0 group-hover:opacity-100 transition-opacity"></div>
                        <div className="text-5xl filter drop-shadow-md group-hover:scale-110 transition-transform duration-300">{s.icon}</div>
                        <h3 className="font-bold text-[var(--text-main)] text-lg z-10">{s.title}</h3>
                        <div className="absolute bottom-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity text-[var(--accent-primary)]">
                            <Sparkles size={16} className="animate-spin-slow"/>
                        </div>
                    </motion.button>
                ))}
            </div>
        </div>
    )
}


// --- MASTER WISHES SECTION COMPONENTS ---

// 1. DATA CONSTANTS & HELPER TYPES

interface WishCardData {
  id: string;
  title: string;
  poem: string;
  img: string;
  type: string; // 'frost', 'gold', 'mist', 'night', 'ember', 'rose', 'forest'
}

const MASTER_ITEMS = [
    // --- SEASONS (1-6) ---
    { id: '1', group: 'SEASON', title: 'Winter Season', icon: '❄️', img: 'https://images.unsplash.com/photo-1483664852095-d6cc6870702d?w=500', subtitle: 'Warmth in Cold' },
    { id: '2', group: 'SEASON', title: 'Summer Season', icon: '☀️', img: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=500', subtitle: 'Bright & Radiant' },
    { id: '3', group: 'SEASON', title: 'Rainy / Monsoon', icon: '🌧️', img: 'https://images.unsplash.com/photo-1515694346937-94d85e41e6f0?w=500', subtitle: 'Rhythm of Love' },
    { id: '4', group: 'SEASON', title: 'Spring / Basant', icon: '🌸', img: 'https://images.unsplash.com/photo-1490750967868-58cb75069faf?w=500', subtitle: 'New Beginnings' },
    { id: '5', group: 'SEASON', title: 'Autumn / Patjhad', icon: '🍁', img: 'https://images.unsplash.com/photo-1509356843151-3e7d96241e11?w=500', subtitle: 'Colors of Change' },
    { id: '6', group: 'SEASON', title: 'Fog & Mist', icon: '🌫️', img: 'https://images.unsplash.com/photo-1485236715568-ddc5ee6ca227?w=500', subtitle: 'Mysterious Beauty' },

    // --- TIME (7-12) ---
    { id: '7', group: 'TIME', title: 'Morning Sunshine', icon: '☀️', img: 'https://images.unsplash.com/photo-1470252649378-9c29740c9fa8?w=500', subtitle: 'Rise & Shine' },
    { id: '8', group: 'TIME', title: 'Golden Sunset', icon: '🌅', img: 'https://images.unsplash.com/photo-1472120435266-53107fd0c44a?w=500', subtitle: 'Golden Hour' },
    { id: '9', group: 'TIME', title: 'Night & Moonlight', icon: '🌙', img: 'https://images.unsplash.com/photo-1532978028217-4504193dc54c?w=500', subtitle: 'Serene Glow' },
    { id: '10', group: 'TIME', title: 'Midnight Magic', icon: '⭐', img: 'https://images.unsplash.com/photo-1419242902214-272b3f66ee7a?w=500', subtitle: 'Silent Wishes' },
    { id: '11', group: 'TIME', title: 'Twilight / Shaam', icon: '🌆', img: 'https://images.unsplash.com/photo-1500322969630-a26ab6eb64cc?w=500', subtitle: 'Between Worlds' },
    { id: '12', group: 'TIME', title: 'Dawn / Subah', icon: '🌄', img: 'https://images.unsplash.com/photo-1505322022379-7c3353ee6291?w=500', subtitle: 'First Light' },

    // --- ELEMENTS (13-17) ---
    { id: '13', group: 'ELEMENTS', title: 'Water Element', icon: '💧', img: 'https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=500', subtitle: 'Flow & Pure' },
    { id: '14', group: 'ELEMENTS', title: 'Fire Element', icon: '🔥', img: 'https://images.unsplash.com/photo-1516026672322-bc52d61a55cd?w=500', subtitle: 'Passion & Warmth' },
    { id: '15', group: 'ELEMENTS', title: 'Air / Wind', icon: '🌬️', img: 'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=500', subtitle: 'Freedom' },
    { id: '16', group: 'ELEMENTS', title: 'Earth Element', icon: '🌎', img: 'https://images.unsplash.com/photo-1441974231531-c6227db76b6e?w=500', subtitle: 'Grounded Love' },
    { id: '17', group: 'ELEMENTS', title: 'Sky Element', icon: '☁️', img: 'https://images.unsplash.com/photo-1513002749550-c59d786b8e6c?w=500', subtitle: 'Limitless' },

    // --- NATURE (18-33) ---
    { id: '18', group: 'NATURE', title: 'Flowers Garden', icon: '🌺', img: 'https://images.unsplash.com/photo-1465146344425-f00d5f5c8f07?w=500', subtitle: 'Blooming Joy' },
    { id: '19', group: 'NATURE', title: 'Rose / Gulab', icon: '🌹', img: 'https://images.unsplash.com/photo-1496661415325-ef852f9c098f?w=500', subtitle: 'Classic Romance' },
    { id: '20', group: 'NATURE', title: 'Lotus / Kamal', icon: '🪷', img: 'https://images.unsplash.com/photo-1516562309702-86361a650eb1?w=500', subtitle: 'Purity' },
    { id: '21', group: 'NATURE', title: 'Rainbow', icon: '🌈', img: 'https://images.unsplash.com/photo-1506869640319-fe1a24fd76dc?w=500', subtitle: 'Seven Colors' },
    { id: '22', group: 'NATURE', title: 'Mountains', icon: '⛰️', img: 'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=500', subtitle: 'Majestic Peaks' },
    { id: '23', group: 'NATURE', title: 'River / Nadi', icon: '🏞️', img: 'https://images.unsplash.com/photo-1437482096254-e446a192357ea?w=500', subtitle: 'Eternal Flow' },
    { id: '24', group: 'NATURE', title: 'Lake / Jheel', icon: '🪣', img: 'https://images.unsplash.com/photo-1494548162494-384bba4ab999?w=500', subtitle: 'Still Waters' },
    { id: '25', group: 'NATURE', title: 'Ocean', icon: '🌊', img: 'https://images.unsplash.com/photo-1505118380757-91f5f5632de0?w=500', subtitle: 'Deep Blue' },
    { id: '26', group: 'NATURE', title: 'Waterfall', icon: '💦', img: 'https://images.unsplash.com/photo-1432405972618-c60b0225b8f9?w=500', subtitle: 'Cascading Joy' },
    { id: '27', group: 'NATURE', title: 'Forest', icon: '🌳', img: 'https://images.unsplash.com/photo-1448375240586-dfd8d395ea6c?w=500', subtitle: 'Green Serenity' },
    { id: '28', group: 'NATURE', title: 'Clouds', icon: '☁️', img: 'https://images.unsplash.com/photo-1534088568595-a066f410bcda?w=500', subtitle: 'Soft Dreams' },
    { id: '29', group: 'NATURE', title: 'Stars', icon: '✨', img: 'https://images.unsplash.com/photo-1516339901601-2e1b870294e2?w=500', subtitle: 'Twinkling Hope' },
    { id: '30', group: 'NATURE', title: 'Galaxy', icon: '🌌', img: 'https://images.unsplash.com/photo-1462331940185-007e89e5309f?w=500', subtitle: 'Cosmic Wonder' },
    { id: '31', group: 'NATURE', title: 'Sun & Noor', icon: '🔆', img: 'https://images.unsplash.com/photo-1541415712613-26c36c646067?w=500', subtitle: 'Radiance' },
    { id: '32', group: 'NATURE', title: 'Moon & Chand', icon: '🌙', img: 'https://images.unsplash.com/photo-1532693322450-2cb5c511067d?w=500', subtitle: 'Gentle Glow' },
    { id: '33', group: 'NATURE', title: 'Hues (7 Colors)', icon: '🎨', img: 'https://images.unsplash.com/photo-1500462918059-b1a0cb512f1d?w=500', subtitle: 'Vibrant Life' },

    // --- PLACES (34-40) ---
    { id: '34', group: 'PLACES', title: 'Snow Land', icon: '❄️🏔️', img: 'https://images.unsplash.com/photo-1517299321609-52687d1bc555?w=500', subtitle: 'White Paradise' },
    { id: '35', group: 'PLACES', title: 'Desert', icon: '🏜️', img: 'https://images.unsplash.com/photo-1509316975850-ff9c5deb0cd9?w=500', subtitle: 'Golden Sands' },
    { id: '36', group: 'PLACES', title: 'Village', icon: '🌾', img: 'https://images.unsplash.com/photo-1535940588839-5ad126868cc8?w=500', subtitle: 'Simple Life' },
    { id: '37', group: 'PLACES', title: 'City Lights', icon: '🌃', img: 'https://images.unsplash.com/photo-1477959858617-67f85cf4f1df?w=500', subtitle: 'Urban Dreams' },
    { id: '38', group: 'PLACES', title: 'Beach Vibes', icon: '🏖️', img: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=500', subtitle: 'Relaxation' },
    { id: '39', group: 'PLACES', title: 'Garden Romance', icon: '🌿', img: 'https://images.unsplash.com/photo-1585320806297-9794b3e4eeae?w=500', subtitle: 'Secret Path' },
    { id: '40', group: 'PLACES', title: 'Paradise', icon: '✨', img: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?w=500', subtitle: 'Heavenly' },

    // --- FANTASY (41-46) ---
    { id: '41', group: 'FANTASY', title: 'Fairy / Pari', icon: '🧚‍♀️', img: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=500', subtitle: 'Magical Wings' },
    { id: '42', group: 'FANTASY', title: 'Angel / Malak', icon: '👼', img: 'https://images.unsplash.com/photo-1499209974431-9dddcece7f88?w=500', subtitle: 'Divine Grace' },
    { id: '43', group: 'FANTASY', title: 'Magic', icon: '✨', img: 'https://images.unsplash.com/photo-1518199266791-5375a83190b7?w=500', subtitle: 'Sparkle & Shine' },
    { id: '44', group: 'FANTASY', title: 'Dreamland', icon: '💭', img: 'https://images.unsplash.com/photo-1483086431163-c803a0e581e6?w=500', subtitle: 'Sweet Dreams' },
    { id: '45', group: 'FANTASY', title: 'Fireflies', icon: '🪲', img: 'https://images.unsplash.com/photo-1500322969630-a26ab6eb64cc?w=500', subtitle: 'Night Lights' },
    { id: '46', group: 'FANTASY', title: 'Starlight Wishes', icon: '⭐', img: 'https://images.unsplash.com/photo-1464802686167-b939a6910659?w=500', subtitle: 'Make a Wish' },

    // --- EMOTION (47-50) ---
    { id: '47', group: 'EMOTION', title: 'Heartbeat', icon: '❤️', img: 'https://images.unsplash.com/photo-1518568814500-bf0f8d125f46?w=500', subtitle: 'Pulse of Life' },
    { id: '48', group: 'EMOTION', title: 'Eyes / Nazar', icon: '👁️', img: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=500', subtitle: 'Deep Soul' },
    { id: '49', group: 'EMOTION', title: 'Touch / Feel', icon: '🤲', img: 'https://images.unsplash.com/photo-1507646227500-4d3899666f8c?w=500', subtitle: 'Connection' },
    { id: '50', group: 'EMOTION', title: 'Soul / Rooh', icon: '🕊️', img: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=500', subtitle: 'Eternal Bond' },
];

// --- 2. CONTENT GENERATOR ENGINE ---
// This acts as the database and algorithmic poet to ensure every section has 10+ cards.

const generateCategoryContent = (categoryId: string, category: any): { cards: WishCardData[], theme: string, particles: string } => {
    // 1. Defined Visual Themes
    const THEME_MAP: Record<string, {type: string, particle: string}> = {
        'SEASON': { type: 'frost', particle: 'snow' },
        'TIME': { type: 'gold', particle: 'sparkles' },
        'ELEMENTS': { type: 'ember', particle: 'fire' },
        'NATURE': { type: 'forest', particle: 'leaf' },
        'PLACES': { type: 'mist', particle: 'cloud' },
        'FANTASY': { type: 'night', particle: 'star' },
        'EMOTION': { type: 'rose', particle: 'heart' }
    };
    
    // Override specific IDs
    const ID_OVERRIDES: Record<string, {type: string, particle: string}> = {
        '3': { type: 'mist', particle: 'rain' }, // Rain
        '2': { type: 'gold', particle: 'sun' }, // Summer
        '9': { type: 'night', particle: 'star' }, // Night
        '25': { type: 'mist', particle: 'bubble' }, // Ocean
        '47': { type: 'rose', particle: 'heart' }, // Heartbeat
        '14': { type: 'ember', particle: 'fire' }, // Fire
    };

    const visual = ID_OVERRIDES[categoryId] || THEME_MAP[category.group] || { type: 'gold', particle: 'sparkles' };

    // 2. Poetry Database & Generators
    
    // HELPER: Template Generator
    const generateFromTemplate = (themeName: string, count: number): WishCardData[] => {
        const templates = [
            `Is ${themeName} ki tarah, tumhari yaadein dil mein utar jati hain... Happy Birthday! ✨`,
            `${themeName} ki khubsurti bhi tumhare aage feeki hai... Tum meri zindagi ka noor ho. ❤️`,
            `Jese ${themeName} mein sukoon hai, wese hi tumhari baaton mein chain milta hai. Happy Birthday! 🎂`,
            `Har ${themeName} mujhe tumhari yaad dilata hai, tum mere dil ke mausam ho. 🌸`,
            `Duniya ke liye ye sirf ${themeName} hai, par mere liye ye tumhara ehsaas hai. Love you! 💖`,
            `${themeName} ka har pal gawah hai meri mohabbat ka... Janamdin Mubarak! 🎉`,
            `Tumhari muskaan jaise ${themeName} ki pehli kiran... Hamesha chamakti raho. ✨`,
            `${themeName} aata hai aur jaata hai, par tumhara pyaar hamesha rehta hai. Happy Birthday! ❤️`,
            `Meri dua hai ki ye ${themeName} tumhare liye dher saari khushiyan laye. 🤲`,
            `Tum ho toh har ${themeName} suhana hai, tum bin sab kuch veerana hai. Happy Birthday! 🌹`
        ];
        
        return Array.from({length: count}).map((_, i) => ({
            id: `${categoryId}_auto_${i}`,
            title: `${category.title} Love - ${i+1}`,
            poem: templates[i % templates.length],
            img: category.img,
            type: visual.type
        }));
    };

    // SPECIFIC STATIC DATASETS (High Quality Manual Content)
    
    // Winter (ID 1)
    if (categoryId === '1') {
        return {
            theme: 'bg-slate-900',
            particles: 'snow',
            cards: [
                { id: 'w1', title: "Sardi Ki Pehli Saans", poem: "सर्द हवाओं की पहली सांस जब चेहरे को छूती है,\nदिल में तेरे नाम की narm si roohani garmi उतर आती है।\nHappy Birthday, meri winter-wali rooh… ❄️❤️", type: 'frost', img: "https://images.unsplash.com/photo-1518717758536-85ae29035b6d?w=500" },
                { id: 'w2', title: "Barf Mein Mehka Tera Naam", poem: "गिरती बर्फ़ का हर कण\nतेरे नाम की ख़ुशबू लेकर दिल तक आता है।\nHappy Birthday, meri barf-si narm mohabbat. 🤍❄️", type: 'frost', img: "https://images.unsplash.com/photo-1483664852095-d6cc6870702d?w=500" },
                { id: 'w3', title: "Winter Coffee", poem: "ठंड में कॉफी की ख़ुशबू\nजब तेरी यादों के साथ घुलती है,\nदिल—pyali ki bhap ki tarah halka-halka garam hone lagta hai.\nHappy Birthday! ☕❄️", type: 'ember', img: "https://images.unsplash.com/photo-1517436073-3b1b1778796c?w=500" },
                { id: 'w4', title: "Shawl Ki Garmahat", poem: "तेरी याद—shawl की तरह दिल को जकड़ लेती है…\nनर्म, गरम और पूरी तरह mohabbat se bhaari.\nHappy Birthday! 🧣❤️", type: 'ember', img: "https://images.unsplash.com/photo-1577908920956-25805dc78f73?w=500" },
                { id: 'w5', title: "Dhundh Mein Teri Muskurahat", poem: "धुंधली सर्द सुबह में जब कुछ भी साफ़ नहीं दिखता,\nतब तेरी मुस्कान—suraj ki pehli kiran ban kar aati hai.\nHappy Birthday! 🌫️☀️", type: 'mist', img: "https://images.unsplash.com/photo-1485236715568-ddc5ee6ca227?w=500" },
                { id: 'w6', title: "Snow-Silence", poem: "बर्फ़ गिरती है… दुनिया ख़ामोश हो जाती है…\nऔर उस ख़ामोशी में teri yaad ki dhadkan गूँजती है।\nHappy Birthday! 🤍❄️", type: 'frost', img: "https://images.unsplash.com/photo-1548065460-7043868037a3?w=500" },
                { id: 'w7', title: "Frozen Fingers", poem: "ठंड में जमती उंगलियाँ तुम्हारा नाम लिखते ही\nphir se zinda हो जाती हैं।\nHappy Birthday, meri jaan! 🤲❤️", type: 'frost', img: "https://images.unsplash.com/photo-1542668579-22c6fb73d302?w=500" },
                { id: 'w8', title: "Snowfall Aur Tum", poem: "गिरती बर्फ़ जैसे आसमान की लिखी हुई love-poem हो।\nहर गिरती परत में tera naam, हर पिघलती बूंद में mera armaan.\nHappy Birthday! ❄️✨", type: 'frost', img: "https://images.unsplash.com/photo-1517299321609-52687d1bc555?w=500" },
                { id: 'w9', title: "Winter Love Story", poem: "सर्दियाँ सिर्फ़ मौसम नहीं, एक छोटी सी mohabbat bhari kahani हैं।\nजहाँ ठंड मौसम की होती है, और गर्माहट… सिर्फ़ tumhare naam की। ❤️", type: 'rose', img: "https://images.unsplash.com/photo-1528255915607-90dc5dd33280?w=500" },
                { id: 'w10', title: "Cold Window", poem: "खिड़की से बाहर ठंडी हवा, अंदर तेरी यादों की गर्माहट।\nइस contrast में हर सर्दी tumhare pyaar ki garmi से भर जाती है। ❄️❤️", type: 'mist', img: "https://images.unsplash.com/photo-1543329241-e945112185d2?w=500" }
            ]
        };
    }

    // Rain / Monsoon (ID 3)
    if (categoryId === '3') {
         return {
            theme: 'bg-blue-950',
            particles: 'rain',
            cards: [
                { id: 'r1', title: "Baarish Ki Pehli Boond", poem: "Barish ki pehli boond jab zameen ko chuti hai,\nWese hi tumhari yaad mere dil ko bhiga jati hai.\nHappy Birthday meri Zindagi! 🌧️💙", type: 'mist', img: "https://images.unsplash.com/photo-1515694346937-94d85e41e6f0?w=500" },
                { id: 'r2', title: "Mitti Ki Khushboo", poem: "Geeli mitti ki khushboo aur tumhara ehsaas,\nDono mere rooh mein baste hain.\nTum meri baarish ho. Janamdin Mubarak! 🌧️🌱", type: 'forest', img: "https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=500" },
                { id: 'r3', title: "Cloudy Skies", poem: "Baadal chaaye hain, par dil khush hai,\nKyunki tumhara khayal mere saath hai.\nHappy Birthday Sunshine! ☁️☀️", type: 'mist', img: "https://images.unsplash.com/photo-1534088568595-a066f410bcda?w=500" },
                { id: 'r4', title: "Dancing in Rain", poem: "Chalo aaj baarish mein bheegte hain,\nAur tumhare janamdin ka jashn manate hain.\nHappy Birthday! 💃🌧️", type: 'rose', img: "https://images.unsplash.com/photo-1515694346937-94d85e41e6f0?w=500" },
                { id: 'r5', title: "Window Drops", poem: "Khidki pe fisalti boondein tumhara naam likhti hain,\nHar boond mein tumhari tasveer dikhti hai.\nHappy Birthday! 🪟💧", type: 'mist', img: "https://images.unsplash.com/photo-1506744038136-46273834b3fb?w=500" },
                { id: 'r6', title: "Thunder & Heartbeat", poem: "Bijli ki kadak se dar nahi lagta,\nJab tak tumhara haath mere haath mein hai.\nHappy Birthday my protector! ⛈️❤️", type: 'night', img: "https://images.unsplash.com/photo-1505118380757-91f5f5632de0?w=500" },
                { id: 'r7', title: "Paper Boats", poem: "Kagaz ki kashti, baarish ka paani,\nAur hamari adhuri par khoobsurat kahani.\nHappy Birthday! ⛵💙", type: 'frost', img: "https://images.unsplash.com/photo-1432405972618-c60b0225b8f9?w=500" },
                { id: 'r8', title: "Tea & Rain", poem: "Chai, Baarish aur Tum,\nIsse behtar combination aur kya ho sakta hai?\nHappy Birthday! ☕🌧️", type: 'ember', img: "https://images.unsplash.com/photo-1511140973288-19bf21d7b771?w=500" },
                { id: 'r9', title: "Rainbow After Rain", poem: "Tum meri zindagi ka wo indradhanush ho,\nJo har toofan ke baad umeed lata hai.\nHappy Birthday! 🌈✨", type: 'gold', img: "https://images.unsplash.com/photo-1506869640319-fe1a24fd76dc?w=500" },
                { id: 'r10', title: "Eternal Rain", poem: "Ye baarish shayad ruk jaye,\nPar tumhare liye mera pyaar kabhi nahi rukega.\nHappy Birthday! 🌧️❤️", type: 'rose', img: "https://images.unsplash.com/photo-1437482096254-e446a192357ea?w=500" }
            ]
        }
    }

    // Love / Heartbeat (ID 47)
    if (categoryId === '47' || categoryId === '48' || categoryId === '50') {
        return {
            theme: 'bg-pink-950',
            particles: 'heart',
            cards: [
                { id: 'l1', title: "Dhadkan", poem: "Meri har dhadkan sirf tumhara naam leti hai,\nTum ho toh main hoon. Happy Birthday Jaan! ❤️", type: 'rose', img: "https://images.unsplash.com/photo-1518568814500-bf0f8d125f46?w=500" },
                { id: 'l2', title: "Rooh Ka Rishta", poem: "Jism se pare, yeh rooh ka bandhan hai,\nTum meri aakhri mohabbat ho. Janamdin Mubarak! ✨", type: 'mist', img: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=500" },
                { id: 'l3', title: "Aankhon Ki Zuban", poem: "Jo lab nahi keh paate, wo aankhein bolti hain,\nTumhari tasveer inme hamesha rehti hai. Happy Birthday! 👁️❤️", type: 'gold', img: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=500" },
                { id: 'l4', title: "Zindagi", poem: "Tum meri puri duniya ho,\nTumhare bina har lamha adhoora hai. Happy Birthday! 🌍❤️", type: 'night', img: "https://images.unsplash.com/photo-1516589178581-6cd7833ae3b2?w=500" },
                { id: 'l5', title: "Ishq", poem: "Log kehte hain ishq naseeb se milta hai,\nMujhe toh khuda ne tumhare roop mein jannat di hai. ❤️", type: 'rose', img: "https://images.unsplash.com/photo-1511140973288-19bf21d7b771?w=500" },
                { id: 'l6', title: "Vaada", poem: "Aaj ke din ek vaada hai,\nAkhri saans tak tumhara saath nibhaunga. Happy Birthday! 🤝❤️", type: 'ember', img: "https://images.unsplash.com/photo-1507646227500-4d3899666f8c?w=500" },
                { id: 'l7', title: "Muskurahat", poem: "Tumhari ek muskurahat mere saare gham mita deti hai,\nHamesha haste rehna. Happy Birthday! 😊💛", type: 'gold', img: "https://images.unsplash.com/photo-1531303435785-3853fb035c27?w=500" },
                { id: 'l8', title: "Yaadein", poem: "Tumhare saath bitaya har pal khaas hai,\nAur aane wala har pal ek naya sapna hai. Happy Birthday! 💭❤️", type: 'mist', img: "https://images.unsplash.com/photo-1492633423870-43d1cd2775eb?w=500" },
                { id: 'l9', title: "Sukoon", poem: "Tumhari baahon mein jo sukoon hai,\nWo duniya ke kisi kone mein nahi. Happy Birthday! 🏡❤️", type: 'forest', img: "https://images.unsplash.com/photo-1517849845537-4d257902454a?w=500" },
                { id: 'l10', title: "Hamesha", poem: "Happy Birthday my forever,\nTum hi shuruat ho, tum hi ant ho. ∞❤️", type: 'night', img: "https://images.unsplash.com/photo-1534447677768-be436bb09401?w=500" }
            ]
        }
    }

    // Default Fallback Generator for all other 40+ categories
    return {
        theme: category.group === 'NATURE' ? 'bg-green-950' : category.group === 'TIME' ? 'bg-indigo-950' : 'bg-slate-950',
        particles: visual.particle,
        cards: generateFromTemplate(category.title, 12) // Generate 12 unique cards per section
    };
};

// --- 3. UNIVERSAL CATEGORY VIEW ---

const CategoryDetailView = ({ categoryId, onBack, isAdmin }: { categoryId: string, onBack: () => void, isAdmin?: boolean }) => {
    const category = MASTER_ITEMS.find(i => i.id === categoryId);
    
    // Generate content on mount
    const content = useMemo(() => {
        if (!category) return null;
        return generateCategoryContent(categoryId, category);
    }, [categoryId, category]);

    if (!category || !content) return <div>Loading...</div>;

    // Background Particle Renderer
    const renderAtmosphere = () => {
        if (content.particles === 'snow') {
             return (
                 <div className="absolute inset-0 pointer-events-none">
                     {Array.from({length: 40}).map((_, i) => (
                         <div key={i} className="absolute text-white/30 animate-[floatUp_10s_linear_infinite]" style={{left: `${Math.random()*100}%`, animationDelay: `${Math.random()*5}s`, fontSize: `${Math.random()*20+10}px`}}>❄️</div>
                     ))}
                 </div>
             )
        }
        if (content.particles === 'rain') {
             return (
                 <div className="absolute inset-0 pointer-events-none bg-[url('https://www.transparenttextures.com/patterns/diagonal-stripes.png')] opacity-10">
                     {Array.from({length: 60}).map((_,i) => (
                         <div key={i} className="absolute top-0 w-[1px] h-16 bg-blue-300 opacity-40 animate-[rain_0.7s_linear_infinite]" 
                              style={{left: `${Math.random()*100}%`, animationDelay: `${Math.random()}s`}} 
                         />
                     ))}
                     <style>{`@keyframes rain { 0% {transform: translateY(-50px)} 100% {transform: translateY(110vh)} }`}</style>
                 </div>
             )
        }
        if (content.particles === 'leaf') {
             return (
                 <div className="absolute inset-0 pointer-events-none">
                     {Array.from({length: 30}).map((_, i) => (
                         <Leaf key={i} size={Math.random()*15+10} className="absolute text-green-400/30 animate-[spin_4s_linear_infinite]" 
                               style={{left: `${Math.random()*100}%`, top: `${Math.random()*100}%`, animationDuration: `${Math.random()*5+5}s`}} 
                         />
                     ))}
                 </div>
             )
        }
        if (content.particles === 'star') {
             return (
                 <div className="absolute inset-0 pointer-events-none">
                     {Array.from({length: 50}).map((_, i) => (
                         <div key={i} className="absolute rounded-full bg-white animate-pulse" 
                              style={{width: Math.random()*3, height: Math.random()*3, left: `${Math.random()*100}%`, top: `${Math.random()*100}%`}} 
                         />
                     ))}
                 </div>
             )
        }
        // Default sparkles
        return (
             <div className="absolute inset-0 pointer-events-none">
                 {Array.from({length: 30}).map((_, i) => (
                     <Sparkles key={i} size={Math.random()*20} className="absolute text-yellow-200/30 animate-pulse" 
                           style={{left: `${Math.random()*100}%`, top: `${Math.random()*100}%`}} 
                     />
                 ))}
             </div>
        )
    };

    return (
        <div className={`min-h-screen pt-20 pb-20 px-2 sm:px-4 relative overflow-hidden ${content.theme}`}>
             {/* Dynamic Atmosphere */}
             <div className="absolute inset-0 z-0 opacity-40 pointer-events-none">
                  <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/stardust.png')] opacity-20"></div>
                  {renderAtmosphere()}
             </div>

             <div className="absolute top-4 left-4 z-50">
                 <button onClick={onBack} className="p-2 rounded-full bg-white/10 text-white hover:bg-white/20 backdrop-blur-md transition-colors border border-white/20"><ArrowLeft size={24}/></button>
            </div>

            <div className="relative z-10 text-center mb-8 sm:mb-12 mt-4">
                 <div className="inline-block p-4 rounded-full bg-white/5 border border-white/10 mb-4 text-4xl animate-bounce backdrop-blur-sm shadow-lg">{category.icon}</div>
                 <h2 className="text-4xl sm:text-5xl md:text-6xl font-bold text-white cursive text-shadow-glow mb-2 sm:mb-4">
                     {category.title}
                 </h2>
                 <p className="text-white/70 uppercase tracking-widest text-xs sm:text-sm font-bold bg-black/20 inline-block px-4 py-1 rounded-full backdrop-blur-md">
                     {category.subtitle} • {content.cards.length} Wishes
                 </p>
            </div>

            {/* Content Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 sm:gap-8 relative z-10 max-w-7xl mx-auto pb-10">
                 {content.cards.map((card, index) => (
                     <motion.div
                        key={card.id}
                        initial={{ opacity: 0, scale: 0.95, y: 30 }}
                        animate={{ opacity: 1, scale: 1, y: 0 }}
                        transition={{ delay: index * 0.05 }}
                        className="relative group px-2 sm:px-0"
                     >
                         <ScratchCard 
                            imageSrc={card.img}
                            text={card.poem}
                            coverText={card.title}
                            scratchType={card.type as any}
                            className="h-[450px] sm:h-96 border-2 border-white/10 shadow-[0_0_20px_rgba(0,0,0,0.3)] group-hover:shadow-[0_0_40px_rgba(255,255,255,0.2)] w-full bg-black/40 backdrop-blur-sm"
                         />
                     </motion.div>
                 ))}
            </div>
        </div>
    );
};


// --- NEW SECTION: MASTER WISHES SECTION (50 CATEGORIES) ---
const MasterWishesSection: React.FC<{onBack: () => void, isAdmin?: boolean}> = ({ onBack, isAdmin }) => {
    const [activeGroup, setActiveGroup] = useState('ALL');
    const [selectedSub, setSelectedSub] = useState<string | null>(null);

    // Group Definitions
    const groups = [
        { id: 'ALL', label: 'All Wishes' },
        { id: 'SEASON', label: 'Seasons' },
        { id: 'TIME', label: 'Day & Time' },
        { id: 'ELEMENTS', label: 'Elements' },
        { id: 'NATURE', label: 'Nature' },
        { id: 'PLACES', label: 'Places' },
        { id: 'FANTASY', label: 'Fantasy' },
        { id: 'EMOTION', label: 'Emotions' }
    ];

    const filteredItems = activeGroup === 'ALL' ? MASTER_ITEMS : MASTER_ITEMS.filter(i => i.group === activeGroup);

    // If a sub-section is selected, render the Generic View
    if (selectedSub) {
        return <CategoryDetailView categoryId={selectedSub} onBack={() => setSelectedSub(null)} isAdmin={isAdmin} />
    }
    
    return (
        <div className="pt-20 pb-20 px-4 max-w-7xl mx-auto min-h-screen">
             <div className="absolute top-4 left-4 z-50">
                <button onClick={onBack} className="p-2 rounded-full bg-[var(--bg-input)] text-[var(--accent-primary)] hover:bg-[var(--accent-primary)] hover:text-white transition-colors">
                        <ArrowLeft size={24}/>
                </button>
             </div>

             <div className="text-center mb-10 relative">
                 <h2 className="text-4xl sm:text-5xl md:text-6xl font-bold text-[var(--text-main)] cursive text-shadow-glow mb-4">
                     <EditableText id="master_hub_title" defaultText="Wishes & Feelings" isAdmin={isAdmin}/>
                 </h2>
                 <p className="text-[var(--text-muted)] tracking-widest uppercase text-xs opacity-70">Select a category to explore</p>
             </div>

             {/* Category Tabs - Mobile Scrollable */}
             <div className="flex overflow-x-auto pb-4 gap-2 mb-8 sticky top-20 z-40 bg-[var(--bg-main)]/95 backdrop-blur-md p-2 -mx-4 px-4 sm:mx-0 sm:rounded-2xl sm:p-4 sm:justify-center border-b sm:border border-[var(--border-color)] no-scrollbar">
                 {groups.map(g => (
                     <button
                        key={g.id}
                        onClick={() => setActiveGroup(g.id)}
                        className={`whitespace-nowrap px-4 py-2 rounded-full text-xs font-bold uppercase tracking-wider transition-all transform flex-shrink-0 ${activeGroup === g.id ? 'bg-[var(--accent-primary)] text-white scale-105 shadow-lg' : 'bg-[var(--bg-input)] text-[var(--text-muted)] hover:bg-[var(--bg-card)]'}`}
                     >
                         {g.label}
                     </button>
                 ))}
             </div>

             {/* 3D Grid: 2 cols on mobile, 3 md, 4 lg */}
             <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-6 perspective-[1000px]">
                 {filteredItems.map((item, index) => (
                     <motion.button
                        key={item.id}
                        onClick={() => setSelectedSub(item.id)}
                        initial={{ opacity: 0, y: 50, rotateX: 10 }}
                        animate={{ opacity: 1, y: 0, rotateX: 0 }}
                        transition={{ delay: index * 0.05 }}
                        whileHover={{ scale: 1.05, rotateY: 5, zIndex: 10, boxShadow: "0 25px 50px -12px rgba(0, 0, 0, 0.5)" }}
                        whileTap={{ scale: 0.95 }}
                        // Mobile: shorter (h-40) for dense grid. Desktop: h-64
                        className="group relative h-40 sm:h-64 rounded-2xl overflow-hidden shadow-xl preserve-3d transition-all duration-500 bg-[var(--bg-card)] border border-[var(--border-color)]"
                     >
                         {/* Background Image with editable capability */}
                         <div className="absolute inset-0 transition-transform duration-700 group-hover:scale-110">
                            <EditableImage id={`master_thumb_${item.id}`} defaultSrc={item.img} isAdmin={isAdmin} className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-opacity"/>
                         </div>
                         
                         {/* Gradient Overlay */}
                         <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent"></div>

                         {/* Content */}
                         <div className="absolute inset-0 flex flex-col justify-end p-3 sm:p-4 text-left transform translate-z-20">
                             <div className="bg-white/10 backdrop-blur-md w-8 h-8 sm:w-10 sm:h-10 rounded-full flex items-center justify-center text-lg sm:text-xl mb-1 sm:mb-2 border border-white/20 shadow-lg group-hover:scale-110 transition-transform">
                                 {item.icon}
                             </div>
                             <h3 className="text-white font-bold text-sm sm:text-xl leading-tight text-shadow-glow line-clamp-2">
                                 <EditableText id={`master_label_${item.id}`} defaultText={item.title} isAdmin={isAdmin} />
                             </h3>
                             <p className="text-white/70 text-[10px] uppercase tracking-widest font-bold mt-1 group-hover:text-white transition-colors hidden sm:block">
                                 {item.subtitle}
                             </p>
                         </div>

                         {/* Hover Shine Effect (Desktop mostly) */}
                         <div className="absolute inset-0 bg-gradient-to-tr from-white/0 via-white/10 to-white/0 translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-1000 hidden sm:block"></div>
                     </motion.button>
                 ))}
             </div>
        </div>
    );
};

// --- ULTRA REALISTIC SUB-COMPONENTS ---
// ... (Including EmotionalRooms, GalaxyWishes, HeartbeatScanner, MirrorOfTruth, LoveWeather, FutureMessage, MakeAWish, TreasureBoxes, LoveReel, WishingTree, EmotionScratchCards, AuroraSky, MagicalLibrary as in previous file - just ensuring they exist)

// 1. Emotional Rooms (3D Parallax & Depth)
const EmotionalRooms = ({ isAdmin }: { isAdmin: boolean }) => {
    const [selectedRoom, setSelectedRoom] = useState<string | null>(null);
    const rooms = [
        { name: 'Love', id: 'room_love', color: 'from-pink-600 to-rose-900', img: 'https://images.unsplash.com/photo-1518199266791-5375a83190b7?w=600' },
        { name: 'Care', id: 'room_care', color: 'from-blue-600 to-indigo-900', img: 'https://images.unsplash.com/photo-1516589178581-6cd7833ae3b2?w=600' },
        { name: 'Appreciation', id: 'room_appreciation', color: 'from-amber-500 to-orange-800', img: 'https://images.unsplash.com/photo-1499209974431-9dddcece7f88?w=600' },
        { name: 'Memory', id: 'room_memory', color: 'from-purple-600 to-violet-900', img: 'https://images.unsplash.com/photo-1506784983877-45594efa4cbe?w=600' },
        { name: 'Happiness', id: 'room_happiness', color: 'from-green-500 to-emerald-900', img: 'https://images.unsplash.com/photo-1519834785169-98be25ec3f84?w=600' }
    ];

    // Unique wishes per room (Defaults)
    const defaultWishes: Record<string, string> = {
        Love: "In this room, only love exists. You are loved beyond measure.",
        Care: "Take a deep breath. You are cared for, always.",
        Appreciation: "Thank you for being the light in so many lives.",
        Memory: "Every moment with you is a treasure kept safe here.",
        Happiness: "May your smile never fade, just like the sun in this room."
    };
    
    return (
        <div className="min-h-screen bg-black flex flex-col items-center justify-center p-4 relative overflow-hidden perspective-2000">
            <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/dark-matter.png')] opacity-20"></div>
            <h2 className="text-5xl text-white cursive mb-12 relative z-10 text-shadow-glow">
                <EditableText id="rooms_main_title" defaultText="Emotional Portals" isAdmin={isAdmin}/>
            </h2>
            
            <div className="flex flex-wrap justify-center gap-8 relative z-10 max-w-6xl">
                {rooms.map((room) => (
                    <motion.div 
                        key={room.id} 
                        onClick={() => setSelectedRoom(room.name)} 
                        whileHover={{ y: -20, scale: 1.05, rotateY: 10 }}
                        className="cursor-pointer group relative preserve-3d transition-transform duration-500"
                    >
                        {/* 3D Door Effect */}
                        <div className={`w-40 h-64 rounded-t-full relative overflow-hidden shadow-[0_20px_50px_rgba(0,0,0,0.5)] border-4 border-white/10 group-hover:border-white/50 transition-colors`}>
                             {/* Background Image Editable */}
                             <div className="absolute inset-0">
                                 <EditableImage id={`${room.id}_bg`} defaultSrc={room.img} isAdmin={isAdmin} className="w-full h-full object-cover opacity-60 group-hover:opacity-100 transition-opacity duration-500" />
                             </div>
                             <div className={`absolute inset-0 bg-gradient-to-t ${room.color} mix-blend-overlay opacity-80`}></div>
                             <div className="absolute bottom-0 inset-x-0 h-1/2 bg-gradient-to-t from-black to-transparent"></div>
                             
                             <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-500 transform translate-y-4 group-hover:translate-y-0">
                                 <DoorOpen size={40} className="text-white drop-shadow-lg" />
                             </div>
                        </div>
                        <div className="text-center mt-4 transform translate-z-10">
                            <p className="text-white font-bold text-xl tracking-widest uppercase text-shadow-glow">
                                <EditableText id={`${room.id}_label`} defaultText={room.name} isAdmin={isAdmin} />
                            </p>
                        </div>
                    </motion.div>
                ))}
            </div>

            <AnimatePresence>
                {selectedRoom && (
                    <motion.div initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}} className="fixed inset-0 z-50 flex items-center justify-center bg-black/95 p-4" onClick={() => setSelectedRoom(null)}>
                        <motion.div 
                            initial={{ scale: 0.8, rotateX: 20 }} animate={{ scale: 1, rotateX: 0 }} exit={{ scale: 0.8, opacity: 0 }}
                            className="bg-white/10 backdrop-blur-xl border border-white/20 rounded-3xl p-8 max-w-md w-full shadow-2xl relative" 
                            onClick={e => e.stopPropagation()}
                        >
                            <button onClick={() => setSelectedRoom(null)} className="absolute top-4 right-4 text-white/50 hover:text-white"><ArrowLeft size={20}/></button>
                            <h3 className="text-3xl font-bold text-center mb-6 text-white cursive">{selectedRoom} Room</h3>
                            <div className="rounded-xl overflow-hidden shadow-inner border border-white/10">
                                <ScratchCard 
                                   imageSrc={rooms.find(r => r.name === selectedRoom)?.img || ""} 
                                   text={<EditableText id={`room_wish_${rooms.find(r => r.name === selectedRoom)?.id}`} defaultText={defaultWishes[selectedRoom] || "Welcome!"} isAdmin={isAdmin}/> as any}
                                />
                            </div>
                            <p className="text-center mt-4 text-sm text-white/50 flex items-center justify-center gap-2">
                                <Sparkles size={12}/> Scratch the Magic Key to enter <Sparkles size={12}/>
                            </p>
                        </motion.div>
                    </motion.div>
                )}
            </AnimatePresence>
        </div>
    );
}

// 2. Galaxy Wishes (Interactive Star Field)
const GalaxyWishes = ({ isAdmin }: { isAdmin: boolean }) => {
    const [stars, setStars] = useState<{id: string, top:number, left:number, type: 'normal'|'secret', size: number, color: string, defaultWish: string}[]>([]);
    const [popup, setPopup] = useState<string | null>(null);

    // UNIQUE WISHES FOR EVERY STAR
    const getStarWish = (index: number) => {
        const wishes = [
            "You are stardust with a soul.", "Shine brighter than the sun.", "The universe dances for you.",
            "Your potential is infinite.", "Keep looking up.", "You are a masterpiece of the cosmos.",
            "Dream big, little star.", "Your light guides others.", "Magic is real, and it's you.",
            "Navigate by your own heart.", "A galaxy of joy awaits you.", "Shoot for the moon.",
            "You are loved to infinity.", "Sparkle everyday.", "Cosmic blessings on you.",
            "Radiate positivity.", "Your spirit is unbreakable.", "Glow through the dark.",
            "Star light, star bright.", "You are my favorite wish.", "Celestial beauty.",
            "Orbiting your happiness.", "Gravity cannot hold you.", "Supernova energy.",
            "Nebula dreams.", "Constellation of love.", "Planetary peace.",
            "Comet of luck.", "Eclipse the negativity.", "Solar power soul."
        ];
        return wishes[index % wishes.length];
    }

    useEffect(() => {
        const newStars = [];
        const colors = ['text-white', 'text-yellow-200', 'text-blue-200', 'text-pink-200'];
        // Generate 30 unique stars
        for(let i=0; i<30; i++) {
            newStars.push({
                id: `galaxy_star_${i}`,
                top: Math.random() * 90 + 5,
                left: Math.random() * 90 + 5,
                type: i % 7 === 0 ? 'secret' : 'normal' as 'normal'|'secret',
                size: Math.random() * 10 + 4,
                color: colors[Math.floor(Math.random() * colors.length)],
                defaultWish: getStarWish(i)
            });
        }
        setStars(newStars);
    }, []);

    return (
        <div className="min-h-screen bg-[#020617] relative overflow-hidden">
            {/* Background Image */}
            <div className="absolute inset-0">
                <EditableImage id="galaxy_bg" defaultSrc="https://images.unsplash.com/photo-1534447677768-be436bb09401?w=1200" isAdmin={isAdmin} className="w-full h-full object-cover opacity-60" />
            </div>
            
            <h2 className="absolute top-10 w-full text-center text-white cursive text-4xl z-10 text-shadow-glow">
                <EditableText id="galaxy_title" defaultText="Galaxy of Wishes" isAdmin={isAdmin}/>
            </h2>
            
            {stars.map(s => (
                <motion.button
                    key={s.id}
                    className={`absolute ${s.color} hover:text-yellow-400 transition-colors z-20`}
                    style={{ top: `${s.top}%`, left: `${s.left}%` }}
                    animate={{ scale: [1, 1.5, 1], opacity: [0.4, 1, 0.4] }}
                    transition={{ duration: Math.random() * 3 + 2, repeat: Infinity }}
                    onClick={() => setPopup(s.id)}
                >
                    <Star size={s.size} fill="currentColor" />
                    {s.type === 'secret' && isAdmin && <span className="absolute -top-2 -right-2 w-2 h-2 bg-red-500 rounded-full"></span>}
                </motion.button>
            ))}

            <AnimatePresence>
                {popup !== null && (
                    <motion.div initial={{scale:0}} animate={{scale:1}} exit={{scale:0}} className="fixed inset-0 flex items-center justify-center z-50 bg-black/60 backdrop-blur-sm" onClick={() => setPopup(null)}>
                        <div className="bg-indigo-950/90 p-8 rounded-2xl border border-indigo-500/50 text-center max-w-sm mx-4 relative shadow-[0_0_50px_rgba(99,102,241,0.6)]" onClick={e => e.stopPropagation()}>
                            <div className="absolute -top-6 -right-6 text-yellow-400 animate-spin-slow"><Star size={40} fill="currentColor"/></div>
                            <h3 className="text-indigo-200 text-xs font-bold uppercase tracking-widest mb-4">Star Wish</h3>
                            <p className="text-2xl text-white font-serif italic leading-relaxed">
                                <EditableText id={`unique_star_msg_${popup}`} defaultText={stars.find(s => s.id === popup)?.defaultWish || "Magic!"} isAdmin={isAdmin} multiline/>
                            </p>
                            <button onClick={() => setPopup(null)} className="mt-6 bg-white/10 hover:bg-white/20 text-white px-6 py-2 rounded-full text-sm font-bold border border-white/20 transition-all">Close</button>
                        </div>
                    </motion.div>
                )}
            </AnimatePresence>
        </div>
    )
}

// 3. Heartbeat Scanner (Medical Grade Animation)
const HeartbeatScanner = ({ isAdmin }: { isAdmin: boolean }) => {
    const [state, setState] = useState<'IDLE' | 'SCANNING' | 'MATCHED'>('IDLE');

    const handleScan = () => {
        if (state === 'IDLE') {
            setState('SCANNING');
            setTimeout(() => setState('MATCHED'), 3500);
        }
    };

    return (
        <div className="min-h-screen bg-black flex flex-col items-center justify-center p-6 text-center relative overflow-hidden">
            {/* Grid Background */}
            <div className="absolute inset-0 bg-[linear-gradient(rgba(255,0,0,0.1)_1px,transparent_1px),linear-gradient(90deg,rgba(255,0,0,0.1)_1px,transparent_1px)] bg-[size:40px_40px]"></div>
            
            {state === 'IDLE' && (
                <motion.div initial={{opacity:0}} animate={{opacity:1}} className="z-10">
                    <h2 className="text-3xl text-red-500 font-bold mb-12 uppercase tracking-[0.2em] animate-pulse">Identity Scan Required</h2>
                    <div className="relative w-48 h-48 mx-auto cursor-pointer group" onMouseDown={handleScan} onTouchStart={handleScan}>
                        <div className="absolute inset-0 rounded-full border-2 border-red-900 group-hover:border-red-500 transition-colors"></div>
                        <div className="absolute inset-4 rounded-full border border-red-900 group-hover:border-red-500/50 transition-colors border-dashed animate-spin-slow"></div>
                        <div className="absolute inset-0 flex items-center justify-center">
                            <Fingerprint size={80} className="text-red-600 group-hover:text-red-400 transition-colors duration-300"/>
                        </div>
                        <div className="absolute -bottom-10 w-full text-center text-red-500/50 text-xs uppercase tracking-widest">Hold to Scan</div>
                    </div>
                </motion.div>
            )}

            {state === 'SCANNING' && (
                <div className="z-10 w-full max-w-md">
                    <div className="text-red-500 font-mono text-xl mb-4 animate-pulse">ANALYZING BIOMETRICS...</div>
                    <div className="w-full h-32 bg-black border border-red-900 rounded-lg relative overflow-hidden">
                         <div className="absolute top-1/2 w-full h-0.5 bg-red-900/30"></div>
                         {/* Fake ECG Line */}
                         <svg viewBox="0 0 500 100" className="w-full h-full absolute inset-0">
                             <polyline fill="none" stroke="#ef4444" strokeWidth="2" points="0,50 100,50 120,20 140,80 160,50 250,50 270,20 290,80 310,50 500,50" className="ecg-line" />
                         </svg>
                    </div>
                </div>
            )}

            {state === 'MATCHED' && (
                <motion.div initial={{scale:0.8, opacity:0}} animate={{scale:1, opacity:1}} className="z-10 relative">
                    <div className="absolute -inset-20 bg-red-600/20 blur-[100px] rounded-full animate-pulse"></div>
                    <Heart size={100} className="text-red-500 fill-current mx-auto mb-8 animate-beat drop-shadow-[0_0_20px_rgba(239,68,68,0.8)]" />
                    <h2 className="text-5xl cursive text-white mb-6 text-shadow-glow">Match Found!</h2>
                    <div className="bg-black/80 border border-red-500/30 p-8 rounded-2xl backdrop-blur-md max-w-lg">
                        <p className="text-2xl text-red-100 font-serif italic leading-relaxed">
                            <EditableText id="heartbeat_final_msg_unique" defaultText="Your heartbeat brings life into my world. Happy Birthday! ❤️" isAdmin={isAdmin} multiline/>
                        </p>
                    </div>
                    <button onClick={() => setState('IDLE')} className="mt-8 text-xs text-red-500/50 hover:text-red-400 uppercase tracking-widest">Reset System</button>
                </motion.div>
            )}

            <style>{`
                .ecg-line {
                    stroke-dasharray: 1000;
                    stroke-dashoffset: 1000;
                    animation: dash 3s linear infinite;
                }
                @keyframes dash { to { stroke-dashoffset: 0; } }
                @keyframes beat { 0%, 100% { transform: scale(1); } 25% { transform: scale(1.1); } 50% { transform: scale(1); } 75% { transform: scale(1.1); } }
                .animate-beat { animation: beat 1s infinite; }
            `}</style>
        </div>
    );
}

// 4. Mirror of Truth (Interactive Reveal)
const MirrorOfTruth = ({ isAdmin }: { isAdmin: boolean }) => {
    const [revealed, setRevealed] = useState(false);
    
    return (
        <div className="min-h-screen bg-gray-950 flex flex-col items-center justify-center p-4">
            <h2 className="text-4xl text-purple-200 cursive mb-8 z-10 relative">The Mirror of Truth</h2>
            
            <div 
               className="relative w-80 h-[500px] rounded-[100px] border-8 border-[#d4af37] shadow-[0_0_60px_rgba(212,175,55,0.3)] bg-gray-900 overflow-hidden cursor-pointer group"
               onClick={() => setRevealed(!revealed)}
            >
                {/* Mirror Frame Shine */}
                <div className="absolute inset-0 border-[12px] border-white/10 rounded-[90px] pointer-events-none z-20"></div>
                
                {/* Reflection Image */}
                <EditableImage 
                    id="mirror_bg_reveal" 
                    defaultSrc="https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=600" 
                    isAdmin={isAdmin} 
                    className={`absolute inset-0 w-full h-full object-cover transition-all duration-2000 ease-in-out ${revealed ? 'blur-0 opacity-100' : 'blur-3xl opacity-50 grayscale'}`} 
                />
                
                {/* Text Overlay */}
                <div className={`absolute inset-0 flex items-center justify-center p-8 text-center transition-all duration-1000 ${revealed ? 'bg-black/30' : 'bg-white/5'}`}>
                    {revealed ? (
                        <motion.div initial={{opacity:0, scale:0.8}} animate={{opacity:1, scale:1}} transition={{delay: 0.5}}>
                             <p className="text-3xl text-white font-serif font-bold text-shadow-glow leading-normal">
                                 <EditableText id="mirror_msg_unique_v2" defaultText="The most beautiful soul in the universe." isAdmin={isAdmin} multiline />
                             </p>
                        </motion.div>
                    ) : (
                        <div className="text-white/60">
                            <Eye size={48} className="mx-auto mb-4 opacity-50" />
                            <p className="text-sm uppercase tracking-[0.3em]">Touch to Reveal</p>
                        </div>
                    )}
                </div>
            </div>
            
            <p className="mt-8 text-white/30 text-xs uppercase tracking-widest">Ancient Magic detected</p>
        </div>
    )
}

// 5. Love Weather (Atmospheric)
const LoveWeather = ({ isAdmin }: { isAdmin: boolean }) => {
    const [weather, setWeather] = useState<'RAIN' | 'STARS' | 'SUN' | 'NONE'>('NONE');

    // Unique Texts
    const weatherTexts = {
        RAIN: "Showering you with endless blessings! 🌧️",
        STARS: "You outshine every constellation! ✨",
        SUN: "Your smile lights up my world! ☀️"
    };

    return (
        <div className="min-h-screen relative overflow-hidden transition-all duration-1000 ease-in-out"
            style={{ 
                background: weather === 'SUN' 
                    ? 'linear-gradient(to bottom, #fef3c7, #fbbf24)' 
                    : weather === 'RAIN' 
                    ? 'linear-gradient(to bottom, #172554, #1e3a8a)' 
                    : '#0f172a' 
            }}
        >
            <div className="relative z-20 flex flex-col items-center justify-center h-full pt-24 px-4">
                <h2 className={`text-5xl cursive mb-12 drop-shadow-lg ${weather === 'SUN' ? 'text-orange-700' : 'text-white'}`}>
                    <EditableText id="weather_title" defaultText="Love Forecast" isAdmin={isAdmin}/>
                </h2>
                
                <div className="flex gap-6 mb-12">
                    <button onClick={() => setWeather('RAIN')} className="group relative p-6 bg-blue-900/40 backdrop-blur-md rounded-2xl border border-blue-400/30 hover:bg-blue-800/60 transition-all shadow-xl">
                        <CloudRain size={32} className="text-blue-300 group-hover:scale-110 transition-transform"/>
                    </button>
                    <button onClick={() => setWeather('STARS')} className="group relative p-6 bg-purple-900/40 backdrop-blur-md rounded-2xl border border-purple-400/30 hover:bg-purple-800/60 transition-all shadow-xl">
                        <Star size={32} className="text-purple-300 group-hover:scale-110 transition-transform"/>
                    </button>
                    <button onClick={() => setWeather('SUN')} className="group relative p-6 bg-orange-500/20 backdrop-blur-md rounded-2xl border border-orange-400/30 hover:bg-orange-500/40 transition-all shadow-xl">
                        <Sun size={32} className="text-orange-300 group-hover:scale-110 transition-transform"/>
                    </button>
                </div>
                
                <AnimatePresence mode="wait">
                    {weather !== 'NONE' && (
                        <motion.div 
                            key={weather}
                            initial={{y:20, opacity:0}} animate={{y:0, opacity:1}} exit={{y:-20, opacity:0}}
                            className={`text-2xl font-bold text-center max-w-lg p-8 rounded-3xl shadow-2xl backdrop-blur-xl border border-white/20 ${weather === 'SUN' ? 'text-orange-900 bg-white/40' : 'text-white bg-black/40'}`}
                        >
                            <EditableText id={`weather_msg_unique_${weather}`} defaultText={weatherTexts[weather]} isAdmin={isAdmin} multiline/>
                        </motion.div>
                    )}
                </AnimatePresence>
            </div>

            {/* Ultra Realistic Weather Effects */}
            {weather === 'RAIN' && (
                <div className="absolute inset-0 z-10 pointer-events-none bg-[url('https://www.transparenttextures.com/patterns/diagonal-stripes.png')] opacity-10">
                     {Array.from({length: 100}).map((_,i) => (
                         <div key={i} className="absolute top-0 w-[1px] h-10 bg-gradient-to-b from-transparent to-blue-300 opacity-60 animate-[rain_0.8s_linear_infinite]" 
                              style={{left: `${Math.random()*100}%`, animationDelay: `${Math.random()}s`, animationDuration: `${0.5 + Math.random()*0.3}s`}} 
                         />
                     ))}
                     <style>{`@keyframes rain { 0% {transform: translateY(-50px)} 100% {transform: translateY(110vh)} }`}</style>
                </div>
            )}
             {weather === 'STARS' && (
                <div className="absolute inset-0 z-10 pointer-events-none">
                     <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/stardust.png')] opacity-40"></div>
                     {Array.from({length: 60}).map((_,i) => (
                         <Star key={i} size={Math.random()*4} className="absolute text-white animate-pulse" 
                               style={{left: `${Math.random()*100}%`, top: `${Math.random()*100}%`, animationDuration: `${1+Math.random()*3}s`}} 
                         />
                     ))}
                </div>
            )}
            {weather === 'SUN' && (
                <div className="absolute inset-0 z-10 pointer-events-none overflow-hidden">
                    <div className="absolute -top-[20%] -right-[20%] w-[80%] h-[80%] bg-orange-400 rounded-full blur-[150px] opacity-30 animate-pulse"></div>
                    <div className="absolute top-1/2 left-1/2 w-full h-full bg-yellow-200/10 rotate-45 transform origin-center"></div>
                </div>
            )}
        </div>
    )
}

// 6. Future Message (Sci-Fi Hologram)
const FutureMessage = ({ isAdmin }: { isAdmin: boolean }) => {
    const [incoming, setIncoming] = useState(false);
    
    useEffect(() => {
        setTimeout(() => setIncoming(true), 1500);
    }, []);

    return (
        <div className="min-h-screen bg-black flex items-center justify-center p-4 overflow-hidden relative">
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-cyan-900/20 via-black to-black"></div>
            
            <div className="max-w-xl w-full border border-cyan-500/30 bg-black/80 p-1 rounded-2xl relative z-10 shadow-[0_0_50px_rgba(6,182,212,0.15)]">
                {/* Holographic Container */}
                <div className="relative border border-cyan-500/20 rounded-xl p-8 overflow-hidden min-h-[400px] flex flex-col items-center justify-center">
                    
                    {/* Scanlines & Grid */}
                    <div className="absolute inset-0 bg-[linear-gradient(rgba(6,182,212,0.05)_1px,transparent_1px),linear-gradient(90deg,rgba(6,182,212,0.05)_1px,transparent_1px)] bg-[size:20px_20px] pointer-events-none"></div>
                    <div className="absolute inset-0 bg-gradient-to-b from-transparent via-cyan-500/5 to-transparent animate-scan pointer-events-none"></div>

                    {!incoming ? (
                        <div className="text-cyan-400 font-mono text-center">
                            <div className="mb-4 text-xs tracking-[0.5em] animate-pulse">ESTABLISHING QUANTUM LINK</div>
                            <div className="w-48 h-1 bg-cyan-900 rounded overflow-hidden mx-auto">
                                <div className="h-full bg-cyan-400 animate-loading-bar"></div>
                            </div>
                        </div>
                    ) : (
                        <div className="text-center relative">
                             {/* Hologram Emitter */}
                            <div className="w-32 h-1 mx-auto bg-cyan-400 blur-sm mb-8 shadow-[0_0_20px_#22d3ee]"></div>
                            
                            <div className="w-24 h-24 mx-auto bg-cyan-500/10 rounded-full border border-cyan-400/50 flex items-center justify-center mb-6 shadow-[0_0_30px_rgba(6,182,212,0.3)]">
                                <Zap size={40} className="text-cyan-300 animate-pulse"/>
                            </div>
                            
                            <h3 className="text-cyan-300 font-bold uppercase tracking-[0.3em] text-xs mb-6">Transmission Date: 08-12-2035</h3>
                            
                            <div className="relative p-6 border-l-2 border-cyan-500/50 bg-cyan-900/10">
                                <p className="text-white font-mono text-lg leading-relaxed typing-effect drop-shadow-[0_0_5px_rgba(6,182,212,0.8)]">
                                   <EditableText id="future_msg_unique_v2" defaultText="Message from the future: She becomes even more amazing every single year. The world is lucky to have her. Happy Birthday Shivani." isAdmin={isAdmin} multiline/>
                                </p>
                            </div>
                            
                            <div className="mt-8 text-[10px] text-cyan-600 font-mono flex justify-between uppercase w-full">
                                <span>Encrypted: AES-256</span>
                                <span>Source: Timeline Alpha</span>
                            </div>
                        </div>
                    )}
                </div>
            </div>
            
            <style>{`
                @keyframes scan { 0% {transform: translateY(-100%)} 100% {transform: translateY(100%)} }
                .animate-scan { animation: scan 3s linear infinite; }
                @keyframes loading { 0% {width:0} 100% {width:100%} }
                .animate-loading-bar { animation: loading 1.5s ease-out forwards; }
            `}</style>
        </div>
    )
}

// 7. Make a Wish (Interactive Orb)
const MakeAWish = ({ isAdmin }: { isAdmin: boolean }) => {
    const [wish, setWish] = useState('');
    const [sent, setSent] = useState(false);

    const handleSend = () => {
        if(!wish) return;
        setSent(true);
        setTimeout(() => {
            confetti({ particleCount: 150, spread: 100, origin: { y: 0.7 }, colors: ['#fbbf24', '#ffffff'] });
        }, 300);
    }

    return (
        <div className="min-h-screen bg-gradient-to-b from-[#1e1b4b] to-black flex items-center justify-center p-4">
            <div className="text-center w-full max-w-md relative z-10">
                {!sent ? (
                    <motion.div initial={{scale:0.9, opacity:0}} animate={{scale:1, opacity:1}} className="bg-white/5 backdrop-blur-xl p-8 rounded-3xl border border-white/10 shadow-2xl">
                        <div className="w-40 h-40 mx-auto rounded-full bg-gradient-to-tr from-indigo-500 via-purple-500 to-pink-500 blur-md mb-8 animate-pulse relative">
                             <div className="absolute inset-0 rounded-full bg-white opacity-20 animate-ping"></div>
                        </div>
                        
                        <h2 className="text-4xl text-white cursive mb-6"><EditableText id="make_wish_title" defaultText="Cast a Spell" isAdmin={isAdmin}/></h2>
                        <input 
                            value={wish}
                            onChange={e => setWish(e.target.value)}
                            placeholder="Type your deepest wish..."
                            className="w-full bg-black/30 border border-white/20 rounded-xl px-6 py-4 text-white text-center outline-none focus:border-purple-400 focus:bg-black/50 transition-all mb-6 placeholder-white/30"
                        />
                        <GlowingButton onClick={handleSend} className="w-full bg-gradient-to-r from-purple-600 to-pink-600 border-none text-white shadow-lg shadow-purple-900/50">Send to Universe</GlowingButton>
                    </motion.div>
                ) : (
                    <motion.div initial={{y:20, opacity:0}} animate={{y:0, opacity:1}} className="text-center">
                         <div className="w-24 h-24 mx-auto bg-yellow-400 rounded-full blur-[50px] mb-8"></div>
                         <Star size={80} className="mx-auto text-yellow-300 mb-6 animate-[spin_3s_linear_infinite]" fill="currentColor" />
                         <h2 className="text-5xl text-white cursive mb-4">Wish Received</h2>
                         <p className="text-purple-200 text-xl font-light">The stars are aligning for you. ✨</p>
                         <button onClick={() => {setSent(false); setWish('')}} className="mt-8 text-white/50 hover:text-white underline text-sm">Make another wish</button>
                    </motion.div>
                )}
            </div>
            
            {/* Background Particles */}
             <div className="absolute inset-0 pointer-events-none">
                 {Array.from({length: 40}).map((_,i) => (
                     <div key={i} className="absolute rounded-full bg-white opacity-20" 
                          style={{
                              width: Math.random()*4, 
                              height: Math.random()*4, 
                              left: `${Math.random()*100}%`, 
                              top: `${Math.random()*100}%`,
                              animation: `twinkle ${Math.random()*3+2}s infinite`
                          }} 
                     />
                 ))}
             </div>
        </div>
    )
}

// 8. Treasure Boxes (Unique Content per Box)
const TreasureBoxes = ({ isAdmin }: { isAdmin: boolean }) => {
    const [opened, setOpened] = useState<number | null>(null);
    const boxes = Array.from({length: 8});
    
    // Default Unique Wishes for boxes
    const boxWishes = [
        "A pocketful of sunshine just for you.",
        "Remember: You are stronger than you know.",
        "May your day be filled with sweet surprises.",
        "Sending you a giant virtual hug!",
        "You are a limited edition masterpiece.",
        "Keep shining, beautiful soul.",
        "Adventure awaits you this year.",
        "Happiness looks gorgeous on you."
    ];

    return (
        <div className="min-h-screen bg-[#2c1a12] p-4 flex flex-col items-center justify-center relative overflow-hidden">
            <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/wood-pattern.png')] opacity-30"></div>
            
            <h2 className="text-5xl text-[#fbbf24] cursive mb-12 relative z-10 text-shadow-glow">
                <EditableText id="boxes_title" defaultText="Treasure Memories" isAdmin={isAdmin}/>
            </h2>
            
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 relative z-10 max-w-4xl w-full">
                {boxes.map((_, i) => (
                    <motion.button 
                        key={i}
                        onClick={() => setOpened(i)}
                        whileHover={{scale:1.05, rotate: [-1, 1, -1]}}
                        className="aspect-square bg-gradient-to-br from-yellow-600 via-yellow-700 to-yellow-900 rounded-2xl border-4 border-[#fbbf24] shadow-[0_10px_30px_rgba(0,0,0,0.5)] flex items-center justify-center relative group overflow-hidden"
                    >
                         {/* Shine effect */}
                         <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/20 to-transparent translate-y-full group-hover:translate-y-[-100%] transition-transform duration-700"></div>
                         
                         <Lock size={40} className="text-[#fbbf24] drop-shadow-md group-hover:scale-110 transition-transform"/>
                         <span className="absolute bottom-2 right-3 text-[#fef3c7] font-bold text-xl opacity-50">{i+1}</span>
                    </motion.button>
                ))}
            </div>
            
            <AnimatePresence>
                {opened !== null && (
                     <motion.div initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}} className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 p-4" onClick={() => setOpened(null)}>
                         <motion.div 
                            initial={{scale:0, rotate: 180}} animate={{scale:1, rotate: 0}} exit={{scale:0}}
                            className="bg-[#fffbeb] p-8 rounded-3xl max-w-sm w-full text-center border-4 border-[#fbbf24] shadow-2xl relative overflow-hidden" 
                            onClick={e => e.stopPropagation()}
                        >
                             <div className="absolute -top-10 -right-10 w-32 h-32 bg-yellow-300 rounded-full blur-[40px]"></div>
                             <Gift size={64} className="mx-auto text-pink-500 mb-6 drop-shadow-md"/>
                             <h3 className="text-xl font-bold text-amber-900 mb-2 uppercase tracking-wide">Box #{opened + 1} Unlocked</h3>
                             <p className="text-lg font-serif italic text-amber-800 leading-relaxed">
                                 <EditableText id={`box_unique_wish_v2_${opened}`} defaultText={boxWishes[opened]} isAdmin={isAdmin} multiline />
                             </p>
                             <button onClick={() => setOpened(null)} className="mt-6 text-sm text-amber-700/60 font-bold uppercase tracking-widest hover:text-amber-900">Close Treasure</button>
                         </motion.div>
                     </motion.div>
                )}
            </AnimatePresence>
        </div>
    )
}

// 9. Love Reel (Auto-Playing Cinematic)
const LoveReel = ({ isAdmin }: { isAdmin: boolean }) => (
    <div className="min-h-screen bg-black flex items-center justify-center relative">
        <div className="absolute inset-0 bg-gradient-to-b from-black via-transparent to-black z-10 pointer-events-none"></div>
        <div className="w-full h-full absolute inset-0 opacity-30">
            <EditableImage id="reel_bg_blur" defaultSrc="https://images.unsplash.com/photo-1518568814500-bf0f8d125f46?w=600" isAdmin={isAdmin} className="w-full h-full object-cover blur-3xl"/>
        </div>
        
        <div className="w-full max-w-sm aspect-[9/16] bg-gray-900 rounded-3xl overflow-hidden relative shadow-[0_0_100px_rgba(236,72,153,0.3)] border border-gray-800 z-20 group">
            <EditableImage id="reel_main_img" defaultSrc="https://images.unsplash.com/photo-1518568814500-bf0f8d125f46?w=800" className="w-full h-full object-cover transition-transform duration-[10s] ease-linear scale-100 group-hover:scale-110" isAdmin={isAdmin}/>
            
            <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-transparent to-black/30 flex flex-col items-center justify-end text-center p-8 pb-20">
                 <h2 className="text-5xl font-bold text-white mb-4 cursive animate-pulse text-shadow-glow">Happy Birthday!</h2>
                 <p className="text-pink-300 text-2xl font-bold mb-8 leading-tight">
                     <EditableText id="reel_text_unique_v2" defaultText="You are loved more than you know 💖" isAdmin={isAdmin} multiline />
                 </p>
            </div>
            
            {/* Play bar animation */}
            <div className="absolute bottom-10 left-8 right-8 h-1 bg-gray-700 rounded-full overflow-hidden">
                <div className="h-full bg-pink-500 w-full animate-[loading_5s_linear_infinite]"></div>
            </div>
        </div>
    </div>
);

// 10. Wishing Tree (Wind & Leaf Animation)
const WishingTree = ({ isAdmin }: { isAdmin: boolean }) => {
    const [activeLeaf, setActiveLeaf] = useState<number | null>(null);
    // Distinct positions for leaves
    const leaves = [
        { top: 20, left: 30, delay: 0 }, { top: 30, left: 60, delay: 1 }, { top: 50, left: 20, delay: 0.5 },
        { top: 50, left: 70, delay: 1.5 }, { top: 70, left: 40, delay: 2 }, { top: 15, left: 50, delay: 2.5 }
    ];

    const leafWishes = [
        "Growth in every step.", "Roots of strength.", "Blossoming joy.",
        "Peace of mind.", "Health and vitality.", "Golden memories."
    ];

    return (
        <div className="min-h-screen bg-[#052e16] relative overflow-hidden">
            <div className="absolute inset-0 opacity-40">
                <EditableImage id="tree_bg" defaultSrc="https://images.unsplash.com/photo-1513836279014-a89f7a76ae86?w=1200" isAdmin={isAdmin} className="w-full h-full object-cover"/>
            </div>
            
            <h2 className="absolute top-10 w-full text-center text-green-300 cursive text-5xl z-10 text-shadow-glow">The Wishing Tree</h2>
            
            <div className="absolute inset-0 pointer-events-none">
                {leaves.map((l, i) => (
                    <motion.button 
                        key={i}
                        className="absolute text-green-400 pointer-events-auto hover:text-yellow-300 transition-colors z-20"
                        style={{ top: `${l.top}%`, left: `${l.left}%` }}
                        animate={{ y: [0, 10, 0], rotate: [0, 5, -5, 0] }}
                        transition={{ duration: 4, delay: l.delay, repeat: Infinity }}
                        onClick={() => setActiveLeaf(i)}
                    >
                        <Leaf size={40} fill="currentColor" className="drop-shadow-lg"/>
                    </motion.button>
                ))}
            </div>

            <AnimatePresence>
                {activeLeaf !== null && (
                    <motion.div initial={{y: 50, opacity:0}} animate={{y:0, opacity:1}} exit={{y:50, opacity:0}} className="fixed bottom-0 inset-x-0 p-8 bg-green-950/90 backdrop-blur-md border-t border-green-500/30 z-50 text-center rounded-t-3xl">
                        <button onClick={() => setActiveLeaf(null)} className="absolute top-4 right-4 text-green-500"><X size={24}/></button>
                        <Leaf size={40} className="mx-auto text-green-400 mb-4 animate-bounce"/>
                        <h3 className="text-2xl text-white font-serif">
                            <EditableText id={`leaf_wish_unique_${activeLeaf}`} defaultText={leafWishes[activeLeaf]} isAdmin={isAdmin} multiline/>
                        </h3>
                    </motion.div>
                )}
            </AnimatePresence>
        </div>
    )
}

// 11. Emotion Scratch Cards (Interactive)
const EmotionScratchCards = ({ isAdmin }: { isAdmin: boolean }) => {
    // 8 Cards with different default types and messages
    const cards = [
        { type: "Emotional", color: "from-pink-500 to-rose-600", defaultMsg: "You make the world softer." },
        { type: "Funny", color: "from-yellow-400 to-orange-500", defaultMsg: "You're aging like fine wine... or cheese?" },
        { type: "Romantic", color: "from-red-500 to-pink-600", defaultMsg: "My heart beats your name." },
        { type: "Special", color: "from-purple-500 to-indigo-600", defaultMsg: "One in a billion." },
        { type: "Secret", color: "from-gray-700 to-black", defaultMsg: "Hidden wish unlocked!" },
        { type: "Joy", color: "from-green-400 to-teal-500", defaultMsg: "Radiate happiness always." },
        { type: "Dream", color: "from-blue-400 to-cyan-500", defaultMsg: "Chase the stars." },
        { type: "Hope", color: "from-amber-300 to-yellow-500", defaultMsg: "Tomorrow is bright." }
    ];

    return (
        <div className="min-h-screen bg-[#1f1016] p-4 flex flex-col items-center">
            <h2 className="text-4xl text-pink-200 cursive mb-8 mt-12">Emotion Scratch Cards</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 w-full max-w-6xl">
                {cards.map((c, i) => (
                    <div key={i} className="relative h-64 rounded-2xl overflow-hidden shadow-xl transform hover:scale-105 transition-transform duration-300">
                        {/* Background (Hidden Content) */}
                        <div className={`absolute inset-0 bg-gradient-to-br ${c.color} flex flex-col items-center justify-center p-6 text-center text-white`}>
                            <h3 className="font-bold uppercase tracking-widest text-xs mb-2 opacity-75">{c.type}</h3>
                            <p className="font-serif text-lg font-bold">
                                <EditableText id={`card_msg_unique_${i}`} defaultText={c.defaultMsg} isAdmin={isAdmin} multiline />
                            </p>
                        </div>
                        {/* Scratch Overlay Component handles the top layer */}
                        <div className="absolute inset-0">
                            <ScratchCard 
                                imageSrc="" 
                                text="" // Text is already in background
                            />
                            {/* Overlay Title just for context before scratch */}
                            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 pointer-events-none text-amber-900 font-bold text-xl mix-blend-multiply opacity-50">
                                {c.type}
                            </div>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    )
}

// 12. Aurora Sky (Canvas Animation)
const AuroraSky = ({ isAdmin }: { isAdmin: boolean }) => {
    // Simulated Aurora with CSS Gradients
    const [pattern, setPattern] = useState(0);
    const patterns = [
        "linear-gradient(45deg, #0f172a, #1e1b4b, #312e81)",
        "linear-gradient(135deg, #064e3b, #115e59, #134e4a)",
        "linear-gradient(to bottom, #2e1065, #4c1d95, #7c3aed)"
    ];

    return (
        <div className="min-h-screen transition-all duration-3000 ease-in-out flex flex-col items-center justify-center relative overflow-hidden" style={{background: patterns[pattern]}}>
             <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/stardust.png')] opacity-30"></div>
             
             {/* Aurora Layers */}
             <div className="absolute -inset-[50%] bg-gradient-to-r from-green-400 via-blue-500 to-purple-600 opacity-30 blur-[100px] animate-[spin_20s_linear_infinite]"></div>
             
             <div className="relative z-10 text-center">
                 <h2 className="text-6xl text-white cursive mb-6 text-shadow-glow">Aurora Dreams</h2>
                 <p className="text-blue-200 text-xl font-light mb-12">Watch the colors dance for you.</p>
                 <button onClick={() => setPattern((pattern + 1) % patterns.length)} className="px-8 py-3 bg-white/10 hover:bg-white/20 text-white rounded-full border border-white/30 backdrop-blur-md transition-all">Change Sky</button>
             </div>
        </div>
    )
}

// 13. Magical Library (Story Generator)
const MagicalLibrary = ({ isAdmin }: { isAdmin: boolean }) => {
    const [generatedStory, setGeneratedStory] = useState("");
    
    // Simple mock generator if AI is unavailable or for instant feedback
    const generate = () => {
        const stories = [
            "Once upon a time, a queen named Shivani ruled with kindness. Her smile could bloom flowers in winter.",
            "In a galaxy far away, a star was named Shivani. It was the brightest guide for all travelers.",
            "Deep in the enchanted forest, the fairies celebrated Shivani Day, where magic was strongest."
        ];
        setGeneratedStory(stories[Math.floor(Math.random() * stories.length)]);
    }

    return (
        <div className="min-h-screen bg-[#1e1e1e] flex flex-col items-center justify-center p-8 relative">
            <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/binding-dark.png')] opacity-50"></div>
            
            <BookOpen size={64} className="text-amber-500 mb-8 relative z-10"/>
            <h2 className="text-4xl text-amber-100 font-serif mb-8 relative z-10">The Chronicles of Shivani</h2>
            
            <div className="max-w-2xl w-full bg-[#fdf6e3] text-[#433422] p-10 rounded-lg shadow-2xl relative z-10 leading-relaxed font-serif text-lg min-h-[200px] flex items-center justify-center text-center">
                 {generatedStory ? (
                     <motion.p initial={{opacity:0}} animate={{opacity:1}}>{generatedStory}</motion.p>
                 ) : (
                     <span className="opacity-50 italic">The pages are blank... waiting for magic.</span>
                 )}
            </div>
            
            <button onClick={generate} className="mt-8 px-8 py-3 bg-amber-700 text-amber-100 rounded shadow-lg hover:bg-amber-600 transition-colors relative z-10 font-bold uppercase tracking-widest text-xs">Read a Legend</button>
        </div>
    )
}
