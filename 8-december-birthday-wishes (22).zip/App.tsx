
import React, { useState, useEffect, useRef } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { Music, Sun, Moon, Palette, ChevronLeft, Info, AlertOctagon } from 'lucide-react';

import { Particles } from './components/Particles';
import { FloatingElements } from './components/FloatingElements';
import { ThemeProvider, useTheme, ThemeName } from './components/ThemeContext';
import { LoginView } from './views/Login';
import { AdminDashboard } from './views/Admin';
import { PrivateDashboard } from './views/Private';
import { PublicPortal } from './views/Public';
import { LandingView } from './views/Landing';
import { VerificationView } from './views/Verification';
import { InterstitialView } from './views/Interstitial';
import { UserRole } from './types';
import { db } from './services/database';

// Flow State Types
type FlowStage = 'LANDING' | 'VERIFY' | 'INTERSTITIAL' | 'MAIN';

function AppContent() {
  const [role, setRole] = useState<UserRole>(UserRole.GUEST);
  const [music, setMusic] = useState(false);
  
  // New Flow States
  const [flowStage, setFlowStage] = useState<FlowStage>('LANDING');
  const [interstitialType, setInterstitialType] = useState<'GUEST' | 'PRIVATE'>('GUEST');
  const [userName, setUserName] = useState('');
  
  // Global Extras
  const [broadcast, setBroadcast] = useState('');
  const [systemLocked, setSystemLocked] = useState(false);

  const audioRef = useRef<HTMLAudioElement | null>(null);
  const { theme, setTheme, mode, toggleMode } = useTheme();

  // --- ADVANCED TRACKING: HEARTBEAT & AUTO-RECOVERY ---
  useEffect(() => {
     // Check for persistent device ID
     const deviceId = localStorage.getItem('device_fingerprint');
     
     // Heartbeat Interval: Runs every 60 seconds
     const heartbeat = setInterval(() => {
        if (role !== UserRole.GUEST && deviceId) {
            db.trackUserHeartbeat(deviceId);
        }
     }, 60000); // 1 Minute

     return () => clearInterval(heartbeat);
  }, [role]);

  // --- Session & System Watchdog (INSTANT APPLY LOGIC) ---
  useEffect(() => {
    // 1. Initial State Load
    const checkSystem = () => {
        const currentSys = db.getSystemState();
        
        // A. Global System Lock
        setSystemLocked(currentSys.systemLocked);

        // B. Active Session Lock Enforcement (Kick out users immediately if locked)
        if (role === UserRole.PUBLIC && currentSys.guestLocked) {
             alert("Admin has temporarily locked the Guest Portal.");
             handleLogout(); // Kick to landing
        }
        if (role === UserRole.PRIVATE && currentSys.privateLocked) {
             alert("Maintenance Mode: Private Portal is temporarily locked.");
             handleLogout(); // Kick to landing
        }

        // C. Force Refresh / Renew Experience (Session Version Check)
        const localVer = parseInt(localStorage.getItem('session_version') || '0');
        if (currentSys.sessionVersion > localVer) {
             console.log("System update detected. Refreshing...");
             localStorage.setItem('session_version', currentSys.sessionVersion.toString());
             window.location.reload(); 
        }

        // D. Broadcast
        const msg = db.getConfig('global_broadcast_message', '');
        if(msg !== broadcast) setBroadcast(msg);
    };

    // Initial check
    checkSystem();

    // High frequency polling for "Instant" feel (1 second)
    const interval = setInterval(checkSystem, 1000);

    return () => clearInterval(interval);
  }, [role, broadcast]); // Re-run if role changes

  // --- History API & Initialization ---
  useEffect(() => {
    // Initialize history state on mount
    window.history.replaceState({ stage: 'LANDING', role: UserRole.GUEST }, '');

    const handlePopState = (event: PopStateEvent) => {
      const state = event.state;
      if (state) {
        if (state.stage) setFlowStage(state.stage);
        if (state.role) setRole(state.role);
        if (state.interstitialType) setInterstitialType(state.interstitialType);
        if (state.userName) setUserName(state.userName);
      } else {
        // Fallback to landing if no state
        setFlowStage('LANDING');
        setRole(UserRole.GUEST);
      }
    };

    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  useEffect(() => {
    // Load Music from DB
    const musicUrl = db.getConfig('global_music_url', "https://soundbible.com/mp3/Music_Box-Big_Daddy-1389738694.mp3");
    audioRef.current = new Audio(musicUrl);
    audioRef.current.loop = true;
    audioRef.current.volume = 0.4;
  }, []);

  const toggleMusic = () => {
    if(!audioRef.current) return;
    if(music) audioRef.current.pause();
    else audioRef.current.play().catch(e => console.log("Audio interaction required"));
    setMusic(!music);
  };

  const handleLogin = (newRole: UserRole) => {
    // Push new state for the logged-in view
    const newState = { 
      stage: 'MAIN', 
      role: newRole, 
      interstitialType, 
      userName 
    };
    window.history.pushState(newState, '');
    setRole(newRole);
  };

  const handleLogout = () => {
    // Navigate back to landing by pushing state
    const newState = { stage: 'LANDING', role: UserRole.GUEST, userName: '' };
    window.history.pushState(newState, '');
    
    setRole(UserRole.GUEST);
    setFlowStage('LANDING');
    setUserName('');
    if(music) toggleMusic();
  };

  // --- Flow Handlers ---

  const handleStartMagic = () => {
    const newState = { stage: 'VERIFY', role: UserRole.GUEST };
    window.history.pushState(newState, '');
    setFlowStage('VERIFY');
  };

  const handleBack = () => {
    window.history.back();
  };

  const handleVerification = (name: string, code: string) => {
    const type = code === '0812' ? 'PRIVATE' : 'GUEST';
    
    const newState = { 
      stage: 'INTERSTITIAL', 
      role: UserRole.GUEST,
      interstitialType: type,
      userName: name 
    };
    
    window.history.pushState(newState, '');

    setUserName(name);
    setInterstitialType(type);
    setFlowStage('INTERSTITIAL');
  };

  const handleInterstitialComplete = () => {
    // Determine target role based on interstitial type
    const nextRole = interstitialType === 'GUEST' ? UserRole.PUBLIC : UserRole.GUEST;

    const newState = { 
      stage: 'MAIN', 
      role: nextRole, 
      interstitialType, 
      userName 
    };
    
    window.history.pushState(newState, '');
    
    setFlowStage('MAIN');
    setRole(nextRole);
  };

  // Logic for UI Elements based on flow
  const showThemeControls = flowStage === 'LANDING' || flowStage === 'VERIFY';
  // Show back button on all pages except Landing
  const showBackButton = flowStage !== 'LANDING'; 

  // SYSTEM LOCK SCREEN (Applies to everyone except Admin)
  if (systemLocked && role !== UserRole.ADMIN) {
      return (
          <div className="min-h-screen bg-zinc-900 flex flex-col items-center justify-center p-8 text-center font-sans">
              <div className="w-24 h-24 bg-red-500/10 rounded-full flex items-center justify-center mb-6 animate-pulse">
                <AlertOctagon size={48} className="text-red-500"/>
              </div>
              <h1 className="text-3xl font-bold text-white mb-4 uppercase tracking-wider">System Maintenance</h1>
              <p className="text-gray-400 max-w-md mx-auto mb-8">
                  The portal is currently under a magical renovation. <br/> Please check back in a few minutes.
              </p>
              
              {/* Secret Admin Backdoor */}
              <button 
                onClick={() => handleLogin(UserRole.ADMIN)} 
                className="mt-20 opacity-0 hover:opacity-100 text-[10px] text-gray-700 uppercase tracking-widest"
              >
                  Admin Override
              </button>
          </div>
      )
  }

  return (
    <div className="min-h-screen w-full relative overflow-x-hidden font-sans text-[var(--text-main)] transition-colors duration-700">
      <Particles />
      <FloatingElements />
      
      {/* Broadcast Modal */}
      <AnimatePresence>
          {broadcast && (
              <motion.div initial={{y: -100}} animate={{y: 20}} exit={{y: -100}} className="fixed top-0 left-1/2 -translate-x-1/2 z-[100] max-w-sm w-full px-4">
                  <div className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white p-4 rounded-xl shadow-2xl border border-white/20 flex items-start gap-3">
                      <Info className="shrink-0 mt-0.5" />
                      <div className="flex-1">
                          <h4 className="font-bold text-sm uppercase mb-1">Admin Announcement</h4>
                          <p className="text-sm opacity-90">{broadcast}</p>
                      </div>
                      <button onClick={() => setBroadcast('')} className="text-white/50 hover:text-white"><div className="text-lg">&times;</div></button>
                  </div>
              </motion.div>
          )}
      </AnimatePresence>

      {/* HEADER CONTROLS */}
      <div className="fixed top-4 left-4 z-50 flex flex-col sm:flex-row items-start sm:items-center gap-3">
        
        {/* Case 1: Theme Controls (First 2 pages) */}
        {showThemeControls && (
          <>
            <div className="relative group">
               {/* Animated border gradient */}
               <div className="absolute inset-0 bg-gradient-to-r from-[var(--accent-primary)] to-[var(--accent-secondary)] rounded-xl blur opacity-30 group-hover:opacity-60 transition duration-500"></div>
               
               <div className="relative bg-[var(--bg-card)] border border-[var(--border-color)] rounded-xl p-1 flex items-center shadow-2xl backdrop-blur-md">
                  <div className="p-2 bg-[var(--bg-input)] rounded-lg mr-1">
                     <Palette size={16} className="text-[var(--accent-secondary)]" />
                  </div>
                  <select 
                    value={theme}
                    onChange={(e) => setTheme(e.target.value as ThemeName)}
                    className="bg-transparent border-none text-[var(--text-main)] text-sm font-bold focus:outline-none py-2 pr-8 cursor-pointer appearance-none min-w-[140px]"
                    style={{ backgroundImage: 'none' }}
                  >
                    <option value="Love">Light Pink Love</option>
                    <option value="Galaxy">Midnight Galaxy</option>
                    <option value="Silver">Silver Elegance</option>
                    <option value="Ocean">Ocean Bliss</option>
                    <option value="Forest">Forest Whisper</option>
                  </select>
                  <div className="absolute right-3 pointer-events-none text-[var(--text-muted)]">
                     <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M6 9l6 6 6-6"/></svg>
                  </div>
               </div>
            </div>

            <motion.button
               onClick={toggleMode}
               whileHover={{ scale: 1.05 }}
               whileTap={{ scale: 0.95 }}
               className="p-3 rounded-xl bg-[var(--bg-card)] border border-[var(--border-color)] text-[var(--accent-secondary)] shadow-lg backdrop-blur-md hover:bg-[var(--bg-input)] transition-colors flex items-center justify-center"
            >
               {mode === 'Day' ? <Sun size={18} /> : <Moon size={18} />}
            </motion.button>
          </>
        )}

        {/* Case 2: Global Back Button (Later pages) */}
        {showBackButton && role !== UserRole.ADMIN && (
           <motion.button
             onClick={handleBack}
             whileHover={{ scale: 1.05 }}
             whileTap={{ scale: 0.95 }}
             className="flex items-center gap-2 px-4 py-2 rounded-xl bg-[var(--bg-card)] border border-[var(--border-color)] text-[var(--text-main)] shadow-lg backdrop-blur-md hover:bg-[var(--bg-input)] transition-colors font-bold"
           >
             <ChevronLeft size={20} /> Back
           </motion.button>
        )}
      </div>

      {/* Music Toggle (Top Right) */}
      <motion.button 
        onClick={toggleMusic}
        className={`fixed top-4 right-4 z-50 p-3 rounded-full backdrop-blur-md border border-[var(--border-color)] shadow-lg transition-all ${music ? 'bg-[var(--accent-primary)] text-white shadow-[var(--accent-primary)]/50' : 'bg-[var(--bg-card)] text-[var(--accent-secondary)]'}`}
        whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}
      >
        <Music size={20} className={music ? "animate-spin-slow" : ""} />
      </motion.button>

      <div className="relative z-10">
        <AnimatePresence mode="wait">
          {flowStage === 'LANDING' && (
            <LandingView key="landing" onStart={handleStartMagic} />
          )}

          {flowStage === 'VERIFY' && (
            <VerificationView key="verify" onVerify={handleVerification} onBack={handleBack} />
          )}

          {flowStage === 'INTERSTITIAL' && (
            <InterstitialView key="interstitial" type={interstitialType} userName={userName} onComplete={handleInterstitialComplete} onBack={handleBack} />
          )}

          {flowStage === 'MAIN' && (
             <>
                {role === UserRole.GUEST && <LoginView key="login" onLogin={handleLogin} initialName={interstitialType === 'PRIVATE' ? userName : ''} onBack={handleBack} />}
                {role === UserRole.ADMIN && <AdminDashboard key="admin" onLogout={handleLogout} />}
                {role === UserRole.PRIVATE && <PrivateDashboard key="private" onLogout={handleLogout} />}
                {role === UserRole.PUBLIC && <PublicPortal key="public" onLogout={handleLogout} initialName={userName} />}
             </>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <AppContent />
    </ThemeProvider>
  );
}
